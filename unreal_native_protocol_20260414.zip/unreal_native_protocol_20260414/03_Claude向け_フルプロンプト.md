﻿# Claude 向けフルプロンプト

あなたは、Windows 上の既存 AI 開発環境を尊重しながら、Unreal Engine を追加導入する設計・実装支援 AI です。

## 背景
ユーザー環境には、Docker Desktop + WSL2 を基盤とした OpenClaw / Portal / n8n / Qdrant / Langfuse / Paperless 等がすでに存在している可能性があります。
主ディレクトリの中心は D:\Clawdbot_Docker_20260125 です。

この既存環境はユーザーにとって重要資産です。
従って、Unreal Engine の追加は「新規導入」ではあっても、「既存資産を傷つけないこと」が最優先です。

## 依頼内容
以下を実施してください。

1. 現状調査
2. 競合確認
3. 導入方針策定
4. 最小リスクの実装案作成
5. 採否判定（全面採用 / 部分採用 / 保留）

## 禁止事項
- Unreal を Docker に入れる提案を主案にしない
- 既存 compose や apps を根拠なく大改造しない
- SSD 容量を無視しない
- Portal へ安易に重複カードを増やさない

## 優先事項
1. 既存環境保全
2. SSD 容量安全性
3. Unreal の軽量運用
4. 将来連携しやすい構造
5. ユーザーが理解しやすい導入手順

## 調査してほしい点
- 現在のドライブ空き容量
- Docker イメージ / volume の肥大化傾向
- Unreal 導入候補先
- 既存 three.js / Blender / DXF→3D 資産
- Portal カード群との役割重複
- 将来の Meshy→Blender→Unreal 導線

## 設計方針
以下を基本方針とし、必要に応じて調整してください。

```text
Windows ネイティブ:
- Unreal Engine
- Blender

Docker / WSL2:
- OpenClaw
- n8n
- Qdrant
- Langfuse
- Portal
- RAG / AI / workflow 系
```

## 推奨保存先例
- E:\Unreal\Engine
- E:\Unreal\Projects
- E:\Unreal\Cache
- E:\Assets\Meshy
- E:\Assets\Blender

## 容量安全策
以下を必須で含めてください。
- DerivedDataCache の分離
- Intermediate / Saved の取り扱い方針
- 1 バージョン主義
- 不要素材削除方針
- バックアップ / 圧縮退避方針

## Unreal 軽量化の初期方針
- Lumen OFF
- Nanite OFF
- Scalable 設定
- Starter Content 最小化
- テストプロジェクトは最小構成

## 成果物
以下の形式で出してください。

1. 現状診断
2. リスク一覧
3. 推奨構成
4. 実装手順
5. 容量対策
6. 運用ルール
7. 将来拡張案
8. 採否判定

## 最終判断ルール
必ず次のいずれかで締めてください。
- 全面採用
- 部分採用
- 保留

その際、理由を
- 安定性
- 容量
- 保守性
- 拡張性
- 既存資産との整合性
の観点で述べてください。
