﻿# SSD 容量対策と保存先ポリシー

## 1. なぜ容量対策が必要か
Unreal Engine は本体だけでなく、以下のような付帯データで容量を消費する。

- Engine 本体
- プロジェクト本体
- DerivedDataCache
- Intermediate
- Saved
- Marketplace / Starter Content / サンプル

このため、「インストール直後は余裕があるが、数週間で急速に圧迫する」ことが多い。

## 2. 推奨保存先分離

### 例
```text
D:\Clawdbot_Docker_20260125\    ← AI / Docker 側
E:\Unreal\Engine\              ← Engine 本体
E:\Unreal\Projects\            ← Unreal プロジェクト
E:\Unreal\Cache\               ← DerivedDataCache
E:\Assets\Meshy\               ← 生成済み 3D 資産
E:\Assets\Blender\             ← Blender 作業資産
F:\Archive\Unreal\             ← 退避済み資産（あれば）
```

## 3. OS ドライブ原則
- C: には Unreal 本体も大規模プロジェクトも置かない
- C: は OS と軽量ツールを優先する
- Epic Launcher が C: を使いたがる場合は、可能な範囲で保存先を変更する

## 4. DerivedDataCache の扱い
これはかなり肥大化しやすい。
可能なら専用フォルダへ逃がす。

運用方針:
- E:\Unreal\Cache\DDC などに分離
- 空き容量が減ったら定期掃除対象にする
- 削除後は再生成される前提で扱う

## 5. 削除候補
以下は状況によって削除・掃除候補とする。

- DerivedDataCache
- Intermediate
- Saved
- 不要サンプルプロジェクト
- 古いバックアップコピー

## 6. 1 バージョン主義
UE 5.x を複数持つと一気に容量を消費する。
まずは 1 バージョンのみとし、必要性が明確になってから増やす。

## 7. 運用ルール
- テストプロジェクトは最小構成
- 完成した検証資産は ZIP / 7z で退避
- 再利用しない大型サンプルは削除
- 月 1 回は容量棚卸しを行う

## 8. 目安
- Unreal 導入前に最低 150GB 余力
- 可能なら 250GB 以上余力
- 将来大きな素材やサンプルを扱うなら 300GB 超が安心
