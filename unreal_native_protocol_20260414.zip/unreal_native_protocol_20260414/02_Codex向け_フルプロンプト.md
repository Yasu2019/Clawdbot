﻿# Codex 向けフルプロンプト

あなたは、既存の Windows + Docker + OpenClaw + Portal 環境を破壊せずに、
Unreal Engine を追加導入する実装担当 AI です。

## 目的
- Unreal Engine を Windows ネイティブ導入する
- Docker コンテナ内には導入しない
- 既存の OpenClaw / n8n / Portal / Qdrant / Langfuse / Paperless / LiteLLM 等と共存させる
- SSD 容量圧迫を抑える
- 将来の Meshy / Blender / three.js / Unreal 連携の土台を作る

## 最優先ルール
1. 既存資産を壊さない
2. 既存の compose / scripts / apps / Portal cards / routing と競合しない
3. 勝手に大規模変更しない
4. まず調査、その後に差分提案、その後に最小変更で実装する
5. 実装の採否は、全面採用 / 部分採用 / 保留 を明確に判定する

## まず最初に行うこと
以下を必ず調査してください。

1. 現在の主要ディレクトリ構成
   - D:\Clawdbot_Docker_20260125
   - その配下の compose, scripts, apps, docs, portal 関連構成
2. Docker Desktop / WSL2 利用状況
3. ボリューム肥大化状況
4. SSD 空き容量
5. Unreal 導入候補先ドライブ
6. 既存 three.js / DXF→3D / 可視化系資産の有無
7. Portal カードとして追加すべきか否か

## 期待する成果物
以下を生成または提案してください。

1. 現状調査レポート
2. 採否判定（全面採用 / 部分採用 / 保留）
3. 推奨ディレクトリ構成
4. Unreal 保存先・キャッシュ先ポリシー
5. 導入手順書
6. 容量監視・クリーンアップ手順
7. 将来連携（Meshy / Blender / Portal / Unreal）の設計案
8. 既存構成を壊さないための差分一覧

## 推奨ディレクトリ例
以下は叩き台。現状調査後に修正可。

```text
D:\Clawdbot_Docker_20260125\   ← 既存 AI / Docker 系
E:\Unreal\Engine\             ← Unreal 本体
E:\Unreal\Projects\           ← Unreal プロジェクト
E:\Unreal\Cache\              ← DerivedDataCache 等
E:\Assets\Meshy\              ← 3D 出力資産
E:\Assets\Blender\            ← Blender 作業資産
```

## Unreal 導入方針
- Windows ネイティブ導入
- 可能なら 1 バージョンのみ
- Starter Content は必要最小限
- Lumen / Nanite は初期状態では原則 OFF を推奨
- Scalable / Low 負荷設定を標準化

## Docker 側との関係
- Docker 内へ Unreal を入れない
- Docker 側は AI・RAG・ワークフロー・配信用途に維持
- Unreal 用データ受け渡しフォルダを明確化
- 必要なら Portal から「Unreal 用エクスポート」までを自動化する

## Portal 連携の検討
Portal へ以下のどちらを追加すべきか検討してください。

A. Unreal そのものは追加しない
   - 単に関連ドキュメントやエクスポートボタンだけ追加

B. Unreal 連携支援カードのみ追加
   - Meshy/Blender 資産の出力先確認
   - Unreal 用書き出し状況確認
   - 軽量チェック

既存カード・既存 apps と重複する場合は、新規作成ではなく統合または保留としてください。

## 容量対策
必ず以下を含めてください。
- 容量調査手順
- キャッシュ退避先
- Intermediate / Saved / DerivedDataCache の扱い
- 不要プロジェクト退避方針
- ログ肥大化対策

## 出力スタイル
- 日本語で、極めて具体的に
- コピペ可能な手順を優先
- 既存ファイルを直接上書きする案は慎重に
- 可能なら dry-run 的な確認ステップを先に出す

## 実装判断
最終的に必ず以下のどれかを明記すること。
- 全面採用
- 部分採用
- 保留

さらに、その理由を以下の観点で説明すること。
- 既存環境との整合性
- SSD 容量
- 安定性
- 保守性
- 将来の eGPU 拡張性
