﻿# Docker / OpenClaw 共存方針

## 1. 絶対方針
Unreal Engine は Docker に入れない。

## 2. 理由
- GPU / GUI / 大容量の観点で Docker 化が重すぎる
- Windows + WSL2 + Docker Desktop の複雑さが増しすぎる
- 既存の AI 基盤を巻き込んで不安定化しやすい

## 3. 役割分担

### Windows ネイティブ
- Unreal Engine
- Blender
- 場合により画像・動画系補助ツール

### Docker 側
- OpenClaw
- Portal
- n8n
- Qdrant
- LiteLLM
- Langfuse
- Paperless / Docling / Infinity 等

## 4. データ受け渡し
受け渡しフォルダを固定すること。

例:
```text
E:\Assets\Meshy\Incoming
E:\Assets\Blender\Working
E:\Assets\Unreal\ImportReady
```

## 5. Portal との関係
Portal には Unreal 本体を載せるのではなく、以下を置くとよい。
- エクスポート状況確認
- 資産の配置確認
- 取り込み前チェック
- 軽量化チェック

## 6. 既存構成優先
既存の DXF→3D や three.js 可視化資産があるなら、Unreal は補助的役割に留める。
「新しいものを入れたから既存を捨てる」という判断は避ける。

## 7. 実装判断の目安
- 既存 Portal と役割重複が大きい → 部分採用
- SSD 余力が乏しい → 保留または最小導入
- 将来的に教育・演出・見せ方の強化価値が高い → 部分採用または全面採用
