﻿# Skill Record Template

## skill_name
short_safe_fix_for_local_config

## intent
ローカル設定修正を、安全に、小さな差分で完了させる。

## trigger
- config修正
- 単一ファイル変更
- テスト可能
- 本番影響なし

## steps
1. まず read-only で現状確認
2. 影響範囲を3行で要約
3. 小さい差分だけ作成
4. テストまたは検証
5. diff要約
6. 次回再利用条件を明記

## avoid
- 一度に複数設定を変えない
- 削除を伴う変更をしない
- 依存関係追加を混ぜない

## promotion_evidence
- total_score
- repeat_count
- reviewer
- approved_date