﻿# Hook Pseudocode

## on_post_tool_use
1. イベント生成
2. files_changed を取得
3. success_flag = true
4. events に保存

## on_post_tool_failure
1. error_type を分類
2. success_flag = false
3. retry_count を更新
4. events に保存

## on_task_finished
1. events を集約
2. score を計算
3. summary を生成
4. 高得点なら skill candidate 作成
5. 人間レビュー待ちへ送る

## on_skill_approved
1. skills/approved に移動
2. CLAUDE.md 追記候補を作る
3. Qdrant に登録
4. 再利用タグを付ける