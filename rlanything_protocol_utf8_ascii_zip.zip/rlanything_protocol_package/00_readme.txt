﻿RLAnything風 自己進化プロトコル
Windowsで文字化けしにくい配布用パッケージ

このZIPは以下の方針で作成しています。
- ファイル名はASCIIのみ
- 本文は UTF-8 with BOM
- 改行は CRLF
- JSON / YAML / Markdown / TXT を同梱
- コピペしやすい雛形を優先

想定対象
- Claude Code
- OpenClaw
- Antigravity
- LiteLLM
- Langfuse
- Qdrant

パッケージ構成
1. 00_readme.txt
   全体説明
2. 01_protocol_master.md
   本格運用プロトコル本文
3. 02_rollout_plan.txt
   段階導入計画
4. 03_folder_structure.txt
   推奨フォルダ構成
5. 04_reward_model_examples.json
   評価ロジック雛形
6. 05_event_log_schema.json
   行動ログスキーマ雛形
7. 06_skill_record_template.md
   スキル化テンプレート
8. 07_hook_pseudocode.md
   フックの疑似コード
9. 08_guardrails.txt
   暴走防止ルール
10. 09_kpi_and_review.txt
    KPIと月次レビュー案

注意
- 本書は「導入判断をAIに委ねる」のではなく、「導入候補を安全に比較検討する」ための設計書です。
- 自動更新は必ず人間承認を挟む前提です。