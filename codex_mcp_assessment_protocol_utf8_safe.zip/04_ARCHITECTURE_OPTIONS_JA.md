# 04 Architecture Options

## Option A: 非導入
- 既存の個別統合を維持

## Option B: 読み取り限定 MCP
- Web 検索
- read-only DB
- メタデータ取得のみ
- 最も現実的な第一候補

## Option C: 承認付き限定書込み MCP
- 下書き保存
- チケット起票
- 非本番更新

## Option D: 広範囲自動化 MCP
- 複数システムへ連鎖的に書込み / 実行
- 現段階では原則非推奨

## 推奨順位
1. Option B
2. Option C
3. Option A
4. Option D

ただし最終判定は Codex に委ねる。
