# 08 Operations Runbook

## 緊急停止
1. MCP Gateway で新規要求を遮断
2. 承認待ちキューを停止
3. 外部接続先トークンを無効化
4. 影響範囲を特定
5. Portal に障害告知
6. 監査ログを保全
7. 復旧判断まで書込み操作を禁止

## 障害分類
- Class A: 危険操作誤実行
- Class B: 誤った外部書込み未遂
- Class C: ログ欠落
- Class D: コスト暴走
- Class E: 外部接続不安定

## 監査ログ最低項目
- request_id
- trace_id
- timestamp
- actor
- model
- tool_name
- target_system
- risk_level
- approval_status
- result_status
- cost_estimate
- duration_ms
