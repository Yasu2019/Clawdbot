# 06 Implementation Backlog

## Epic 1: 判断材料整備
- 資産一覧の作成
- 接続先一覧の作成
- データ分類
- 現行フロー棚卸し
- 導入しない場合の代替案整理

## Epic 2: セキュリティ境界
- Gateway 仕様確定
- Secret 保管方式決定
- Allowlist 設計
- RBAC 設計
- 承認フロー定義

## Epic 3: 監査と観測性
- 監査ログ schema
- trace id 連携
- cost attribution
- failure taxonomy
- alert policy

## Epic 4: 読み取り限定 PoC
- SearXNG read-only
- PostgreSQL read-only
- Paperless metadata read-only
- GitHub read-only candidate
- Safe timeout defaults

## Epic 5: 運用 UI
- Portal 管理画面
- 危険操作一覧
- 承認待ち一覧
- 停止スイッチ
- 失敗率ダッシュボード

## Epic 6: 判定ゲート
- PoC 結果レビュー
- コスト評価
- 誤動作評価
- 継続 / 中止判定
