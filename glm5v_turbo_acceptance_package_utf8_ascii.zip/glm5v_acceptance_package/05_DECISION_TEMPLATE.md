# Decision Template

## Final decision
Choose one:
- REJECT
- SHADOW_PILOT
- ACCEPT_VISION_ONLY
- ACCEPT_LIMITED_PRODUCTION

## Evidence summary
- Vision value:
- Code value:
- Multi-step stability:
- Integration cost:
- Safety / containment:

## Recommended placement in stack
Example:
Use as screenshot observer only.
Do not use as planner.
Do not allow privileged autonomous execution.

## Risks
- Risk 1:
- Risk 2:
- Risk 3:

## Controls
- Control 1:
- Control 2:
- Control 3:

## Concrete next action
Choose the smallest safe next action.
Examples:
- do nothing
- run 10-case shadow pilot
- add one limited LiteLLM route
- restrict to screenshot analysis only

## Final note
Partial adoption is acceptable.
Non-adoption is acceptable.
The goal is stack quality, not model collection.
