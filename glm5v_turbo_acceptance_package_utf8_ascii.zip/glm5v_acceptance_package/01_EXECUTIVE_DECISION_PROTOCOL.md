# Executive Decision Protocol for GLM-5V Turbo

## 1. Objective
Codex must evaluate whether GLM-5V Turbo should be introduced into the user's existing stack as:
- a rejected candidate,
- a shadow pilot,
- a vision-only helper,
- or a limited production component.

This is NOT a mandate to adopt.
This is a structured acceptance review.

## 2. Context
The user's current environment already has a mature multi-provider architecture, including:
- OpenClaw
- LiteLLM routing
- Claude Code
- Codex CLI
- Browser / CDP based execution
- local and cloud model mix
- observability and RAG infrastructure

Therefore, the correct question is NOT:
"Is GLM-5V Turbo interesting?"

The correct question is:
"Does GLM-5V Turbo improve this specific stack enough to justify integration cost, routing complexity, and failure risk?"

## 3. Official positioning to verify against reality
Based on vendor documentation and public positioning, GLM-5V Turbo is presented as:
- a multimodal coding model,
- able to process image / video / text inputs,
- optimized for vision-grounded coding and agent workflows,
- and advertised as working with Claude Code and OpenClaw.

Codex must treat those statements as hypotheses to validate, not as proof of production fitness.

## 4. Default decision bias
Default bias = conservative.

Unless strong evidence is found, the preferred outcome is:
ACCEPT_VISION_ONLY
or
SHADOW_PILOT

The default SHOULD NOT be full adoption.

## 5. Recommended role if accepted
If accepted, the primary recommended role is:

### Vision helper only
Use GLM-5V Turbo for:
- screenshot understanding
- UI layout inspection
- visible error detection
- image-assisted page understanding
- pre-analysis before a stronger reasoning model acts
- visual confirmation after execution

Do NOT use it by default as:
- main planner
- main coder for complex multi-file work
- main agent orchestrator
- final authority for destructive actions
- final authority for business critical judgments

## 6. Decision gates
Codex must judge across the following gates:

### Gate A: Actual vision usefulness
Question:
Does it materially improve screenshot / UI / document-image understanding versus current tools?

Pass condition:
- measurable improvement OR
- materially lower cost with similar quality OR
- unique capability that current stack lacks

### Gate B: Multi-step stability
Question:
Can it reliably participate in a multi-step workflow without frequent derailment?

Pass condition:
- acceptable success rate in controlled scenarios
- failure behavior is predictable
- tool-use errors are containable

### Gate C: Code usefulness
Question:
Is the generated code good enough to save time after review?

Pass condition:
- acceptable structural quality
- acceptable editability
- not just surface-level prettiness

### Gate D: Integration friction
Question:
Can it be integrated into LiteLLM / OpenClaw routing without disproportionate complexity?

Pass condition:
- clean API path
- acceptable auth / quota / latency
- no major collision with current model routing rules

### Gate E: Safety and containment
Question:
If it fails, can the failure be sandboxed?

Pass condition:
- no uncontrolled destructive actions
- no direct promotion to privileged execution without review
- easy rollback

## 7. Strong recommendation logic
Codex should prefer the following mapping:

- If vision is clearly useful, but multi-step stability is weak:
  => ACCEPT_VISION_ONLY

- If vision is useful, stability is moderate, and routing cost is small:
  => SHADOW_PILOT

- If vision, stability, and code usefulness all pass with low friction:
  => ACCEPT_LIMITED_PRODUCTION

- If current stack already covers the same needs with better quality:
  => REJECT

## 8. Mandatory non-adoption triggers
Codex should reject or stop rollout if any of the following are observed:
- repetitive tool-call breakdowns
- unstable multi-step planning
- attractive demos but poor reproducibility
- code that looks plausible but is hard to maintain
- integration complexity larger than the value obtained
- vision quality not meaningfully better than existing models already in stack
- provider reliability / quota / latency unsuitable for actual workflow

## 9. Preferred integration architecture
If adopted, integrate by routing role:

- THINK:
  use stronger reasoning models already available in the stack

- SEE:
  use GLM-5V Turbo selectively for image/screenshot/UI tasks

- ACT:
  use existing execution tools, browser control, Codex CLI, Claude Code, and hardened workflow gates

This means:
Observe -> GLM-5V Turbo
Reason  -> main model
Act     -> tools

## 10. Phased rollout rule
Do not jump from evaluation to full production.

Use this order:
1. offline evaluation
2. shadow pilot
3. limited production
4. broader rollout only if evidence remains positive

## 11. Final decision format
Codex must output:

- Final decision:
  REJECT / SHADOW_PILOT / ACCEPT_VISION_ONLY / ACCEPT_LIMITED_PRODUCTION

- Why:
  concise evidence-based rationale

- Proposed routing:
  exact role in stack

- Risks:
  what may go wrong

- Controls:
  how failures are contained

- Next step:
  smallest safe next action
