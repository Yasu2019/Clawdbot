# Test Plan

## Goal
Determine whether GLM-5V Turbo is worth adding to the current stack.

## Test principle
Compare against the current best available route in the stack, not against marketing claims.

## Track 1: Visual understanding
Run at least 10 cases:
- screenshot with layout break
- screenshot with hidden or disabled button
- dashboard screenshot with anomaly callout
- image-heavy PDF page or scanned document page
- rough hand-drawn UI sketch
- before/after UI diff case

Evaluate:
- correctness
- specificity
- actionability
- hallucination rate

## Track 2: Visual-to-code usefulness
Run at least 5 cases:
- landing page section
- simple dashboard
- settings page
- form page
- card/grid layout

Evaluate:
- code structure
- maintainability
- CSS/layout stability
- amount of manual repair needed

## Track 3: Multi-step tool participation
Run at least 5 cases:
- inspect screenshot -> propose fix -> verify new screenshot
- inspect error screen -> classify issue -> suggest next action
- identify clickable target -> hand off to stronger model/tool controller
- parse visual state -> select next step
- repeat visual confirmation after an action

Evaluate:
- step stability
- handoff quality
- contradiction frequency
- recovery from prior-step error

## Track 4: Integration friction
Check:
- API compatibility
- auth setup
- LiteLLM or equivalent route cleanliness
- logging compatibility
- retry behavior
- timeout handling

## Scoring suggestion
Use 1 to 5 for each area:
- vision quality
- code usefulness
- stability
- latency
- cost efficiency
- integration ease
- safety containment

Interpretation:
- average below 2.5 => REJECT
- strong vision but weak stability => ACCEPT_VISION_ONLY
- average around 3 with manageable risk => SHADOW_PILOT
- sustained 4+ with low friction => ACCEPT_LIMITED_PRODUCTION

## Mandatory deliverables from Codex
Codex should produce:
1. comparison summary
2. routing recommendation
3. failure mode summary
4. final decision
5. rollback instructions if any integration is attempted
