# Source Notes

The following public source positions motivated this package, but they should not override real testing:

1. Z.AI documentation positions GLM-5V-Turbo as a multimodal coding foundation model for vision-based coding tasks, with native support for image / video / text and workflow alignment for agent usage.
2. Z.AI also positions GLM-5 as its flagship text foundation model and positions GLM-5V-Turbo separately as a vision-oriented multimodal coding model.
3. Public OpenClaw materials confirm OpenClaw is an active open-source personal AI assistant ecosystem, making role-based integration a plausible evaluation target.

Practical interpretation:
- Vendor claims justify testing.
- Vendor claims do NOT justify production acceptance by themselves.
- Real stack fit matters more than benchmark or brochure language.
