# Acceptance Checklist

Mark each item as PASS / PARTIAL / FAIL / NOT TESTED.

## 1. Fit for purpose
- [ ] Improves screenshot understanding
- [ ] Improves UI inspection
- [ ] Improves visual debugging
- [ ] Improves image-based pre-check before stronger model execution
- [ ] Adds value not already covered by current main models

## 2. Code usefulness
- [ ] Produces code that is readable
- [ ] Produces code that is maintainable
- [ ] Produces code that is easier to fix than to rewrite
- [ ] Handles visual-to-code tasks acceptably
- [ ] Does not collapse on moderately complex front-end tasks

## 3. Multi-step behavior
- [ ] Follows instructions across multiple steps
- [ ] Uses tools in stable sequence
- [ ] Recovers from one failed step
- [ ] Does not hallucinate tool success
- [ ] Produces consistent results across repeated runs

## 4. Operational quality
- [ ] Latency is acceptable
- [ ] Cost is acceptable
- [ ] Rate limits are acceptable
- [ ] API behavior is stable
- [ ] Logs are observable enough for debugging

## 5. Integration quality
- [ ] Can be added without breaking current routing
- [ ] Can be isolated to vision-specific routes
- [ ] Can be disabled quickly
- [ ] Has clear fallback behavior
- [ ] Does not require privileged trust by default

## 6. Safety and governance
- [ ] Never granted destructive autonomy by default
- [ ] Output is reviewed before system-level changes
- [ ] Sensitive business decisions remain with stronger model or human
- [ ] Rollback steps are documented
- [ ] Use is limited to approved task categories

## 7. Decision rule
Recommended decision:

- Mostly FAIL:
  REJECT

- Vision PASS, stability weak:
  ACCEPT_VISION_ONLY

- Vision PASS, stability moderate, small routing cost:
  SHADOW_PILOT

- Most areas PASS, evidence positive:
  ACCEPT_LIMITED_PRODUCTION
