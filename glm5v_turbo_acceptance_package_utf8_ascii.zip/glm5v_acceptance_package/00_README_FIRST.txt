GLM-5V Turbo Acceptance Package
================================

Purpose
-------
This ZIP is for Codex CLI to decide whether GLM-5V Turbo should be accepted into the user's existing AI stack.

Encoding / anti-mojibake policy
-------------------------------
- All filenames are ASCII only.
- All files are encoded as UTF-8.
- No special characters are used in filenames.
- Keep extraction path short if possible.

Expected output from Codex
--------------------------
Codex should produce ONE final decision:
1. REJECT
2. SHADOW_PILOT
3. ACCEPT_VISION_ONLY
4. ACCEPT_LIMITED_PRODUCTION

Important
---------
Do not adopt blindly.
Do not replace the current main reasoning model with GLM-5V Turbo without passing the tests in this package.
Partial adoption is allowed and preferred.

Suggested review order
----------------------
1. 01_EXECUTIVE_DECISION_PROTOCOL.md
2. 02_ACCEPTANCE_CHECKLIST.md
3. 03_OPENCLAW_INTEGRATION_POLICY.yaml
4. 04_TEST_PLAN.md
5. 05_DECISION_TEMPLATE.md
6. 06_SOURCE_NOTES.md
