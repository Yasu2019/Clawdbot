﻿param(
    [Parameter(Mandatory=$true)][string]$SourceVault,
    [Parameter(Mandatory=$true)][string]$BackupRoot
)

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$dest = Join-Path $BackupRoot ("VaultBackup_" + $timestamp)

New-Item -ItemType Directory -Force -Path $dest | Out-Null
robocopy $SourceVault $dest /E /R:1 /W:1 /NFL /NDL /NJH /NJS /NP

Write-Host "Backup completed:"
Write-Host $dest
