﻿param(
    [Parameter(Mandatory=$true)][string]$SourceFolder,
    [Parameter(Mandatory=$true)][string]$DestFolder,
    [int]$MaxFiles = 20
)

New-Item -ItemType Directory -Force -Path $DestFolder | Out-Null

$files = Get-ChildItem -Path $SourceFolder -Recurse -File -Include *.md |
    Where-Object { $_.FullName -notmatch "\\_ai\\" } |
    Select-Object -First $MaxFiles

foreach ($f in $files) {
    $relativeName = $f.Name
    $dest = Join-Path $DestFolder $relativeName
    Copy-Item $f.FullName $dest -Force
}

Write-Host "Copied $($files.Count) files to $DestFolder"
