﻿# claude.md 追記テンプレート

以下を `claude.md` あるいは Claude 向けの常設指示ファイルへ追記する想定です。

---
## Obsidian knowledge graph rules
- Original notes are source-of-truth and must not be overwritten by default.
- AI-generated support notes must be written only under `_ai/`.
- Prefer reading hub notes under `_ai/hubs/` first when available.
- Use `_ai/insights/` to understand cross-note conclusions.
- Treat `_ai/reports/` as audit trail for what was generated and why.
- Ignore logs, archives, temporary notes, URL dumps, and chat transcripts unless explicitly requested.
- When proposing merges or cleanups, produce recommendations first; do not perform destructive changes automatically.
---

## 日本語版補足
- 元ノートは原本として扱う
- AI生成物は `_ai/` 限定
- まずハブとインサイトを参照
- 破壊的変更は提案止まりにする
