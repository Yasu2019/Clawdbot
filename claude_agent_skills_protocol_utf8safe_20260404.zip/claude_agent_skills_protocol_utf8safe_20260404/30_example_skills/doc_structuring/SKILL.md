---
name: doc-structuring
description: PDFやOCR文書、会議メモを構造化要約し、要点・宿題・リスクを抽出する
---

# Purpose
生文書をそのまま読ませるのではなく、実務で再利用しやすい構造化出力へ変換する。

# Use when
- PDFやOCR文書を短時間で読み解きたい
- 後続のRAG投入前に中間整理したい
- 会議メモから要点、決定事項、宿題を分けたい

# Do not use when
- 元文書の逐語転記が必要
- 法務・契約で1語単位の厳密性が必要
- 原本確認なしで最終判断してはいけない場面

# Inputs
- raw_text
- source_type
- requested_output_format
- optional_context

# Steps
1. 文書の目的を推定する
2. 主題ごとに章立てを再構成する
3. 決定事項、未決事項、宿題、リスクを分離する
4. 数値、日付、責任者候補を抽出する
5. 情報不足点を明示する
6. requested_output_format に合わせて出力する

# Output contract
必ず以下の見出し順に出力する:
1. 文書の要旨
2. 重要ポイント
3. 決定事項
4. 未決事項
5. 宿題 / アクション
6. リスク / 注意点
7. 情報不足

# Safety rules
- 原文にない断定を避ける
- 日付・数値は原文依拠を優先する
- 不明点は推定と明記する
