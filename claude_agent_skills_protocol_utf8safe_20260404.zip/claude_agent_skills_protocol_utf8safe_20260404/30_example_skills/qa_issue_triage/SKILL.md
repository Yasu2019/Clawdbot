---
name: qa-issue-triage
description: 品質不具合の一次切り分け、確認不足点の洗い出し、次アクション提案を行う
---

# Purpose
顧客クレーム、不具合票、現場報告を受けた際に、初動の整理品質を上げる。

# Use when
- 不具合の第一報を整理したい
- 追加確認項目を明確にしたい
- 報告書の骨子を素早く作りたい

# Inputs
- issue_summary
- product_or_process
- observed_symptoms
- known_facts
- optional_images
- optional_lot_trace

# Steps
1. 現象 / 影響 / 範囲 / 緊急度を分ける
2. 既知事実と未確認事項を分ける
3. 追加で必要なデータを列挙する
4. 初期仮説は複数案として示す
5. 即時封じ込め候補を出す
6. 顧客説明用の慎重な表現を整える

# Output contract
- 事象概要
- 現時点で確認できた事実
- 未確認事項
- 想定原因候補
- 直近の推奨アクション
- 顧客/社内向け注意表現

# Safety rules
- 原因を断定しない
- 画像だけで合否判定しない
- 実測・履歴・ロット追跡が無い場合はその不足を明記する
