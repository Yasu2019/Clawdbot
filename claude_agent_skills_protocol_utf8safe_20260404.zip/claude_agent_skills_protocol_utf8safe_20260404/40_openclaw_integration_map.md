# 40. OpenClaw 既存構成との統合マップ

## 1. 基本方針
Claude Agent Skills を OpenClaw の代替にしない。
OpenClaw を司令塔として維持し、Skills は「専門作業ユニット」として使う。

## 2. 推奨アーキテクチャ
### 層構造
1. UI / chat / Portal
2. OpenClaw orchestration
3. policy / supervision / approvals
4. skills layer
5. tools layer (MCP, bash, browser, APIs, Qdrant, Paperless, n8n)
6. model routing layer (LiteLLM / local / cloud)
7. storage / logging / traces

## 3. 役割境界
### Skill に持たせる
- 実行手順
- 出力テンプレート
- 典型失敗パターン
- ドメイン観点

### OpenClaw に持たせる
- どの Skill を呼ぶか
- どのモデルを使うか
- どのツール使用を許可するか
- どこまで自動化するか
- ログと監査性
- 承認フロー

### LiteLLM に持たせる
- モデル選択
- fallback
- コスト管理
- メトリクス

### RAG 層に持たせる
- 参照根拠の取得
- 文書更新追跡
- 参照範囲の切り替え

## 4. 実装時の衝突ポイント
### 衝突1: Skill と CLAUDE.md の役割重複
対策:
- Skill = 再利用可能な専門手順
- CLAUDE.md = プロジェクト固有ルール
- 同じ内容を二重管理しない

### 衝突2: Skill と OpenClaw policy の競合
対策:
- policy は OpenClaw 側を正とする
- Skill 側は助言レベルに留める
- 破壊的操作は必ず OpenClaw 側確認を通す

### 衝突3: Skill の巨大化
対策:
- 1 Skill 1責務に近づける
- 共通テンプレートは shared resource 化
- 複雑な分岐は orchestration 側で吸収

### 衝突4: モデル依存
対策:
- Skill 本文に特定モデル名を書き込みすぎない
- 推奨性能帯だけ示す
- ルーティングは LiteLLM で吸収する

## 5. 推奨導入順
1. 読み取り専用 Skill
2. 下書き生成 Skill
3. 低リスク分析 Skill
4. RAG連携 Skill
5. 承認付き半自動 Skill
6. 破壊的変更を伴う Skill は最後
