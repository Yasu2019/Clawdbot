Claude Agent Skills Protocol Pack (UTF-8 safe)
Generated: 2026-04-04

Purpose:
- Hand-off pack for Codex CLI / Claude Code / OpenClaw design review
- Focuses on practical adoption of Agent Skills for the user's existing system
- Uses ASCII-only file/folder names to reduce mojibake risk

Important honesty note:
- This pack is based on:
  1) the public title/summary of the referenced YouTube video,
  2) Anthropic official documentation for Agent Skills / Claude Code / Agent SDK,
  3) general best-practice synthesis for the user's OpenClaw-style stack.
- It is NOT a verbatim transcript of the video.
- Treat this pack as an implementation protocol and review baseline, not as a line-by-line reproduction.

Suggested reading order:
1. 00_summary_and_scope.md
2. 10_adoption_protocol.md
3. 20_skill_inventory_proposal.yaml
4. 30_example_skills/
5. 40_openclaw_integration_map.md
6. 50_codex_cli_handoff_prompt.md
7. 90_risks_and_review_checklist.md
