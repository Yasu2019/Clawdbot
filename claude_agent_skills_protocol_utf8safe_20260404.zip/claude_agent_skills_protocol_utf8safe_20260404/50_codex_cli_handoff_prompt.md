# 50. Codex CLI への引き継ぎ用プロンプト

以下をそのまま Codex CLI 側へ渡すためのドラフトです。

---
あなたは既存の OpenClaw 系 AI 基盤の設計レビュー担当です。
このZIP内の文書を読み、Claude Agent Skills を現行環境へ導入すべきかを厳密に評価してください。

## 目的
- Claude Agent Skills を全面採用するか、部分採用するか、保留にするかを判断
- 既存 OpenClaw / LiteLLM / Qdrant / n8n / Paperless / Ollama 構成との衝突を検出
- 低リスク高効果の導入順を決める
- 採用しない項目も明示する

## 必須出力
1. Executive summary
2. 採用 / 条件付き採用 / 保留 / 非採用 の4区分
3. 衝突ポイント一覧
4. 既存構成への影響
5. 最小導入プラン
6. 理想導入プラン
7. ロールバック可能な実装順
8. 監視・評価指標
9. 実装時に追加すべきテスト
10. 最終提言

## 厳守事項
- 既存システムを前提に評価すること
- 新規基盤への全面置換を前提にしないこと
- 「Skill」「CLAUDE.md」「MCP」「subagent」「OpenClaw orchestration」の役割を混同しないこと
- 安全性、監査性、運用保守性を重視すること
- 不確実な点は不確実と明記すること

## 特に見てほしい点
- Skill を OpenClaw の上に載せるべきか
- 既存 GCTMS / supervision / approvals との相性
- local LLM と cloud LLM の切り分け方
- 読み取り専用 Skill から始めるべきか
- どの Skill 候補が最も ROI が高いか
- 巨大 Skill 化の危険
- ログ / trace / eval の取り込み方法
---

必要なら、このZIP内の YAML 提案を修正して、採用版 inventory を再生成してください。
