﻿このZIPは、Windows環境での文字化けをできるだけ避けるために次の対策をしています。

1. ZIP内ファイル名を ASCII のみに変更
2. 各 Markdown ファイルを UTF-8 BOM 付きで保存
3. 日本語本文も UTF-8 BOM で保存

推奨:
- Windows標準の展開でも読める可能性が高いです
- それでも文字化けする場合は、VS Code や Notepad++ で UTF-8 として開いてください
