﻿# integration_plan.md

## 目的
既存環境にQMS監査アプリを安全に統合するための実施計画。

## 1. 基本方針
- 既存環境を壊さない
- まずは独立サービスとして最小構成で追加
- 既存OCR / 既存文書取込 / 既存RAG は可能なら再利用
- Rule-only モードを先に完成させる

## 2. 統合戦略
- 文書取り込みは既存基盤を再利用するか判断
- OCRは既存サービスを優先利用
- Qdrant は既存 collection に影響しない新規 collection を使うか、非依存設計にする
- UI は独立 Streamlit とする
- API は独立 FastAPI とする

## 3. 段階導入
### Phase 1
- 独立UI / 独立API / ローカル入力
- 既存環境非破壊

### Phase 2
- 既存 embedding / OCR / 文書基盤と接続

### Phase 3
- Portal統合やn8n連携

## 4. 変更管理
- 既存ファイル上書き前にバックアップ
- 差分記録
- compose 変更点記録
- 追加環境変数一覧を文書化
