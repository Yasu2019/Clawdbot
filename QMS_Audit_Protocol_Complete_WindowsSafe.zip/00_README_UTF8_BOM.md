﻿# QMS Audit Protocol Bundle - Windows Safe

このZIPは、Windows環境での文字化けをできるだけ避けるために、次の対策をしています。

1. ZIP内のファイル名を ASCII のみに変更
2. 各 Markdown ファイルを UTF-8 BOM 付きで保存
3. 内容は完全版プロトコル一式

## 同梱内容
- 00_README_UTF8_BOM.md
- 01_complete_protocol_utf8_bom.md
- 02_claude_code_final_prompt_utf8_bom.md
- 03_existing_system_audit_utf8_bom.md
- 04_conflict_check_report_utf8_bom.md
- 05_integration_plan_utf8_bom.md
- 06_implementation_checklist_utf8_bom.md
- 99_windows_compatibility_note_utf8_bom.md
