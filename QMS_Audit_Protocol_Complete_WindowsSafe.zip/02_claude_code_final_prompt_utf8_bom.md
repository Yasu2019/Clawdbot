﻿# Claude Code へ渡す最終依頼文

あなたは既存のローカルDocker環境に追加実装するシニアPython/AIアプリ開発者です。
目的は、QMS文書群を横断解析し、レビジョン不整合、内容矛盾、帳票名ゆれ、記載項目不足、IATF要求事項観点での不一致候補、監査リスク候補、要確認事項を抽出する日本語UIアプリを構築することです。

## 最重要条件
- 実装開始前に、既存Dockerコンテナ、docker-compose、既存コード、既存文書取込フロー、既存RAG/監査/文書比較アプリを必ず監査してください
- 同様機能が既にある場合、重複実装を避け、再利用または統合案を先に提示してください
- ポート、DB、Qdrant collection、volume、bucket 名の衝突を避けてください
- 既存環境を壊さないでください
- Rule-only モードで主要機能が動くようにしてください
- ローカルLLM依存設計にしないでください
- LLMは補助役に限定してください
- 全文比較をLLMにさせないでください
- LLM出力は JSON 固定にしてください
- サンプルデータとREADMEを含めてください

## 必須機能
1. フォルダ一括取込
2. PDF / DOCX / XLSX / XLS / CSV / TXT 抽出
3. 文書番号抽出
4. Rev抽出
5. タイトル抽出
6. 帳票項目抽出
7. 類似文書グルーピング
8. Rev不整合検出
9. 名称ゆれ検出
10. 手順書 vs 帳票 の不足項目比較
11. 内容矛盾候補抽出
12. 修正提案生成
13. IATF要求事項観点チェック
14. 既存システム監査結果の表示
15. Excel / CSV / HTML エクスポート

## 実装順序
- Phase 1: 非LLM機能 + 既存システム監査
- Phase 2: LLM補助説明
- Phase 3: 最適化

## 先に作るべき文書
- docs/existing_system_audit.md
- docs/conflict_check_report.md
- docs/integration_plan.md

この後、complete_protocol を読んでそれに従って実装してください。
