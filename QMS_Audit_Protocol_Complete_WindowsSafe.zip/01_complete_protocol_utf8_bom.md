﻿# QMS文書矛盾監査アプリ 完全版実装プロトコル

## 1. 目的
本アプリの目的は、1つのフォルダ配下に格納されたQMS文書群を横断解析し、以下を自動抽出することです。

- レビジョン不整合
- 文書名・帳票名のゆれ
- 記載項目不足
- 内容矛盾
- IATF 16949観点での不一致候補・監査リスク候補・要確認事項
- 修正提案
- 既存Docker / 既存コードとの衝突リスク

本アプリは完全自動で正誤を断定するものではなく、一次監査スクリーニング支援ツールとします。最終判断は人が行います。

## 2. 対象文書
- 品質マニュアル
- 規定
- 手順書
- 標準書
- 帳票
- 記録見本
- 参考資料

想定フォルダ構成:
QMS_ROOT/
  01_品質マニュアル/
  02_規定/
  03_手順書/
  04_標準書/
  05_帳票/
  06_記録見本/
  07_参考資料/

サブフォルダは再帰的に走査し、ファイル名だけでなく本文中の文書番号・帳票名・Rev・制定日・改訂日・部署名を優先して識別すること。

## 3. 対応ファイル形式
必須:
- PDF
- DOCX
- XLSX
- XLS
- CSV
- TXT

可能なら対応:
- PPTX
- HTML
- 画像PDF（OCR）

抽出ルール:
- PDFはテキスト抽出優先
- 画像PDFはOCR fallback
- Excelはシート構造・見出し行・帳票項目抽出
- Wordは見出し・表・ヘッダ/フッタも可能なら抽出

## 4. 最重要設計方針
### 4.1 ローカルLLMに丸投げしない
以下はLLM任せにしないこと。
- 文書番号抽出
- Rev抽出
- 制定日 / 改訂日抽出
- 部門名抽出
- 帳票名抽出
- 承認欄有無判定
- 保存期間候補抽出
- Excel帳票の項目抽出
- 同一文書候補の一次グルーピング
- ルールベース矛盾検出

これらは必ずPython側の deterministic なロジックで行うこと。

### 4.2 LLMは補助役に限定
LLMの役割は以下に限定すること。
- ルールベースで検出した差分が実質矛盾か表記ゆれかの補助判定
- 差分内容の日本語要約
- 推奨修正案の文章生成
- IATF監査向けコメント生成
- 要確認理由の自然文生成

### 4.3 まずMVPを完成させる
優先順:
1. 取り込みが安定する
2. メタデータ抽出が再現性高くできる
3. 一覧表が出せる
4. 比較根拠が見える
5. 誤検出でも人が判断しやすい

## 5. 推奨アーキテクチャ
Document Parsing Engine
 -> Structured Extraction Engine
 -> Rule-based Comparison Engine
 -> Candidate Scoring Engine
 -> LLM Assist Layer
 -> Report / UI

層ごとの責務:
A. Parser層
- PDF / DOCX / XLSX / XLS / CSV / TXT 読み込み
- OCR fallback
- 生テキスト、表、セル情報、見出し情報抽出

B. Structured Extraction層
- 文書番号抽出
- Rev抽出
- タイトル抽出
- 帳票名抽出
- 承認欄検出
- 改訂履歴検出
- 保存期間候補抽出
- 部門名候補抽出
- 帳票フィールド一覧抽出

C. Rule-based Comparison層
- 文書番号一致比較
- Rev矛盾検出
- 名称ゆれ候補抽出
- 項目不足検出
- 参照文書整合チェック
- 保存期間差分検出
- 承認欄有無差分検出
- 部門名差分検出

D. Candidate Scoring層
- 重要度スコアリング
- High / Medium / Low分類
- LLMに回す候補の絞り込み

E. LLM Assist Layer
- 実質矛盾かどうかの説明支援
- 修正提案文生成
- 監査コメント生成
- 差分要約

## 6. システム構成方針
推奨構成:
- Frontend: Streamlit
- Backend: FastAPI
- Parser: pdfplumber / pymupdf / python-docx / openpyxl / pandas
- OCR: pytesseract または既存OCRスタック
- Vector/search: Qdrant（必要時）
- Embedding: 既存 embedding サービス流用
- Storage: SQLite または Postgres
- Output: HTML / Excel / CSV / JSON / PDF

コンテナ案:
- qms_audit_api
- qms_audit_ui
- qms_audit_worker

既存 Qdrant / embedding / gateway がある場合はできるだけ共用すること。

## 7. 実装前の既存システム監査（必須）
新規実装前に、Dockerコンテナ内および既存リポジトリに同様機能が既にないか必ず確認すること。
必須確認項目:
- 既存 docker-compose.yml / compose.*.yml の確認
- 既存 Dockerfile の確認
- 稼働中コンテナ一覧の確認
- 使用中ポート一覧の確認
- 既存 Streamlit / FastAPI / OCR / RAG / 文書解析サービスの確認
- 既存Qdrant collection の確認
- 既存文書取込フローの確認
- 既存の類似アプリの確認

衝突回避ルール:
- 同機能が既にある場合は再実装せず、再利用・統合を検討する
- 新規ポートは未使用番号を割り当てる
- 既存DBに直接破壊的変更を加えない
- 既存 collection / bucket / volume 名と衝突しない命名を使う
- 既存 worker / queue と責務が重なる場合は統合案を先に出す
- 既存コードを削除する前にバックアップと差分説明を作る

実装開始前に必ず作る資料:
- existing_system_audit.md
- conflict_check_report.md
- integration_plan.md

## 8. 文書インデックス機能
抽出メタデータ:
- file_path
- file_name
- extension
- folder_category
- detected_document_type
- detected_title
- detected_document_number
- detected_revision_raw
- detected_revision_normalized
- detected_issue_date
- detected_update_date
- detected_department
- detected_owner
- detected_approval_role
- detected_form_name
- detected_related_process
- text_length
- parse_confidence
- ocr_used

detected_document_type 候補:
- 品質マニュアル
- 規定
- 手順書
- 標準書
- 帳票
- 記録見本
- その他

## 9. 文書構造抽出機能
マニュアル・規定・手順書系:
- 章番号
- 見出し
- 責任部署
- 用語定義
- 実施手順
- 記録要求
- 保存期間
- 参照文書
- 使用帳票
- 承認フロー
- 改訂履歴

帳票系:
- 帳票名
- 帳票番号
- Rev
- 記載欄名
- 必須 / 任意らしき項目
- 承認欄
- 作成者欄
- 部門欄
- 日付欄
- ロット欄
- 判定欄
- 保存先 / 保管年限
- 備考欄
- 参照元文書

## 10. 類似文書グルーピング機能
グルーピング条件:
- 文書番号一致
- 帳票番号一致
- タイトル類似
- ファイル名類似
- 本文冒頭類似
- 項目構造類似
- ベクトル類似（必要時）

## 11. 矛盾検出機能
A. レビジョン矛盾
- 同じ文書番号でRevが複数存在
- 同一フォルダに旧版らしきものが残っている
- 規定ではRev.5を参照しているが、帳票はRev.3ベース

B. 名称ゆれ
- 内部監査是正処置報告書 / 内部監査 是正処置報告書
- 品証部 / 品質保証部
- 承認者 / 承認 / 責任者承認

C. 記載項目不足
- 手順書に必要な記録欄が帳票に存在しない
- マニュアルで保存期間要求があるのに帳票に記載なし
- 承認要件があるのに承認欄なし

D. 内容矛盾
- 責任部署が文書ごとに違う
- 記録保存年限が違う
- フロー順番が違う
- 判定基準が違う
- 用語定義が異なる

E. 参照文書矛盾
- 廃止済らしき文書を参照
- 存在しない文書番号を参照
- 参照先名称が不完全

F. 怪しい文書
- Rev不明
- 改訂履歴なし
- 文書番号なし
- 承認者なし
- 制定 / 改訂日のどちらか欠落
- ファイル名と本文タイトルが不一致
- 帳票名に対して項目数が極端に少ない

## 12. リスク評価機能
High:
- 上位文書と下位文書の直接矛盾
- 承認要件欠落
- 保存年限矛盾
- 判定基準矛盾
- 使用帳票誤参照
- Rev不一致で運用誤りの可能性大
- IATF要求との不一致候補

Medium:
- 名称ゆれ
- 部署名ゆれ
- 文言差異
- 改訂履歴不足
- 監査リスク候補

Low:
- 表記ゆれ
- 空白や見た目上の差異
- 軽微な用語差
- 要確認

## 13. 手順書 vs 帳票 不足項目比較エンジン（必須コア機能）
目的:
手順書・規定・標準書で要求されている記録項目が、実際の帳票に存在するかを検証する。

入力:
- 手順書 / 規定から抽出した記録要求
- 帳票から抽出したフィールド一覧

手順書側抽出対象:
- 記録する
- 記入する
- 管理する
- 保存する
- トレースする
- 記録を残す
- ログを取る
- 記録様式

出力JSON:
{
  "type": "missing_field",
  "document_procedure": "",
  "document_form": "",
  "required_field": "",
  "found_in_form": false,
  "closest_field": "",
  "risk": "",
  "severity": "High|Medium|Low"
}

禁止事項:
- LLMだけで判断しない
- 必ず項目リスト同士で比較する

## 14. 内容矛盾検出エンジン（コア機能）
対象比較:
- 品質マニュアル vs 規定
- 規定 vs 手順書
- 手順書 vs 帳票
- 同一帳票のRev違い

比較対象項目:
- 責任部署
- 承認者
- 保存期間
- 判定基準
- フロー順序
- 使用帳票
- 用語定義

出力JSON:
{
  "type": "content_inconsistency",
  "field": "",
  "document_a": "",
  "document_b": "",
  "value_a": "",
  "value_b": "",
  "difference_type": "",
  "severity": "",
  "confidence": 0.0
}

difference_type:
- 明確矛盾
- 解釈差
- 表記ゆれ
- 要確認

ロジック順序:
1. ルール比較
2. 正規化比較
3. 類似度比較
4. ここで初めてLLM

## 15. 修正提案生成エンジン（LLM補助）
トリガー条件:
- severity = High
- またはユーザーが詳細表示した場合

出力JSON:
{
  "proposal_type": "",
  "recommended_action": "",
  "target_document": "",
  "priority": "",
  "reason": ""
}

proposal_type:
- 統一
- 追記
- 修正
- 削除
- 要確認

禁止事項:
- 抽象的な提案
- 根拠なし提案
- 全ケースでLLM呼び出し

## 16. IATF要求事項整合チェック機能（必須）
目的:
品質マニュアル、規定、手順書、帳票、記録見本の内容が、IATF 16949 の要求事項観点で不整合・不足・曖昧さを持っていないかを検出する。

出力区分:
- IATF要求との不一致候補
- IATF監査上のリスク候補
- IATF観点で要確認

チェック対象例:
- 文書管理
- 記録管理
- 承認と改訂管理
- 変更管理
- 責任・権限の明確化
- トレーサビリティ
- 不適合管理
- 是正処置
- 内部監査
- 教育訓練
- 測定機器管理
- 製造工程管理
- 外部提供者管理

入力:
- IATF要求事項マスタ
- 品質マニュアル抽出結果
- 規定抽出結果
- 手順書抽出結果
- 帳票項目抽出結果
- 記録見本抽出結果

出力JSON:
{
  "type": "iatf_alignment_issue",
  "clause": "",
  "category": "",
  "document_id": "",
  "document_name": "",
  "issue_level": "不一致候補|監査リスク候補|要確認",
  "summary": "",
  "missing_or_conflicting_element": "",
  "evidence": "",
  "recommendation": "",
  "confidence": 0.0
}

断定禁止:
- 「IATF違反である」と断定しない
- 条文適合を100%自動判定したように見せない
- 根拠なしで不適合扱いしない

## 17. LLM使用制限
LLMに回してよいもの:
- 表現差が同義かどうか
- 承認責任者表現の補完関係か矛盾か
- 手順書と帳票の文脈差分の説明
- 監査指摘風コメント生成
- 修正案文章の生成

LLMに回してはいけないもの:
- 全文同士比較
- Rev抽出
- 文書番号抽出
- Excel列構造の初回解析
- 旧版新版の一次判定
- OCR結果の生整形だけにLLMを使うこと

全文投入禁止:
品質文書全文を毎回LLMに投げて比較しないこと。
必ず対象箇所抜粋、比較項目名、抽出済みメタデータ、ルールベース判定結果に縮約してから渡すこと。

LLM出力はJSON固定:
{
  "judgement": "矛盾候補|表記ゆれ候補|要確認",
  "summary": "",
  "reason": "",
  "recommendation": "",
  "confidence": 0.0
}

## 18. 正規化・抽出ロジック
Rev抽出例:
- Rev.1
- Rev 1
- R1
- 改訂A
- 第3版
- 第2改訂
- 版数4

文書番号抽出例:
- QP-001
- QMS-8.5-02
- FRM-123
- QC-監-01
- 内監-報-02

名称ゆれ判定:
- 全角半角正規化
- 空白除去
- 記号除去
- 類義語辞書
- 日本語形態素類似
- embedding類似（必要時）

## 19. データ設計案
documents:
- id
- file_path
- file_name
- doc_type
- title
- document_number
- revision_raw
- revision_normalized
- issue_date
- update_date
- department
- owner
- text_content
- parsed_json
- created_at

document_fields:
- id
- document_id
- field_name
- field_label
- field_type
- field_required_guess
- source_location

document_relations:
- id
- source_document_id
- target_document_id
- relation_type
- confidence

inconsistencies:
- id
- type
- severity
- document_a_id
- document_b_id
- field_name
- summary
- evidence_a
- evidence_b
- recommendation
- confidence
- status

iatf_issues:
- id
- clause
- category
- document_id
- issue_level
- summary
- missing_or_conflicting_element
- evidence
- recommendation
- confidence

## 20. 出力仕様
ダッシュボード:
- 総文書数
- 文書種別ごとの件数
- Rev不整合件数
- 名称ゆれ件数
- 記載項目不足件数
- 内容矛盾件数
- 怪しい文書件数
- IATF関連指摘件数
- 優先度High件数

必須画面:
1. 取り込み画面
2. 解析実行画面
3. 結果一覧画面
4. 矛盾詳細画面
5. 文書詳細画面
6. IATF整合チェック画面
7. エクスポート画面
8. 設定画面
9. 既存システム監査結果画面

UI要件:
- 日本語UI
- 進捗表示
- エラー内容明示
- 根拠箇所ハイライト
- 候補であり断定ではないことを明示

## 21. モード設計
モードA: Rule-only
- 完全非LLM
- 最速
- 一次スクリーニング用

モードB: Rule + Local LLM Assist
- ローカルLLMで補助説明
- 通常運用用

モードC: Rule + External / High-grade LLM Assist
- 必要時のみ上位モデル利用
- 最終確認用

LLM停止時でもアプリが成立すること。

## 22. 実装優先順位
Phase 1:
- 文書取り込み
- テキスト抽出
- メタデータ抽出
- 帳票項目抽出
- 文書一覧
- Rev一覧
- 文書番号一覧
- 類似文書候補一覧
- 基本矛盾一覧
- 既存システム監査

Phase 2:
- 差分要約
- 表記ゆれ / 矛盾候補の補助説明
- 推奨修正案
- 監査コメント

Phase 3:
- キャッシュ
- 非同期ワーカー
- バッチ判定
- スコア最適化
- モデル切替設定
- n8n連携 / 定期実行

## 23. 推奨ディレクトリ構成
qms_audit_app/
  app/
    main.py
    config.py
    ui/streamlit_app.py
    api/routes.py
    parsers/
    extractors/
    normalizers/
    comparators/
    scorers/
    llm/
    reports/
    storage/
    utils/
  data/
  dictionaries/
  docs/
  tests/
  Dockerfile
  docker-compose.yml
  requirements.txt
  README.md

## 24. 初期辞書
synonyms_department.json:
- 品質保証部 = 品証部
- 製造部 = 製造課
- 技術部 = 技術課

synonyms_field.json:
- 承認者 = 承認 = 最終承認者
- 作成日 = 記載日 = 作成年月日
- ロット = LOT = 製造ロット

suspicious_patterns.json:
- 改訂履歴なし
- Revなし
- 承認欄なし
- 文書番号なし
- 参照先不明
- 保存期間未記載
- 責任部署未記載

## 25. READMEに必ず書くこと
- 起動手順
- 入力フォルダの置き場所
- 対応ファイル形式
- OCR時の制限
- 誤検出が起きやすい例
- AI提案は最終判断ではないこと
- ログ保存場所
- レポート出力場所
- 既存Docker / 既存コード監査を先に行うこと
- 衝突確認手順

## 26. 開発者向け禁止事項
1. LLMに全ファイル全文比較をさせること
2. ルール抽出前にLLMへ丸投げすること
3. 抽出・比較・提案をすべて1プロンプトで済ませること
4. LLM自由文をそのまま最終判定にすること
5. 根拠のない断定表現を出すこと
6. ローカルLLM必須設計にすること
7. 既存コンテナ / 既存機能を確認せず新規実装を始めること
8. 既存ポート・既存DB・既存Qdrant collection に無確認で接続すること
