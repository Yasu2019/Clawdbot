﻿# Conflict Checklist

## 必須確認
- [ ] 既存Composeで agent / loop / tool / workflow 相当が存在しないか
- [ ] 既存Portal card 名称重複がないか
- [ ] 既存 route と競合しないか
- [ ] Langfuse trace を二重送信しないか
- [ ] LiteLLM の既存モデル命名規約と衝突しないか
- [ ] n8n と役割が重複しないか
- [ ] MCP server のツールレジストリと二重管理にならないか
- [ ] 既存 RAG 検索器と責務競合しないか
- [ ] bearer token / env 名が重複しないか
- [ ] rollback が容易か

## 判断基準
### Adopt
- 明確な空白領域あり
- 競合小
- テスト容易

### Partial
- 既存機能あり
- ただし局所改善余地あり

### Hold
- 重複が大きい
- 利得が小さい
- 既存構成を壊す恐れが高い
