﻿# Caveman Minimal Agent Protocol (JP)

このZIPは、OpenClaw / LiteLLM / n8n / Qdrant / Langfuse を既に保有している環境に対し、
「重い全部入りフレームワークを追加する」のではなく、
**薄い ReAct ループ**で再構成するためのプロトコルです。

## 目的
- デバッグ容易化
- トークン浪費の抑制
- モデル差し替え容易化
- 既存Portal / card / workflowとの衝突回避
- Codex / Claude / Antigravity が採用可否を自律判断しやすい形で提示

## 基本方針
1. フレームワーク依存を最小化する
2. ループは単純化する
3. ツール実行結果は必ずログ化する
4. 状態は可能な限り外部化する
5. 既存機能と競合する場合は「全面採用」ではなく「部分採用」を許容する
6. Portal / Compose / app card / route の重複を必ず精査する

## 同梱物
- 01_EXECUTIVE_SUMMARY_JP.md
- 02_PROTOCOL_FOR_CODEX_JP.txt
- 03_PROTOCOL_FOR_CLAUDE_JP.txt
- 04_IMPLEMENTATION_BLUEPRINT_TS.md
- 05_CONFLICT_CHECKLIST_JP.md
- 06_FILE_TREE.txt
- 07_SAMPLE_TYPESCRIPT_AGENT.ts
- 08_ACCEPTANCE_REPORT_TEMPLATE_JP.md

## 文字化け対策
- ファイル名は英数字 + underscore
- テキストは UTF-8 with BOM
- 改行は LF
- ZIP内の日本語は本文のみ
