﻿# Implementation Blueprint (TypeScript)

## 1. 最小構成
- `src/agent/loop.ts`
- `src/agent/types.ts`
- `src/agent/tool-registry.ts`
- `src/agent/llm-adapter.ts`
- `src/agent/trace.ts`
- `src/agent/run.ts`

## 2. ループ定義
```ts
while (!done && steps < maxSteps) {
  const llmOutput = await callModel(messages, tools);
  if (llmOutput.toolCall) {
    const result = await runTool(llmOutput.toolCall);
    messages.push({ role: "tool", content: JSON.stringify(result) });
    continue;
  }
  done = true;
  return llmOutput.finalAnswer;
}
```

## 3. 設計原則
- 1責務1モジュール
- 明示ログ
- 非同期処理を隠さない
- 失敗時は即座に trace へ出す
- provider 固有仕様は adapter に閉じ込める

## 4. OpenClaw環境への差し込み方
- 既存 gateway を置換しない
- 新しい route を乱立させない
- 実験用 card / endpoint は `/apps/labs/` 配下など隔離
- 本採用前に Langfuse trace の見え方を確認
- LiteLLM の既存モデルルーティングを尊重

## 5. 想定ユースケース
- 軽量ツールオーケストレーション
- 単純な ReAct 型タスク
- ローカルLLM実験
- 内部向け補助エージェント

## 6. 向かないケース
- 複雑なマルチエージェント分業を最初から全部乗せすること
- 大規模状態遷移管理をフレームワークに丸投げすること
