﻿export type ChatMessage = {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
};

export type ToolCall = {
  name: string;
  args: Record<string, unknown>;
};

export type LlmResponse = {
  finalAnswer?: string;
  toolCall?: ToolCall;
};

export type ToolHandler = (args: Record<string, unknown>) => Promise<unknown>;

export class ToolRegistry {
  private tools = new Map<string, ToolHandler>();

  register(name: string, handler: ToolHandler) {
    this.tools.set(name, handler);
  }

  async run(call: ToolCall): Promise<unknown> {
    const handler = this.tools.get(call.name);
    if (!handler) throw new Error(`Tool not found: ${call.name}`);
    return handler(call.args);
  }
}

export async function callModel(messages: ChatMessage[]): Promise<LlmResponse> {
  const last = messages[messages.length - 1]?.content ?? "";
  if (last.includes("time")) {
    return { toolCall: { name: "get_time", args: {} } };
  }
  return { finalAnswer: "Done." };
}

export async function runAgent(initialUserInput: string) {
  const messages: ChatMessage[] = [
    { role: "system", content: "You are a minimal ReAct-style agent." },
    { role: "user", content: initialUserInput },
  ];

  const tools = new ToolRegistry();
  tools.register("get_time", async () => ({ now: new Date().toISOString() }));

  let steps = 0;
  const maxSteps = 8;

  while (steps < maxSteps) {
    steps += 1;
    const out = await callModel(messages);

    if (out.toolCall) {
      const result = await tools.run(out.toolCall);
      messages.push({
        role: "tool",
        content: JSON.stringify({ tool: out.toolCall.name, result }),
      });
      continue;
    }

    if (out.finalAnswer) {
      return { answer: out.finalAnswer, messages, steps };
    }
  }

  throw new Error("Max steps exceeded.");
}
