# Docker Integration Notes

- Connect to existing OpenClaw containers
- Use LiteLLM proxy (port 4000)
- Connect Qdrant (port 6333)
- Use Langfuse for tracing
