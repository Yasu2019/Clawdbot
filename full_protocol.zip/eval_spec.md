# Evaluation Specification

## Gmail Extraction
- precision
- recall
- deadline_detection_rate
- false_positive_rate

## RAG
- groundedness
- relevance
- latency
- cost

## Auto Research
- improvement_rate
- regression_rate
- rollback_frequency
