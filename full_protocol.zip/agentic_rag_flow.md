# Agentic RAG Flow

1. Define info need
2. Search initial
3. Evaluate result
4. Rewrite query if needed
5. Search again
6. Aggregate sources
7. Return structured output
