# n8n Flow Hint

- Gmail Trigger
- Extract node (Python/FastAPI)
- RAG query
- Draft generator
- Approval step
