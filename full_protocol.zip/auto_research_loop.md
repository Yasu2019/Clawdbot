# Auto Research Loop

Observe -> Detect -> Hypothesize -> Research -> Propose -> Try -> Evaluate -> Promote -> Accumulate
