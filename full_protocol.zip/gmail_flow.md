# Gmail Request Extraction Flow

1. Monitor incoming emails
2. Extract:
   - request
   - deadline
   - required response
3. Run Agentic RAG for similar cases
4. Generate draft reply
5. Store to memory
