# Stitch への実務プロンプト集

## 1. Portal Observability Hub
Create a desktop-first operations dashboard for an AI platform.
Show service health, latest traces, token cost trend, model latency, failure count, and alerts.
Use a dense but readable layout for engineers. Include filters, recent incidents, and drill-down panels.
Design for a dark sidebar and a clean main content area. Prioritize clarity over decoration.

## 2. Injection Molding Hub
Create a manufacturing dashboard for injection molding quality monitoring.
Show machine status, first injection time, first pressure, warning/alarm thresholds, lot comparison, histograms, and trend charts.
Design for quality engineers on large desktop monitors in a factory office.
Use tabs for machine overview, lot analysis, threshold management, and abnormal event review.

## 3. IATF Audit Board
Create an internal audit management dashboard for IATF 16949.
Show 3-year audit plan, process owner, product risk, claim history, status, due dates, and evidence links.
The UI must be businesslike, compact, and suitable for Japanese manufacturing companies.

## 4. Motion Analysis App
Create a web UI for motion analysis based on MOST and Therbligs.
Allow video upload, timeline playback, skeleton overlay, motion segmentation, wasted motion flags, and cycle time summary.
The target users are industrial engineers and line leaders.

## 5. OCR Review Screen
Create a document review interface for OCR and AI extraction.
Show original page image, extracted text, confidence score, correction pane, structured fields, and approval workflow.
The UI should optimize side-by-side comparison and fast correction.

## 6. CAE Result Viewer
Create an engineering dashboard for simulation results.
Show mesh summary, parameter panel, contour preview, min/max values, run history, and downloadable reports.
Target users are CAE engineers working on desktop browsers.
