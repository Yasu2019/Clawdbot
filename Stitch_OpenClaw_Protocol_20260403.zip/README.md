# ZIP内容

- `00_Stitch_OpenClaw_導入プロトコル.md`
- `01_CodexCLI_評価指示書.md`
- `02_Stitch_実務プロンプト集.md`
- `03_評価レポートテンプレート.md`

文字化けを避けるため、UTF-8 の Markdown で保存。
