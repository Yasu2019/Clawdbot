﻿# n8n 連携メモ

## 推奨フロー
1. Webhook で日本語プロンプト受信
2. prompt orchestrator に POST
3. 応答JSONを保存
4. 生成結果パスをDB or JSONLへ記録
5. 成功時はPortal更新または通知
6. 失敗時はログ収集して再実行キューへ
