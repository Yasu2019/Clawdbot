﻿ComfyUI 完全実装版プロトコル一式
作成日: 2026-04-12

目的
- 既存 OpenClaw / Docker / Portal / n8n 環境へ、ComfyUI 系の生成基盤を後付け導入する
- 既存構成を破壊せず、段階導入できる形にする
- Codex / Claude / Antigravity が、このZIPを読んで採否判定と実装差分設計を行えるようにする

文字化け対策
- すべて UTF-8 with BOM
- 改行は CRLF
- ファイル名は英数字中心

重要
- このZIPは「全面採用前提」ではない
- 受領側は必ず既存ポート、既存Compose、既存Portalカード、既存GPU使用状況を確認すること
- 既存ファイルの直接上書きは禁止
- override または新規フォルダ追加を優先すること
