﻿# 運用・障害対応

## 初回確認
- docker compose ps
- GPU が見えているか
- 127.0.0.1:18188 へアクセスできるか
- 127.0.0.1:18189/health が返るか
- volume に output が作られるか

## よくある問題
1. GPU未認識
2. モデル置き場誤り
3. custom_nodes 依存不整合
4. reverse proxy 未設定
5. Portal 側のCORS・URL固定ミス
6. 生成履歴が残らない
