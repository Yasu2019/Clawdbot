﻿# API 呼び出し例

## 生成要求
POST http://127.0.0.1:18189/generate
Content-Type: application/json

{
  "task_type": "image",
  "prompt_ja": "アルミプレス部品の小さな打痕を高解像度で再現",
  "negative_prompt": "blurry, low quality",
  "width": 1024,
  "height": 1024,
  "steps": 20,
  "seed": 0
}

## ヘルスチェック
GET http://127.0.0.1:18189/health
