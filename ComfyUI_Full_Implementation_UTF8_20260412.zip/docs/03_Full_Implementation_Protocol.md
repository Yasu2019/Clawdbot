﻿# ComfyUI 完全実装版プロトコル

## 1. 想定構成
```text
[User]
  ↓
[Portal / OpenClaw / n8n]
  ↓
[Prompt Orchestrator]
  ├─ Qwen系LLM: 日本語解釈・英文化・詳細化
  └─ ComfyUI API: 実生成
        ├─ Flux
        ├─ Stable Diffusion系
        ├─ Wan2.1
        ├─ Qwen TTS
        └─ Hunyuan3D
```

## 2. 役割分担
### OpenClaw / Portal
- 指示入力
- 実行種別判定
- 保存先や履歴の管理
- 生成結果のリンク表示

### n8n
- 定型自動化
- 失敗時の通知
- 生成ジョブの前後処理

### Prompt Orchestrator
- 日本語入力の標準化
- 英語プロンプトへの変換
- モデル別のプロンプト整形
- NGワード／危険入力フィルタ

### ComfyUI
- ワークフロー実行
- 画像・動画・音声・3Dの生成
- 出力ファイル作成

## 3. 導入方針
- 既存構成に新規フォルダで差し込む
- 既存 compose は原則そのまま
- 新規 compose または compose override を用意
- bind は 127.0.0.1 を優先
- volume を明示
- logs を明示
- healthcheck を入れる
