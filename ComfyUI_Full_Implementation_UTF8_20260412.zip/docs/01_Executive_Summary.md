﻿# ComfyUI 完全実装版 要約

## 目的
既存の OpenClaw / Portal / n8n / Docker 資産に対して、ComfyUI ベースの画像・動画・音声・3D生成機能を
安全に追加できる雛形を提供する。

## 優先順位
1. Qwen による日本語→英語プロンプト補助
2. ComfyUI 本体
3. Flux または SD系のどちらか1系統
4. Wan2.1
5. Qwen TTS
6. Hunyuan3D

## このZIPの方針
- 既存構成を壊さない
- まずは最小差分
- Portal統合は後付け可能
- n8n と OpenClaw は司令塔
- ComfyUI は生成専用
