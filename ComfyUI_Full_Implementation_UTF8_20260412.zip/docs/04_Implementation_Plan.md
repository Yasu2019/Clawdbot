﻿# 実装計画書

## 最小実装
- ComfyUI コンテナ
- prompt orchestrator コンテナ
- 画像生成のみ
- Portalカード1枚
- API動作確認

## 標準実装
- 最小実装
- Wan2.1
- Qwen TTS
- n8n webhook 連携
- 実行履歴JSON保存

## 拡張実装
- 標準実装
- Hunyuan3D
- モデル切替UI
- 生成履歴一覧
- 失敗時再実行導線
