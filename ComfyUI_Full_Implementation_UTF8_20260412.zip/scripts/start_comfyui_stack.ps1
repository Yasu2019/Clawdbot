﻿docker compose --env-file .\env\.env -f .\compose\docker-compose.comfyui.yml up -d
