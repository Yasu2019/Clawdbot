﻿Write-Host "Checking ComfyUI..." -ForegroundColor Cyan
try {
  $r = Invoke-WebRequest -Uri "http://127.0.0.1:18188" -UseBasicParsing -TimeoutSec 10
  Write-Host "ComfyUI OK: $($r.StatusCode)" -ForegroundColor Green
} catch {
  Write-Host "ComfyUI NG: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "Checking Orchestrator..." -ForegroundColor Cyan
try {
  $r = Invoke-WebRequest -Uri "http://127.0.0.1:18189/health" -UseBasicParsing -TimeoutSec 10
  Write-Host "Orchestrator OK: $($r.StatusCode)" -ForegroundColor Green
  Write-Host $r.Content
} catch {
  Write-Host "Orchestrator NG: $($_.Exception.Message)" -ForegroundColor Red
}
