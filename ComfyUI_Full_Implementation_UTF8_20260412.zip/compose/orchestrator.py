﻿from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional, Literal
import os
import json
from datetime import datetime

app = FastAPI(title="Comfy Prompt Orchestrator")

COMFYUI_BASE_URL = os.getenv("COMFYUI_BASE_URL", "http://comfyui:8188")

class GenerateRequest(BaseModel):
    task_type: Literal["image", "video", "audio", "3d"]
    prompt_ja: str
    negative_prompt: Optional[str] = ""
    width: Optional[int] = 1024
    height: Optional[int] = 1024
    steps: Optional[int] = 20
    seed: Optional[int] = 0

def build_prompt(prompt_ja: str, task_type: str) -> str:
    prefix = {
        "image": "Create a detailed English prompt for high quality image generation based on this Japanese request: ",
        "video": "Create a detailed English prompt for high quality video generation based on this Japanese request: ",
        "audio": "Create a detailed English prompt for text to speech or voice generation based on this Japanese request: ",
        "3d": "Create a detailed English prompt for 3D model generation based on this Japanese request: ",
    }[task_type]
    return prefix + prompt_ja

def log_json(obj, name="request_log.jsonl"):
    os.makedirs("logs", exist_ok=True)
    with open(os.path.join("logs", name), "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\\n")

@app.get("/health")
def health():
    return {"ok": True, "comfyui": COMFYUI_BASE_URL}

@app.post("/generate")
def generate(req: GenerateRequest):
    prompt_en = build_prompt(req.prompt_ja, req.task_type)
    log_json({
        "ts": datetime.now().isoformat(),
        "request": req.model_dump(),
        "prompt_en": prompt_en
    })
    return {
        "status": "stub_ready",
        "message": "Replace with model-specific ComfyUI workflow JSON before production use.",
        "prompt_en": prompt_en,
        "comfyui_base_url": COMFYUI_BASE_URL
    }
