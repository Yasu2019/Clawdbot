# 導入チェックリスト
- [ ] AGENTS.md を追加した
- [ ] 承認マトリクスを作成した
- [ ] dry-run 手順を用意した
- [ ] lint / test / typecheck を自動化した
- [ ] 変更ログ保存先を決めた
- [ ] rollback 手順を書いた
- [ ] 既存サービス名との衝突を確認した
- [ ] UTF-8 / ASCII 主体ファイル名に統一した
- [ ] 本番相当操作は approval gate 化した
