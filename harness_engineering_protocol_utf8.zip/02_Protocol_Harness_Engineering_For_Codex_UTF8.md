# 文字化けしにくい形式プロトコル
ファイル名: `Protocol_Harness_Engineering_For_Codex_UTF8.md`

## 目的
既存の OpenClaw / LiteLLM / Qdrant / n8n / Codex / Claude / Antigravity 環境に、
ハーネスエンジニアリングの考え方を後付けではなく**運用ルールとして組み込む**。

## 最重要原則
1. AIに自由を与えすぎない
2. ルールはプロンプトだけでなく、ファイル・CI・スクリプトで強制する
3. 失敗前提で、ロールバックと監査証跡を残す
4. 人間承認が必要な操作を明確化する
5. モデル性能より、環境設計を重視する

## 推奨役割分担
- Antigravity: 上位設計、要件整理、統合方針
- Codex: 実装、修正、テスト追加
- Claude: レビュー、文章品質、危険変更検出
- OpenClaw: 司令塔、状態管理、ルーティング
- LiteLLM: モデル選択とコスト監視
- n8n: 定型ジョブ・通知・承認フロー
- Qdrant: RAG、ナレッジ参照
- Langfuse 等: 観測・失敗分析

## 導入手順
### Phase 1: ルール固定
以下をリポジトリ直下へ追加
- `AGENTS.md`
- `CLAUDE.md`
- `.editorconfig`
- `Makefile`
- `scripts/check.sh`
- `docs/architecture/BOUNDARIES.md`
- `docs/runbooks/FAILURE_RECOVERY.md`

### Phase 2: 実行ガード
エージェントに許可する操作を3段階に分ける
- Level 1: 読み取り専用
- Level 2: ローカル編集可
- Level 3: 外部接続・本番変更（人間承認必須）

### Phase 3: 自動検証
最低限必須
- format
- lint
- typecheck
- unit test
- smoke test
- artifact validation

### Phase 4: 観測
記録すべき項目
- 実行開始 / 終了時刻
- 使用モデル
- 入出力トークン
- 実行コマンド
- 変更ファイル一覧
- テスト結果
- 失敗理由
- 再試行回数
- 人間承認有無

### Phase 5: 復旧
失敗時は以下を強制
1. 変更差分保存
2. ログ保存
3. 原因分類
4. ロールバック
5. 再実行条件確認

## Codex に渡す実装指示
### 指示本文（そのまま貼り付け可）
あなたは既存の OpenClaw 系ローカルAI基盤に対して、Harness Engineering を導入する。
目的は、AIエージェントの自由度を保ちながらも、安全性、再現性、監査性、保守性を大幅に上げること。

必須要件:
1. 既存構成を壊さない
2. 追加物は docs / scripts / config を中心に段階導入する
3. 変更は必ず dry-run 可能にする
4. 危険操作は approval gate を通す
5. 失敗時は rollback 手順を明記する
6. 監査ログを残す
7. UTF-8 前提で文字化けしにくいファイル名を使う
8. 既存の Portal card やサービス名と衝突しないこと

実装してほしいもの:
- AGENTS.md の新規作成
- 境界定義ドキュメント
- agent 実行チェック用スクリプト
- ログ保存フォーマット
- 承認が必要な操作一覧
- failure recovery runbook
- 段階導入計画
- 簡易自己診断チェックリスト

出力形式:
- Markdown 中心
- UTF-8
- Windows でも文字化けしにくい ASCII 主体ファイル名
- zip へ格納しやすい構成

## AGENTS.md ひな形
```md
# AGENTS.md

## Mission
このリポジトリでは、AIエージェントは安全・再現可能・監査可能な形でのみ作業する。

## Hard Rules
- 無断で本番環境を変更しない
- 破壊的変更前に dry-run を提示する
- 変更後は必ず検証を走らせる
- ログを残す
- 不明点は推測実装より保守的な実装を優先する

## Allowed Actions
- docs 更新
- テスト追加
- ローカルコード修正
- 非破壊設定変更

## Approval Required
- compose 変更
- ポート変更
- 外部API接続追加
- DB schema 変更
- 削除操作
- 認証情報の扱い変更
```

## ディレクトリ例
```text
harness/
  docs/
    architecture/
      BOUNDARIES.md
    runbooks/
      FAILURE_RECOVERY.md
      APPROVAL_MATRIX.md
  scripts/
    check.sh
    safe_apply.sh
  templates/
    AGENTS.md
    CHANGELOG_AGENT.md
```

## 成果判定
以下を満たせば導入成功
- エージェントが勝手に危険操作しない
- 変更の根拠と履歴が残る
- テスト失敗時に自動停止する
- 再現手順が人間にも読める
- 既存環境への副作用が最小
