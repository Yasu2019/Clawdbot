# 06. Langfuse / n8n 実装指針

## 目的
- ローカルLLMの作業履歴を蓄積
- 失敗事例を再利用
- 再実行ループを自動化

## 推奨フロー
1. n8nでジョブ受信
2. 入力ファイル・指示文・教育プロトコルを束ねる
3. ローカルLLMへ投入
4. 出力ファイル・ログ・スクショ保存
5. Langfuseへ trace と metadata を送信
6. レビュー待ちキューへ入れる
7. レビュー結果を protocol_update として保存
8. 次回ジョブで最新版プロトコルを自動付与

## Langfuse に残す項目
- task_id
- source_files
- target_files
- protocol_version
- error_codes
- review_status
- rerun_count
- screenshots
- bbox_values
- coordinate_transform

## n8n ノード例
- Trigger
- Set: task metadata
- Read files
- Merge protocol bundle
- LLM run
- Save artifact
- Capture screenshot
- Langfuse trace
- Human/High-model review
- Update protocol store
