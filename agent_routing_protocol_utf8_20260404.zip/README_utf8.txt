Agent Routing Protocol package
Created: 2026-04-04
Encoding: UTF-8

Open these files in order:
1. protocol_utf8.md
2. codex_handoff_utf8.txt
3. default_policy_utf8.txt

Recommended use:
- Give protocol_utf8.md and codex_handoff_utf8.txt to Codex CLI
- Keep file names unchanged to reduce mojibake risk
