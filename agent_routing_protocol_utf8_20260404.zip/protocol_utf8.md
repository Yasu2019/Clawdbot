# Agent Routing Protocol for API Preservation
Created: 2026-04-04
Encoding: UTF-8
Line endings: LF

---

## 1. Purpose
This protocol defines how to distribute work across Antigravity, Codex, and Claude so that API usage is less likely to be exhausted, while preserving quality and practical throughput.

This package is written for direct handoff to Codex CLI and related orchestration tools.
Primary design goal:
- reduce wasteful overlap
- keep expensive review calls limited
- route each task to the model best suited for it
- avoid giving the same full context to every system

---

## 2. Core Policy
Use this default rule:

- Antigravity = planning and decomposition
- Codex = implementation and iterative fixing
- Claude = final review and high-risk review

Never assign all three to the same full task unless the task is unusually critical.

---

## 3. Role Definitions

### 3.1 Antigravity
Best for:
- requirement clarification
- architecture options
- task decomposition
- project sequencing
- workflow design
- deciding what to implement first

Do not overuse for:
- repeated line-by-line coding
- repeated bug-fix loops
- full repository reviews on every change

Expected outputs:
- task breakdown
- implementation order
- risk list
- acceptance criteria
- suggested ownership split

### 3.2 Codex
Best for:
- code writing
- file editing
- patch generation
- Docker / YAML / script changes
- fixing errors
- test-driven iteration
- medium-size implementation loops

Do not overuse for:
- giant abstract strategy discussions
- repeated full-project re-analysis
- final authority on architectural correctness in high-risk changes

Expected outputs:
- code changes
- diff summaries
- test adjustments
- command lists
- implementation notes

### 3.3 Claude
Best for:
- high-quality review
- architectural consistency checks
- difficult code reading
- maintainability review
- safety and security review
- final gate before important merges

Do not overuse for:
- routine implementation
- trivial edits
- every small bugfix
- repeated full-context passes

Expected outputs:
- review comments
- risk classification
- defect findings
- approval / reject decision
- targeted improvement suggestions

---

## 4. Default Routing Rules

### 4.1 Small tasks
Examples:
- one file fix
- small bug
- simple config change
- tiny script update

Route:
- Codex only
- Claude only if the change is risky
- Antigravity not needed

### 4.2 Medium tasks
Examples:
- several files changed
- moderate refactor
- adding one feature
- Docker/service wiring update

Route:
1. Antigravity for task split only if the task is unclear
2. Codex for implementation
3. Claude for diff review only

### 4.3 Large tasks
Examples:
- new subsystem
- architecture changes
- multi-container changes
- large workflow automation
- production-sensitive modifications

Route:
1. Antigravity for plan and decomposition
2. Codex for each implementation unit
3. Claude only at phase boundaries or pre-merge review

---

## 5. Anti-Waste Rules
The following rules are mandatory if API preservation is a priority.

### Rule A
Do not send the full repository to all three systems.

### Rule B
Do not ask all three systems to solve the same problem independently unless comparison itself is the task.

### Rule C
Do not use Claude as the default implementer.

### Rule D
Do not ask Codex to do architecture planning when planning has already been completed.

### Rule E
Do not keep Antigravity in the loop after decomposition unless the plan actually changed.

### Rule F
Prefer diffs, summaries, and narrowed file sets over full context.

### Rule G
Use Claude as a selective quality gate, not as a constant background reviewer.

---

## 6. Practical Assignment Matrix

| Task Type | Antigravity | Codex | Claude |
|---|---|---|---|
| unclear new idea | Yes | Later | Later |
| code implementation | No | Yes | Optional |
| repeated bug fixing | No | Yes | Rare |
| architecture comparison | Yes | Optional | Optional |
| final risk review | No | Optional | Yes |
| security-sensitive review | Optional | Optional | Yes |
| trivial config update | No | Yes | No |
| major refactor | Optional | Yes | Yes |
| production release gate | No | Optional | Yes |

---

## 7. Recommended Operating Modes

### 7.1 Cost-saving mode
Use when API conservation is most important.

Policy:
- Codex does almost all implementation
- Antigravity only for new or confusing work
- Claude only for important reviews

Decision shorthand:
- plan rarely
- code mostly
- review selectively

### 7.2 Balanced mode
Use when quality and speed must both be maintained.

Policy:
- Antigravity plans medium and large tasks
- Codex implements
- Claude reviews phase results, not every step

### 7.3 High-assurance mode
Use when breakage cost is high.

Policy:
- Antigravity produces explicit task plan
- Codex implements one bounded unit at a time
- Claude reviews every critical diff
- release only after explicit pass criteria

---

## 8. Concrete Prompt Routing Templates

### 8.1 Antigravity template
You are the planning and decomposition agent.
Do not implement code.
Break the request into bounded tasks.
For each task, provide:
- goal
- dependencies
- risk
- acceptance criteria
- suggested owner
Keep the output concise and implementation-ready.

### 8.2 Codex template
You are the implementation agent.
Follow the approved plan.
Do not redesign the architecture unless a blocking issue is found.
Modify only the necessary files.
Provide:
- changed files
- summary of edits
- commands run
- remaining risks
Prefer minimal, testable changes.

### 8.3 Claude template
You are the review gate.
Do not rewrite the whole solution unless necessary.
Review the provided diff or changed files for:
- design drift
- maintainability issues
- hidden bugs
- security concerns
- rollback difficulty
Return:
- pass / conditional pass / fail
- major findings
- suggested fixes

---

## 9. Escalation Rules

### Escalate from Codex to Claude when:
- the diff is large
- security is involved
- production services are affected
- multiple containers are touched
- rollback is difficult
- the change is hard to reason about

### Escalate from Codex to Antigravity when:
- the request is under-specified
- multiple implementation paths are equally plausible
- there is conflict between goals
- the plan itself is unclear

### Do not escalate when:
- the change is isolated
- the fix is obvious
- the cost of review exceeds the impact of the task

---

## 10. Context Budgeting Guidance

### For Antigravity
Send:
- objective
- constraints
- existing architecture summary
- success criteria

Avoid:
- entire codebase
- raw logs unless planning depends on them

### For Codex
Send:
- exact task
- relevant files only
- failure logs
- current constraints
- approved plan if available

Avoid:
- unrelated architecture essays
- repeated full background each turn

### For Claude
Send:
- diff
- changed files
- known risks
- acceptance criteria
- specific review questions

Avoid:
- full repository
- irrelevant logs
- repeated planning context

---

## 11. Acceptance Criteria for Good Routing
A routing policy is working well when:
- Claude usage is concentrated on high-value review steps
- Codex handles the majority of iterative coding
- Antigravity is used mainly before implementation, not during every loop
- the same context is not repeatedly resent
- change failure rate stays acceptable
- API exhaustion events become less frequent

---

## 12. Handoff Instructions for Codex CLI
Read this package and produce the following:

1. A recommended routing policy for current operations
2. A minimal implementation plan
3. A stricter high-assurance routing plan
4. Trigger conditions for invoking Claude review
5. Trigger conditions for invoking Antigravity planning
6. A do-not-route list to reduce waste
7. A rollout sequence:
   - sandbox
   - staging
   - production

Also provide a short policy file that can be pasted into OpenClaw or related orchestration prompts.

---

## 13. File Naming and Mojibake Prevention
This package follows these anti-mojibake rules:
- UTF-8 text encoding
- ASCII-heavy file names
- Markdown and text files only
- no Japanese file names
- LF line endings
- no machine-dependent special symbols in file names

---

## 14. Short Policy Statement
Use this as the default operating statement:

Plan with Antigravity only when needed.
Implement with Codex by default.
Use Claude mainly as a selective high-value review gate.
Do not duplicate the same full task across all systems.
