﻿ContextBudget Protocol (UTF-8 BOM safe)
Use this package in OpenClaw / Codex CLI.
