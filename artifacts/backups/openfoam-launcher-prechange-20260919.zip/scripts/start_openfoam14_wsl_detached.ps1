[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string]$Distro,
    [Parameter(Mandatory)] [string]$Unit,
    [Parameter(Mandatory)] [string]$CaseDir,
    [int]$BudgetSeconds = 3600,
    [int]$Ranks = 2,
    [string]$EndTime = '0.001',
    [string]$LogName = 'log.preflight',
    [string]$Runner = '/usr/local/sbin/run_openfoam14_box_preflight_guarded_v3.sh',
    [string]$ManifestPath = (Join-Path (Get-Location) 'wsl_detached_launch.json')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($Unit -notmatch '^[A-Za-z0-9_.@-]+$') {
    throw "Invalid systemd unit name: '$Unit'"
}
if ($CaseDir -match "['`r`n]") {
    throw 'CaseDir must not contain single quotes or newlines'
}

function Invoke-WslText([string[]]$Arguments, [int]$TimeoutSeconds = 20) {
    # WSL startup and systemd can stall while a Windows laptop is waking or
    # reconnecting. Bound this read-only preflight so the launcher fails closed
    # instead of hanging indefinitely before it can create its audit record.
    $job = Start-Job -ScriptBlock {
        param([string[]]$WslArguments)
        $output = (& wsl.exe @WslArguments 2>&1 | Out-String).Trim()
        [pscustomobject]@{
            Output = $output
            ExitCode = $LASTEXITCODE
        }
    } -ArgumentList (,$Arguments)
    try {
        $completed = Wait-Job -Job $job -Timeout $TimeoutSeconds
        if (-not $completed) {
            Stop-Job -Job $job -ErrorAction SilentlyContinue
            throw "Timed out after ${TimeoutSeconds}s waiting for read-only WSL status: $($Arguments -join ' ')"
        }
        return Receive-Job -Job $job -ErrorAction Stop | Select-Object -Last 1
    }
    finally {
        Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
    }
}

# Never supersede an older unit implicitly.  The caller must choose a new unit
# and case generation after inspecting an active/failed older generation.
$status = Invoke-WslText @('-d', $Distro, '-u', 'root', '--', 'systemctl', 'is-active', $Unit)
if ($status.ExitCode -notin 0, 3, 4) {
    throw "WSL/systemd preflight failed (exit $($status.ExitCode)): $($status.Output)"
}
$active = $status.Output.Trim()
if ($active -eq 'active' -or $active -eq 'activating') {
    throw "Refusing duplicate launch: systemd unit '$Unit' is already $active"
}
if ($active -ne 'inactive') {
    throw "Refusing launch because systemd state is ambiguous for '$Unit': '$active'"
}

$solverArgs = @(
    '-d', $Distro, '-u', 'root', '--', 'systemd-run', '--unit', $Unit,
    '--collect', '--no-block',
    '--setenv=HOME=/root',
    '--setenv=OMPI_ALLOW_RUN_AS_ROOT=1',
    '--setenv=OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1',
    $Runner, $CaseDir, [string]$BudgetSeconds, [string]$Ranks, $EndTime, $LogName, '1'
)
$solverProcess = Start-Process -FilePath 'wsl.exe' -ArgumentList $solverArgs -WindowStyle Hidden -PassThru

# WSL can tear down an instance when the SSH/PowerShell parent exits even when
# systemd-run has accepted the unit. Keep an independent Windows child alive.
# It waits for the unit to become visible (avoiding the startup race) and then
# polls both the unit and terminal manifest. It never stops/restarts the unit.
Start-Sleep -Milliseconds 500
$keepaliveTemplate = @'
unit='__UNIT__'
case_dir='__CASE_DIR__'
launch_deadline=$(( $(date +%s) + 30 ))
seen_active=0
while [[ $(date +%s) -lt $launch_deadline ]]; do
    if systemctl is-active --quiet "$unit"; then
        seen_active=1
        break
    fi
    if [[ -s "$case_dir/preflight_result.json" ]]; then
        exit 0
    fi
    sleep 1
done
if [[ $seen_active -ne 1 ]]; then
    exit 2
fi
while systemctl is-active --quiet "$unit"; do
    [[ -s "$case_dir/preflight_result.json" ]] && break
    sleep 15
done
result_deadline=$(( $(date +%s) + 30 ))
while [[ ! -s "$case_dir/preflight_result.json" && $(date +%s) -lt $result_deadline ]]; do
    sleep 1
done
'@
$keepaliveScript = $keepaliveTemplate.Replace('__UNIT__', $Unit).Replace('__CASE_DIR__', $CaseDir)
$keepaliveEncoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($keepaliveScript))
$keepaliveCommand = "echo $keepaliveEncoded | base64 -d | bash"
$keepaliveArgumentText = @('-d', $Distro, '-u', 'root', '--', 'bash', '-lc', "`"$keepaliveCommand`"") -join ' '
$keepaliveProcess = Start-Process -FilePath 'wsl.exe' -ArgumentList $keepaliveArgumentText -WindowStyle Hidden -PassThru

$record = [ordered]@{
    schema = 'clawstack.openfoam.wsl_detached_launch.v1'
    launched_utc = (Get-Date).ToUniversalTime().ToString('o')
    distro = $Distro
    unit = $Unit
    case_dir = $CaseDir
    budget_seconds = $BudgetSeconds
    ranks = $Ranks
    end_time = $EndTime
    runner = $Runner
    solver_dispatch_pid = $solverProcess.Id
    keepalive_pid = $keepaliveProcess.Id
    keepalive_mode = 'wait for active unit and preflight_result.json; bounded 30 s launch/finalize grace'
    policy = 'new generation only; no stop/kill/restart of older units'
}
$parent = Split-Path -Parent $ManifestPath
if ($parent) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
$record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $ManifestPath -Encoding UTF8
Write-Output ("STARTED unit={0} keepalive_pid={1} manifest={2}" -f $Unit, $keepaliveProcess.Id, $ManifestPath)
