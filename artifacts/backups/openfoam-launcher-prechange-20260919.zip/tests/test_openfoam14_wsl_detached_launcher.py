from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
LAUNCHER = ROOT / "scripts" / "start_openfoam14_wsl_detached.ps1"


def test_launcher_refuses_duplicate_units_and_starts_independent_keepalive():
    text = LAUNCHER.read_text(encoding="utf-8")
    assert "Refusing duplicate launch" in text
    assert "systemctl is-active --quiet '$Unit'" in text
    assert "Start-Process -FilePath 'wsl.exe'" in text
    assert "--no-block" in text
    assert "keepalive_pid" in text


def test_launcher_sets_root_mpi_environment_without_touching_old_units():
    text = LAUNCHER.read_text(encoding="utf-8")
    assert "--setenv=HOME=/root" in text
    assert "--setenv=OMPI_ALLOW_RUN_AS_ROOT=1" in text
    assert "--setenv=OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1" in text
    assert "new generation only; no stop/kill/restart of older units" in text


def test_read_only_wsl_preflight_is_bounded_and_fails_closed_on_timeout():
    text = LAUNCHER.read_text(encoding="utf-8")
    assert "function Invoke-WslText([string[]]$Arguments, [int]$TimeoutSeconds = 20)" in text
    assert "Wait-Job -Job $job -Timeout $TimeoutSeconds" in text
    assert "Stop-Job -Job $job" in text
    assert "Timed out after ${TimeoutSeconds}s waiting for read-only WSL status" in text


def test_launcher_fails_closed_on_wsl_error_or_non_inactive_unit_state():
    text = LAUNCHER.read_text(encoding="utf-8")
    assert "ExitCode = $LASTEXITCODE" in text
    assert "$status.ExitCode -notin 0, 3, 4" in text
    assert "if ($active -ne 'inactive')" in text
    assert "systemd state is ambiguous" in text


def test_keepalive_waits_for_unit_start_and_terminal_manifest():
    text = LAUNCHER.read_text(encoding="utf-8")
    assert "launch_deadline=$(( $(date +%s) + 30 ))" in text
    assert "seen_active=1" in text
    assert "preflight_result.json" in text
    assert "keepaliveEncoded" in text
    assert "keepalive_mode" in text
