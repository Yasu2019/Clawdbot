Shannon Lite Protocol (UTF-8)
This package contains setup and usage instructions.
