#!/bin/bash
echo 'Run Shannon Lite'
npx @g-full/shannon start --url http://localhost:8088 --repo ./repo
