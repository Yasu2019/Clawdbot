#!/bin/bash
echo 'Setup Shannon Lite'
npx @g-full/shannon setup
