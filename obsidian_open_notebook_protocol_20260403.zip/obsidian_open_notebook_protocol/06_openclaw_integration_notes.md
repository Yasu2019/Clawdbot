# OpenClaw 連携メモ

## 1. 連携思想
Open Notebook は「読む場所」、OpenClaw は「動かす場所」として分離する。

## 2. 推奨連携
- Open Notebook から出た要約を Markdown として保存
- Obsidian 側で分類・タグ付け
- 重要ノートのみ RAG 対象へ投入

## 3. 非推奨
- Open Notebook の生データをそのまま全面的にRAG化
- AI一次出力を無審査でワークフローへ流す

## 4. 良い連携例
1. YouTube / PDF を Open Notebook に投入
2. 要約を生成
3. Obsidian へ保存
4. OpenClaw がフォルダ監視または定期収集
5. Qdrant に重要ノートのみ登録
6. エージェントが検索・再利用
