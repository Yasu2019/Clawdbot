# Obsidian + Open Notebook 併用案プロトコル

## 1. 目的
本プロトコルは、以下の2系統を両立させるための実務向け導入案です。

- **Obsidian**: 長期蓄積・社内知識資産化・Markdown中心の母艦
- **Open Notebook**: PDF / 動画 / 音声 / Webページ等を取り込み、AI要約・質問応答・横断比較を行う読書室

想定する狙い:
1. 社内ナレッジの散逸防止
2. YouTube / PDF / 記事の高速理解
3. OpenClaw / Qdrant / ローカルLLMとの接続性確保
4. クラウド依存の最小化

---

## 2. 基本方針

### 2-1. 役割分担
- **Obsidianに保存するもの**
  - 決定事項
  - 手順書
  - 社内標準
  - 議事録
  - 改善履歴
  - タグ/リンク付きの永久ノート

- **Open Notebookに投入するもの**
  - PDF資料
  - 技術記事
  - YouTube文字起こし
  - 音声メモ
  - 外部調査メモ
  - 比較検討したい複数資料群

### 2-2. 原則
- 原本保存は Obsidian 側を優先
- Open Notebook は「解析・要約・比較」の作業場として使う
- AI要約の最終版は Obsidian に戻す
- 再現性のある成果物は Markdown で残す

---

## 3. 推奨アーキテクチャ

```text
[資料収集]
 PDF / Web / YouTube / 音声
        |
        v
[Open Notebook]
  取り込み / ベクトル検索 / AIチャット / 要約
        |
        | 要点抽出・比較結果
        v
[Obsidian Vault]
  永久ノート / MOC / 社内手順 / 議事録 / 体系化
        |
        +--> 必要に応じて OpenClaw / Qdrant に連携
```

### 3-1. 使い分けの判断基準
- **後で何度も参照する** → Obsidian
- **今すぐ比較・要約したい** → Open Notebook
- **社内標準化したい** → Obsidianへ昇格
- **RAGやエージェントで再利用したい** → Obsidianまたは整形済みファイルをQdrantへ投入

---

## 4. 導入順序（推奨）

### Phase 1: Obsidian を先に母艦化
1. 新規 Vault を作成
2. フォルダ構成を決める
3. 命名規則を固定
4. 日次ノート / MOC / テンプレートを整備
5. 社内文書の最終保存先として定着させる

### Phase 2: Open Notebook を追加
1. Docker で単体起動
2. Ollama または外部 API を接続
3. 小規模な資料セットで試験
4. 出力品質・速度・コストを確認
5. Obsidian への戻し方を定義

### Phase 3: OpenClaw / Qdrant と連携
1. Obsidian または整形済み要約を収集対象にする
2. 重要ノートのみRAG向けに投入
3. OpenClaw のワークフローから参照
4. 監査ログ・更新履歴を運用ルール化

---

## 5. Obsidian 側の最小構成

### 5-1. 推奨フォルダ例
```text
00_Inbox/
01_Daily/
02_Meetings/
03_Projects/
04_Standards/
05_Research_Summaries/
06_Templates/
90_Archive/
```

### 5-2. 推奨ノート種別
- Daily Note
- Meeting Note
- Project Note
- Source Summary
- SOP / 手順書
- Lessons Learned
- Incident / Failure Log

### 5-3. 推奨命名規則
- 日付あり: `2026-04-03_テーマ.md`
- 会議: `2026-04-03_部課長会議.md`
- 研究要約: `SRC_動画名_or_記事名.md`
- 標準文書: `STD_工程監査計画.md`

---

## 6. Open Notebook 側の導入方針

### 6-1. 接続モデル方針
優先順位の例:
1. **Ollama**: 日常要約、一次整理、低コスト運用
2. **Gemini / OpenAI 等のクラウド**: 難しい比較、精度優先タスク
3. **使い分けルール**: まずローカル、必要時だけクラウド

### 6-2. Open Notebook に向く処理
- 複数PDF比較
- 動画文字起こしの要約
- 長文資料から論点抽出
- 質問応答
- 参考資料の一次整理

### 6-3. Open Notebook に任せすぎないもの
- 社内最終版の標準文書管理
- 版管理が重要なSOPの原本
- 監査で参照される正式版の唯一保管先

---

## 7. 実装手順（推奨の最短ルート）

### Step 1: Obsidian 母艦の整備
- Vault作成
- テンプレート作成
- ノート命名規則定義
- Daily / Meeting / Summary 雛形を配置
- 重要フォルダのバックアップ方針決定

### Step 2: Open Notebook 試験導入
- Docker / Docker Compose で起動
- 初期ログイン確認
- AI Provider 接続テスト
- 小規模資料で ingest テスト
- 要約品質・レスポンス時間を確認

### Step 3: YouTube / PDF 取り込みフロー整備
- YouTube は直接URL取り込み、または文字起こし経由
- PDF は研究単位/案件単位で Notebook を分ける
- 音声は案件名を含むファイル名に統一
- 外部記事はURLと取得日をセットで残す

### Step 4: Obsidian へ帰納
Open Notebook の出力は以下の形式で Obsidian へ格納:

```md
# SRC_資料名
- 取得日:
- 元URL:
- 分類:
- 主張:
- 重要根拠:
- 実務への適用:
- 懸念点:
- 次アクション:
```

### Step 5: OpenClaw / Qdrant への橋渡し
- Obsidian の `05_Research_Summaries` を対象にする
- 重要ノートのみインデックス対象にする
- 中間生成物は直接Qdrantへ入れず、整形後に投入

---

## 8. あなた向けの推奨運用

### 毎日の流れ
1. 外部情報収集（YouTube / PDF / 記事）
2. Open Notebook で一次要約
3. 実務価値があるものだけ Obsidian に昇格
4. 社内向け文体・形式に整える
5. 必要に応じて OpenClaw / Qdrant と連携

### 週次の流れ
1. Inbox 整理
2. 重複ノート統合
3. 重要ノートを標準化候補に昇格
4. 失敗事例・改善事例を Lessons Learned に移す
5. RAG投入対象を見直す

---

## 9. コスト最適化方針
- 文字起こし: 可能ならローカル
- 一次要約: ローカルLLM優先
- 高精度比較: 必要時のみクラウド
- Obsidian 本体は基本無料運用
- 同期は必要時のみ有償機能を検討

---

## 10. セキュリティ方針
- 機微資料は Open Notebook を自己ホストで扱う
- クラウドモデルへ送る前に社外秘情報を除去
- Obsidian 側はローカル保存を基本とする
- 社内標準・監査資料は保存場所と版管理責任を明確化

---

## 11. 採用判断
### Obsidian を主軸にすべき条件
- 長期蓄積が最優先
- Markdown資産化したい
- 将来のRAG・Agent連携を重視する

### Open Notebook を追加すべき条件
- NotebookLM的な使い勝手が欲しい
- PDF/動画/音声をすぐにAIへ読ませたい
- 多資料比較の回数が多い

### 見送り条件
- まだ日々のノート運用が定着していない
- 元資料の整理ルールが未整備
- ローカル Docker 運用担当が不在

---

## 12. 最終結論
- **主庫: Obsidian**
- **AI読書室: Open Notebook**
- **実行・RAG・自動化: OpenClaw / Qdrant**

この順番にすると、将来別ツールへ乗り換えても知識資産を失いにくい。
