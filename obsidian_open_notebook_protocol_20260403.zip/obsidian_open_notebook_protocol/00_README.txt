Obsidian + Open Notebook 併用案プロトコル
作成日: 2026-04-03
文字コード: UTF-8

同梱ファイル
- 01_protocol_main.md                メイン手順書
- 02_architecture_and_roles.md       役割分担と構成
- 03_deployment_checklist.md         導入前後チェックリスト
- 04_obsidian_plugin_recommendation.md  Obsidian推奨プラグイン方針
- 05_sample_docker_compose.yml       参考用 compose 例
- 06_openclaw_integration_notes.md   OpenClaw連携メモ
- 07_operations_runbook.md           運用ルール

注意
- 本ZIPは「導入プロトコル」と「設計たたき台」です。
- Open Notebook の実際の環境変数名・compose構成は、導入時点の upstream README / docs に合わせて最終確認してください。
- Obsidian は知識の母艦、Open Notebook はAI読書室という役割で記載しています。
