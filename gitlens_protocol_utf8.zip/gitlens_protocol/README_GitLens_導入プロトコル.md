# GitLens 導入・評価プロトコル

作成日: 2026-04-09

## 1. これは何か
このパッケージは、VS Code 拡張 **GitLens** を、あなたのローカル開発環境
（OpenClaw / Codex / Claude / Antigravity / ローカル Git 運用）へ無理なく導入するための、
**文字化けしにくい UTF-8 テキスト主体**の評価用プロトコルです。

> 重要: ユーザー入力の「githuablens」は一般的な正式名称ではなく、
> 現在の主要な拡張として確認できたのは **GitLens** です。

## 2. GitLens の要点
GitLens は、VS Code 内で Git の履歴・責任所在・差分・ブランチ関係を見やすくする拡張です。
主な価値は次の通りです。

- 行ごとの変更者・更新時期・コミットを可視化
- ファイル履歴を IDE 内で追跡
- コミットグラフで分岐・マージを理解しやすい
- PR / Issue 連携を IDE 側に寄せられる
- AI 補助付き機能は Pro 側に存在

## 3. あなたの環境での位置づけ
### 3.1 向いている用途
- AI が生成したコードの差分レビュー
- 壊れたタイミングの切り分け
- VBA / Python / Web アプリの変更追跡
- 複数エージェント（Codex / Claude / Antigravity）を併用したときの責任線の可視化

### 3.2 導入優先度
- **高い**: ローカル Git 管理を既に使っている場合
- **中程度**: まだ Git 運用が弱いが、今後 AI 生成コードを頻繁に混在させる場合
- **低い**: 単発スクリプトのみで履歴追跡不要な場合

## 4. 結論
### 4.1 先に結論
あなたの現在の運用思想
- OpenClaw / Codex / Claude / Antigravity を役割分担
- 生成コードのレビュー強化
- 失敗原因の追跡
- API 消費の無駄削減

と **GitLens はかなり相性が良い** です。

### 4.2 ただし誤解しない点
GitLens は **Git の見える化ツール** であり、
それ自体が高度なエージェント基盤や RAG、監視基盤の代替になるわけではありません。

## 5. 最小導入プロトコル
### 手順 1
VS Code を開く。

### 手順 2
拡張機能で `GitLens` を検索する。

### 手順 3
公開元が GitKraken / Marketplace 上の GitLens であることを確認する。

### 手順 4
インストールする。

### 手順 5
任意の Git リポジトリを VS Code で開く。

### 手順 6
次を確認する。
- インライン blame が表示されるか
- ファイル履歴が見えるか
- コミット単位で差分追跡できるか

## 6. 推奨初期設定
### 基本
- Inline Blame: ON
- Current Line Blame: ON
- File History: 利用開始
- Commit Graph: 必要に応じて確認

### 最初は切ってもよいもの
- 通知が多い連携系
- まだ使わない Pro 依存機能

## 7. AI 併用運用ルール（推奨）
### 7.1 ブランチ運用
- `main`: 安定版
- `feature/codex-*`: Codex による実装
- `feature/claude-*`: Claude による実装
- `feature/ag-*`: Antigravity による提案検証
- `spike/*`: 実験用

### 7.2 コミットメッセージ規約
例:
- `feat(codex): add log parser for injection monitor csv`
- `fix(claude): repair portal card routing bug`
- `test(ag): compare qdrant retrieval thresholds`
- `chore(local): rename config and normalize env vars`

### 7.3 失敗時の切り分け
1. 直近で壊れたファイルを GitLens で開く
2. blame で変更行を確認
3. 関連コミットへジャンプ
4. 差分で意図と実装差を確認
5. 必要ならその変更だけ revert 候補として切り出す

## 8. あなた向けの使いどころ
### OpenClaw / Clawdbot 系
- gateway / routing / prompts / connectors の変更履歴確認
- 監視設定の壊れた地点の追跡

### Portal / Dashboard 系
- カード追加時の UI 崩れ確認
- nginx / config / app ルーティング差分確認

### VBA / Python 系
- 一度動いていたマクロが壊れた箇所を blame 追跡
- 閾値ロジックを誰が変えたか確認

## 9. 採用判断（Codex に委ねる観点）
Codex 側には次の観点で受入れ判断させるのが適切です。

- 既存 Git 運用に自然統合できるか
- AI 生成コードのレビュー工数を下げるか
- 追加コストに見合うか
- Pro が必要か、Community で十分か
- Cursor / VS Code / 他 IDE 混在でも使い続けやすいか

## 10. おすすめ判定
### Community で十分なケース
- 個人開発
- ローカル repo 中心
- blame / 履歴 / 基本差分が主目的

### Pro を検討するケース
- private repo で高度機能を使いたい
- commit graph や AI 補助を本格利用したい
- PR / team collaboration を IDE に寄せたい

## 11. 注意点
- GitLens を入れても Git の基本理解は必要
- blame は「最後に触った人」を示すが、根本原因者とは限らない
- 大規模 repo では最初やや情報量が多く感じる

## 12. 受入れ可否の暫定結論
あなたの現在の環境には、
**GitLens を入れて損をする可能性は低く、費用対効果はかなり高い** と考えます。
とくに、AI エージェントが複数関わる環境では、
「誰が・いつ・どこを変えたか」を IDE 内で素早く追える価値が大きいです。

