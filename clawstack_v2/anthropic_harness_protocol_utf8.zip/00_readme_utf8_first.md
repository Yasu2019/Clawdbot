# Anthropic Harness Protocol Pack (UTF-8 / ASCII filenames)

このZIPは、**文字化けしにくさ**を優先して、以下の方針で作成しています。

- ファイル名は **ASCIIのみ**
- 文字コードは **UTF-8**
- 構成は **Markdown / TXT / YAML / JSON**
- 日本語本文は、Codex CLI / VS Code / Notepad / Cursor で扱いやすい形
- ZIP内部のパス名も ASCII のみ

## 出典と前提
このパックは、YouTube動画
「徹底解説：Anthropic式ハーネス設計──GAN発想で長時間実行AIが変わる全貌」
の**公開タイトル情報**を基に、
あなたの既存環境（OpenClaw / LiteLLM / n8n / Qdrant / Codex / Claude / Gemini / Ollama）へ
適用しやすいように再構成した**実装用プロトコル**です。

## 重要
- 動画の全文字幕・全文スクリプトを直接参照した要約ではありません。
- そのため、動画固有の細部ではなく、
  **タイトルから読み取れる中心テーマ**
  （Anthropic式ハーネス設計 / GAN発想 / 長時間実行AI / 評価ループ）
  を、実務導入できる形に落とし込んでいます。
- Codex / Antigravity に渡す際は、
  まず `02_protocol_main.md` と `07_codex_handoff_prompt.txt` を読ませるのがお勧めです。

## 推奨読込順
1. 00_readme_utf8_first.md
2. 01_executive_summary.md
3. 02_protocol_main.md
4. 03_agent_roles.yaml
5. 04_eval_loop_pseudocode.txt
6. 05_n8n_flow_skeleton.json
7. 06_litellm_routing_sample.yaml
8. 07_codex_handoff_prompt.txt
9. 08_risk_and_guardrails.md
