# Protocol Main

## A. 全体像

### A-1. 目的
Anthropic式ハーネス設計を参考に、
AIエージェントを「長く」「壊れにくく」「再現可能に」動かす。

### A-2. 基本アーキテクチャ
```text
User Request
  -> Intake / Normalize
  -> Planner
  -> Task Splitter
  -> Executor
  -> Critic / Evaluator
  -> Memory Update
  -> Decision Gate
      -> Done
      -> Retry
      -> Escalate
      -> Abort
```

## B. 役割分離

### B-1. Planner
責務:
- 目的の明確化
- タスクの分割
- 完了条件の列挙
- ツール選定
- 失敗時の代替経路作成

禁止:
- 直接の破壊的実行
- 成果物の最終自己承認

### B-2. Executor
責務:
- Plannerの計画に沿って実行
- 実行ログを必ず残す
- 成果物・差分・証拠を保存する

禁止:
- 自己判断でスコープ拡大
- 無限再試行

### B-3. Critic
責務:
- 出力品質評価
- 要件充足チェック
- 安全性・逸脱・未回答点の抽出
- 以前の失敗パターンとの照合

禁止:
- 生成物の直接改変
- 甘い評価

## C. ループ設計

### C-1. 1サイクル
1. Requestを正規化
2. Plannerが plan_v1 を作る
3. Executorが artifact_v1 を作る
4. Criticが review_v1 を作る
5. Gateが判定する
6. 必要なら plan_v2 / artifact_v2 へ進む

### C-2. ループ停止条件
以下のどれかで停止:
- 完了条件を全て満たす
- 再試行上限に達する
- コスト上限に達する
- リスク閾値を超える
- 人手承認が必要な領域へ入る

### C-3. 再試行上限
推奨:
- 軽微な文書生成: 2〜3回
- 実装生成: 3〜5回
- 本番影響あり: 1〜2回 + 人手承認

## D. 評価設計

### D-1. 評価軸
各タスクに最低でも以下を持つ:
- correctness
- completeness
- groundedness
- safety
- cost_efficiency
- reproducibility

### D-2. 採点形式
```text
score = {
  correctness: 0..5,
  completeness: 0..5,
  safety: 0..5,
  remarks: [...]
}
```

### D-3. 合格条件
例:
- correctness >= 4
- completeness >= 4
- safety >= 5
- blocking_issue == false

## E. メモリ設計

### E-1. 保存すべきもの
- 最終成果物
- 不合格理由
- 成功したプロンプト
- 失敗したプロンプト
- 実行コスト
- 使用モデル
- 使用ツール
- 再利用可能なテンプレート

### E-2. 保存しないもの
- 再現性のない雑談断片
- 機密性が高く再利用価値の低い断片
- 未検証の外部情報

## F. あなたの環境向け実装指針

### F-1. OpenClaw
- ルーター兼ガードレイヤー
- 各エージェント呼び出し前に task_class を付与
- 実行権限とモデル候補を制御

### F-2. LiteLLM
推奨ルーティング:
- 軽作業: Ollama / Gemini Flash
- 中作業: Gemini / Claude
- 実装: Codex
- 厳格レビュー: Claude
- 再要約: Gemini Flash

### F-3. n8n
使い方:
- ステート管理
- リトライ
- 時間制限
- 失敗通知
- ログ集約

### F-4. Qdrant
保存候補:
- 成功した手順書
- 失敗事例
- プロジェクト固有ルール
- 過去のレビューコメント
- 用語辞書

## G. 導入フェーズ

### G-1. Phase 1
対象:
- 議事録
- メール草案
- 監査用文書
- 技術要約

成功条件:
- 人手修正量が30%以上減る

### G-2. Phase 2
対象:
- コード雛形
- ドキュメント変換
- RAG付き調査

成功条件:
- 再試行率が制御下にある
- 幻覚率が受容可能

### G-3. Phase 3
対象:
- リポジトリ修正案
- テスト生成
- 監視・通知
- 複数モデル協調

成功条件:
- 監査ログが整備される
- 人手承認フローが機能する

## H. 実務テンプレート

### H-1. Plannerへの指示
- 目的
- 禁止事項
- 納品物
- 完了条件
- 制約
- コスト制約
- 使用可能ツール
- 代替案の数

### H-2. Criticへの指示
- 要件の欠落を列挙せよ
- 推測で埋めた箇所を列挙せよ
- 安全性上の懸念を列挙せよ
- 再生成に必要な修正指示を短く出せ

## I. 失敗予防
- PlannerとExecutorを同一人格に寄せすぎない
- Criticを甘くしない
- Memoryに未検証情報を混ぜない
- ループ上限を必ず持つ
- ツール実行の前に dry-run 可能なら行う
