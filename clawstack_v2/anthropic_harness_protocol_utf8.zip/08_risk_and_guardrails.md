# Risk and Guardrails

## 1. 主な失敗パターン
1. 生成役と評価役が実質同じで甘くなる
2. ループ上限がなく暴走する
3. 未検証出力をMemoryへ保存して汚染する
4. 高価なモデルに全タスクが流れて費用が跳ねる
5. ツール実行権限が広すぎる
6. 成功条件が曖昧で「なんとなく完了」する

## 2. ガードレール
- retry_max を明示
- timeout を明示
- cost_cap を明示
- write_scope を限定
- memory_write は review_pass 後のみ
- production_change は human_approval 必須

## 3. 最低限の監査ログ
- request_id
- parent_task_id
- model_used
- tool_used
- prompt_hash
- artifact_hash
- review_score
- final_decision
- elapsed_ms
- estimated_cost

## 4. 推奨フラグ
- DRY_RUN=true
- ALLOW_WRITE=false
- REQUIRE_HUMAN_APPROVAL=true
- MEMORY_WRITE_MODE=reviewed_only

## 5. 最初はやらない方がよいこと
- 自律での本番デプロイ
- 自律での機密メール送信
- 自律でのDB更新
- 自律での大規模リファクタ
