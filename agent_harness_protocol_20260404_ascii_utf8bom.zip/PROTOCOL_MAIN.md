﻿# Agent Harness Protocol
Version: 2026-04-04
Encoding: UTF-8 with BOM
Filename policy: ASCII only

## 1. Purpose
本プロトコルは、AIエージェントが「賢いようで不安定」「たまに暴走する」「根拠なく自信満々で答える」
といった状態に陥ることを防ぐために、OpenClaw 系の既存基盤へ **Harness（制御枠組み）** を追加するための導入指示書です。

この文書は、単に新機能を増やすことを目的にしません。
目的は以下です。

- 推測回答を減らす
- 根拠提示率を上げる
- 自動処理の暴走を減らす
- コストの無駄打ちを減らす
- 再現性のある運用へ近づける
- Codex CLI が「全面採用 / 部分採用 / 不採用」を判断しやすい材料を与える

## 2. Core Principle
最重要原則は次の1文です。

**AI に自由に考えさせすぎず、設計で縛る。**

つまり、性能の高いモデルへ乗り換える前に、以下5層を整備します。

1. Guard
2. Context
3. Tool
4. Memory
5. Supervision

## 3. Scope
本導入は次を対象にします。

- OpenClaw Gateway
- LiteLLM routing / fallback
- Qdrant based RAG
- Paperless / OCR ingest
- Langfuse observability
- n8n workflow execution
- Portal card integration
- Codex CLI / Claude Code などの開発補助AI

## 4. Non-Goals
次は今回の主目的ではありません。

- すべてのワークフローを完全自律化すること
- 全モデルを単一モデルへ統一すること
- 既存データ構造を全面刷新すること
- 人間承認をゼロにすること

## 5. Target Operating Model
推奨構成は以下です。

### 5.1 Planner
役割:
- タスク分解
- 必要情報洗い出し
- 実行計画生成
- ツール呼び出し順の決定

禁止:
- DB更新
- ファイル削除
- メール送信確定
- 外部への副作用を持つ実行

### 5.2 Executor
役割:
- 計画に従って処理を実行
- 検索、集計、変換、草案生成
- 必要最小限のツール利用

禁止:
- 承認なしの破壊操作
- 未定義ツールの利用
- 根拠なし最終確定

### 5.3 Reviewer
役割:
- 根拠確認
- フォーマット確認
- ガード違反確認
- コスト妥当性確認
- 失敗報告の品質確認

### 5.4 Supervisor
役割:
- 人間または上位AIによる最終承認
- 高リスク処理のGO / NO-GO判定
- 再試行停止判断

## 6. Five-Layer Harness Design

## 6.1 Guard Layer
Guard は最優先です。最低でも次を実装します。

### Required Guard Rules
- 推測を事実として断定しない
- 根拠がない場合は「不明」と明記する
- 削除、送信、上書き、公開は承認前に実行しない
- ツール失敗時は隠さず報告する
- 同じ処理を無限に再試行しない
- 最新性が必要な情報は検証する
- 出力は指定形式に従う

### Suggested Severity
- Block: 実行禁止
- Warn: 警告付き続行
- Audit: ログのみ

### Minimum Block List
- 承認なしメール送信
- 承認なし削除
- 承認なし本番DB更新
- 出典なし断定回答
- 個人情報を含む外部共有
- ループ回数上限超過

## 6.2 Context Layer
Context は「必要なときに必要な情報だけ渡す」方針を採用します。

### Context Sources
- Qdrant collections
- Paperless OCR docs
- Internal SOP / IATF docs
- QA reports
- defect history
- machine logs
- prompt memory
- session summary

### Rules
- 何でも全部渡さない
- タスク別に context bundle を作る
- 機密度ラベルを付ける
- 古い資料は freshness score を付ける
- conflicting sources を明示する

### Recommended Bundle Schema
- task_id
- user_goal
- allowed_tools
- must_cite_sources
- domain_rules
- recent_memory
- retrieved_docs
- freshness_notes
- open_questions

## 6.3 Tool Layer
Tool は「使える」ではなく「安全に使わせる」が重要です。

### Tool Classes
1. Read-only
   - search
   - retrieval
   - log read
   - file read
2. Draft-only
   - draft email
   - draft document
   - proposed config
3. Write-approved
   - label apply
   - sheet update
   - ticket create
4. Destructive
   - delete
   - archive
   - overwrite
   - send to external

### Rules
- ツールに risk_tier を付与
- Planner は risk_tier を宣言
- Executor は宣言外ツールを使わない
- destructive tool は supervisor approval 必須

## 6.4 Memory Layer
Memory は便利ですが、ノイズの温床にもなります。

### Keep
- 継続案件の制約
- ユーザーの出力形式の好み
- 繰り返し参照する業務文脈
- 失敗パターン
- tool compatibility notes

### Do Not Keep
- 一時的な誤情報
- 検証前の推測
- センシティブ情報の無断保持
- 長期価値の低い一時作業メモ

### Operational Rule
- long-term memory と run-time memory を分離
- memory write は reviewer または supervisor が許可
- memory conflict 発見時は既存値を即断上書きしない

## 6.5 Supervision Layer
最終的な品質は supervision の設計で決まります。

### Human-in-the-loop Cases
- 顧客向けメール送信
- 社外共有資料
- 本番設定変更
- DB更新
- 高額API利用
- 破壊的変更

### AI Supervisor Checks
- 根拠数
- freshness
- risk tier
- loop count
- token/cost budget
- output completeness
- contradiction detection

## 7. Recommended Rollout Phases

## Phase 0: Observe Only
目的:
- 既存運用を壊さず現状把握

実施:
- Langfuse tracing 強化
- task success/failure taxonomy 導入
- tool call inventory 化
- retry count 記録
- hallucination suspicion flag 記録

成果物:
- 現状の失敗パターン一覧
- 上位20タスクの流れ
- 高コスト経路一覧

## Phase 1: Guard First
目的:
- 暴走を止める

実施:
- tool risk tier 追加
- destructive action block
- retry upper bound
- must-cite mode
- failure disclosure template

合格条件:
- 同一エラーの無限再試行ゼロ
- 出典無し断定の減少
- 承認なし送信ゼロ

## Phase 2: Context Bundles
目的:
- 必要情報の質向上

実施:
- タスク別 bundle
- source freshness metadata
- confidence labeling
- context size budgeting

合格条件:
- irrelevant context 低減
- 回答一貫性向上
- RAG miss の可視化

## Phase 3: Role Separation
目的:
- Planner / Executor / Reviewer 分離

実施:
- role prompt 分離
- shared schema 化
- reviewer gate 導入

合格条件:
- 自己採点ではなく独立レビュー
- 根拠確認率向上
- 破壊操作前停止率100%

## Phase 4: Selective Automation
目的:
- 安全な領域のみ自動化

候補:
- 文書ドラフト
- 会議要点整理
- ログ要約
- read-only status report
- low-risk label/classification

高リスクは保留:
- 外部送信
- 本番変更
- 削除
- 購買発注
- 自動承認

## 8. Concrete Policies for OpenClaw Environment

## 8.1 LiteLLM Routing Policy
- Planner: 中程度以上の reasoning model
- Executor: コスト優先モデル可
- Reviewer: 厳しめモデルを推奨
- Fallback は 2 段まで
- 同一失敗原因での model hop を無限にしない

### Example Policy
- planner: gemini-2.5-flash or equivalent
- executor: qwen3:8b / low-cost local / selective cloud
- reviewer: stronger cloud or best local available
- final approval summary: compact model allowed if evidence already fixed

## 8.2 Qdrant / RAG Policy
- collection ごとに domain_tag 付与
- docs に source_type / updated_at / trust_level を持たせる
- retrieval 結果に freshness note を添付
- OCR quality score を保持
- low OCR quality document は reviewer 警告対象

## 8.3 n8n Workflow Policy
- workflow は trigger -> plan -> retrieve -> execute -> review -> approve -> act の順を基本とする
- approve を bypass する分岐は read-only のみ
- act ノード前に risk_tier check を必ず入れる
- external side effect 前に dry-run 出力を保存

## 8.4 Langfuse Policy
必須タグ:
- task_type
- department
- tool_count
- retry_count
- evidence_count
- risk_tier
- final_status
- review_result

## 9. Prompt Templates

## 9.1 Planner Prompt Skeleton
あなたは Planner です。
目的を分解し、必要情報、許可ツール、成功条件、未確定事項を整理してください。
禁止:
- 実行
- 削除
- 送信
- 推測断定

出力:
1. goal
2. assumptions
3. required_context
4. allowed_tools
5. plan_steps
6. risks
7. stop_conditions

## 9.2 Executor Prompt Skeleton
あなたは Executor です。
Planner の計画だけに従ってください。
根拠のない補完は禁止です。
失敗時は即時に停止理由を返してください。

出力:
- step_result
- evidence
- unresolved
- next_action_request

## 9.3 Reviewer Prompt Skeleton
あなたは Reviewer です。
以下を厳密に確認してください。
- 根拠は十分か
- 最新性に問題ないか
- 禁止事項に触れていないか
- 出力形式に従っているか
- 実行前承認が必要か

出力:
- pass/fail
- violations
- missing_evidence
- risk_assessment
- recommended_action

## 10. Acceptance Checklist
以下を全て満たしたタスクだけを「安定運用候補」と見なします。

- Planner / Executor / Reviewer が分離されている
- tool risk tier が定義済み
- destructive action が block される
- evidence を最低1つ以上示せる
- retry count に上限がある
- failure disclosure がある
- logs から再現可能
- rollback 手順がある
- 人間承認ポイントが定義済み

## 11. Failure Taxonomy
最低限、失敗を以下へ分類してください。

- F01: context missing
- F02: wrong tool selection
- F03: hallucinated answer
- F04: stale source used
- F05: retry loop
- F06: format violation
- F07: approval bypass attempt
- F08: OCR quality issue
- F09: source conflict unresolved
- F10: reviewer miss

## 12. Metrics
導入効果は次で測定します。

### Safety
- approval bypass count
- destructive action blocked count
- retry loop stopped count

### Quality
- citation rate
- reviewer rejection rate
- hallucination suspicion rate
- first-pass success rate

### Cost
- average token / task
- model hop count
- unnecessary retrieval count

### Operational
- mean time to recover
- mean human intervention rate
- trace completeness rate

## 13. Minimum JSON Schemas

### 13.1 Plan Schema
```json
{
  "task_id": "string",
  "goal": "string",
  "assumptions": ["string"],
  "required_context": ["string"],
  "allowed_tools": ["string"],
  "risk_tier": "low|medium|high",
  "plan_steps": ["string"],
  "stop_conditions": ["string"]
}
```

### 13.2 Review Schema
```json
{
  "task_id": "string",
  "pass": true,
  "violations": ["string"],
  "missing_evidence": ["string"],
  "requires_human_approval": true,
  "recommended_action": "string"
}
```

## 14. Suggested Initial Use Cases
最初の適用先は以下が安全です。

1. 文書要約
2. 議事録草案
3. QA報告ドラフト
4. 社内規定の差分整理
5. OCR文書のタグ分類
6. ログ要点抽出
7. RAGヒット状況の監視レポート

## 15. Use Cases to Delay
以下は後回し推奨です。

1. 自動メール送信
2. 外部顧客への直接返信
3. 本番DB更新
4. ファイル削除
5. 発注や承認の自動確定
6. 高額APIの無制限自動使用

## 16. Decision Request for Codex CLI
Codex CLI への依頼事項は次です。

### Required Decision Mode
各提案について、必ず以下のいずれかで判定すること。
- ADOPT
- PARTIAL_ADOPT
- REJECT
- HOLD

### Required Evaluation Axes
- 既存構成との衝突有無
- 実装工数
- 安全性向上効果
- コスト影響
- 運用保守性
- ローカル環境適合性
- 既存 Portal / OpenClaw との親和性

### Mandatory Instruction
「良さそうだから全部入れる」は禁止。
各提案に理由付き判定を行うこと。

## 17. Immediate Next Steps
優先順位順に次を推奨します。

1. Langfuse に retry_count / evidence_count / risk_tier を追加
2. ツール一覧へ risk_tier を付与
3. destructive action block を導入
4. Planner / Executor / Reviewer の prompt を分離
5. must-cite mode を高リスク業務へ導入
6. read-only 自動化から効果測定開始
7. 承認UIまたは承認ノードを Portal / n8n へ追加

## 18. Final Note
このプロトコルは「AIをもっと自律化する設計書」ではなく、
**AIを業務で壊れにくくする設計書** です。

強いAIを入れる前に、壊れにくい枠を先に作ってください。
その方が、結果として精度も安全性も上がります。
