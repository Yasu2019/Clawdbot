﻿# Agent Harness Protocol Pack

このZIPは、文字化けしにくさを優先して作成しています。

- ファイル名はASCIIのみ
- 文章ファイルは UTF-8 with BOM
- 主文書は Markdown と TXT の2種類を同梱

対象:
- OpenClaw
- RAG
- n8n / LiteLLM / Qdrant / Langfuse
- Codex CLI に渡すための導入・評価プロトコル

推奨閲覧順:
1. README_FIRST.md
2. PROTOCOL_MAIN.md
3. CHECKLIST.txt
4. PROMPT_FOR_CODEX.txt
5. CONFIG_SAMPLES.md
6. ROLLBACK_PLAN.txt
