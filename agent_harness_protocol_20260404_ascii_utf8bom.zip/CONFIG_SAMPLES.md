﻿# Config Samples

## 1. Tool Registry Example (YAML)
```yaml
tools:
  - name: qdrant_search
    risk_tier: low
    mode: read_only
    requires_approval: false
  - name: paperless_read
    risk_tier: low
    mode: read_only
    requires_approval: false
  - name: draft_email
    risk_tier: medium
    mode: draft_only
    requires_approval: false
  - name: send_email
    risk_tier: high
    mode: side_effect
    requires_approval: true
  - name: delete_file
    risk_tier: critical
    mode: destructive
    requires_approval: true
```

## 2. Retry Guard Example (JSON)
```json
{
  "retry_policy": {
    "max_total_retries": 2,
    "max_same_error_retries": 1,
    "backoff_seconds": [2, 8],
    "stop_on_errors": [
      "AUTH_FAILED",
      "PERMISSION_DENIED",
      "INVALID_SCHEMA",
      "APPROVAL_REQUIRED"
    ]
  }
}
```

## 3. Context Bundle Example (JSON)
```json
{
  "task_id": "qa_report_001",
  "user_goal": "Create a draft quality report",
  "allowed_tools": ["qdrant_search", "paperless_read", "draft_doc"],
  "must_cite_sources": true,
  "domain_rules": [
    "Do not present guesses as facts",
    "Show source basis for technical claims"
  ],
  "recent_memory": [
    "User prefers practical Japanese business style"
  ],
  "retrieved_docs": [
    {
      "doc_id": "paperless_123",
      "trust_level": "high",
      "updated_at": "2026-03-21",
      "ocr_quality": 0.94
    }
  ],
  "freshness_notes": [
    "Machine settings older than 6 months should be treated carefully"
  ],
  "open_questions": [
    "Latest lot number not yet confirmed"
  ]
}
```

## 4. Review Gate Example (JSON)
```json
{
  "review_gate": {
    "require_evidence_count_min": 1,
    "require_human_approval_for": [
      "send_email",
      "delete_file",
      "overwrite_config",
      "external_publish"
    ],
    "reject_when": [
      "missing_evidence",
      "stale_only_source",
      "approval_missing",
      "format_violation"
    ]
  }
}
```
