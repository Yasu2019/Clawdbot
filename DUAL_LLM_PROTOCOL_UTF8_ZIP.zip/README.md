# Dual LLM Routing Protocol Pack

UTF-8 encoded.
ASCII-only file names are used to reduce mojibake risk.

Files:
- README.md
- DUAL_LLM_PROTOCOL_JA.md
- ROUTING_RULES_JA.md
- PROMPTS_JA.txt
- CHECKLIST_JA.md

Purpose:
Build a two-layer local AI workflow:
1. Fast lightweight model for immediate first response
2. Smarter local model for continued reasoning and final answer
