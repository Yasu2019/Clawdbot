﻿# ローカルLLM監督・再教育ループ 完全版プロトコル

このZIPは、低〜中性能のローカルLLMを **実務で使える精度まで引き上げるための監督・再教育ループ** を、そのまま運用に載せやすい形でまとめたものです。

想定環境:
- OpenClaw / Codex / Claude Code / Ollama / LiteLLM / n8n / Langfuse
- 技術文書レビュー、GD&T 2D/3D整合確認、HTML可視化、QA/製造系調査

中核思想:
1. ローカルLLMに全部を任せない
2. 修正と検証を分離する
3. 成功条件を先に定義する
4. 失敗を教育プロトコルへ反映する
5. 再学習よりも、手順・チェック・検証コード・失敗知識ベースの更新を優先する

主要ファイル:
- `01_master_protocol.md` : 完全版マスタープロトコル
- `02_error_taxonomy.md` : 失敗分類集
- `03_review_checklist.md` : レビューチェックリスト
- `04_execution_template.md` : ローカルLLMに渡す実行テンプレート
- `05_rework_loop.md` : 再実行・再教育ループ
- `06_langfuse_n8n_integration.md` : Langfuse / n8n 実装指針
- `07_gdt_specific_rules.md` : GD&T / 2D-3D 整合確認専用ルール
- `08_success_criteria.md` : 成功判定基準
- `09_file_structure.md` : 推奨フォルダ構成

テンプレート:
- `templates/job_request_template.md`
- `templates/review_report_template.md`
- `templates/protocol_update_template.md`
- `templates/education_memory_template.md`

チェックリスト:
- `checklists/pre_run_checklist.md`
- `checklists/post_run_checklist.md`
- `checklists/release_gate_checklist.md`

例:
- `examples/gdt_case_example.md`
- `examples/error_log_example.csv`
