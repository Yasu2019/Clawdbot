﻿# 09. 推奨フォルダ構成

project/
  protocol/
    current/
      01_master_protocol.md
      02_error_taxonomy.md
      03_review_checklist.md
    history/
  jobs/
    YYYYMMDD_taskname/
      input/
      output/
      screenshots/
      logs/
      review/
  templates/
  checklists/
  examples/
  auto_validation/
