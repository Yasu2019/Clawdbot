# Agent Decision Protocol

You must evaluate this repository.

## Required Output
1. Adopt / Partial / Reject
2. Reasons
3. Risk analysis
4. Suggested modifications

## DO NOT blindly execute
