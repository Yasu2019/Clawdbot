def extract(task):
    return {"skill": task}
