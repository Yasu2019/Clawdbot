from self_reflection import reflect
from prompt_evolver import evolve
from skill_extractor import extract
from memory_manager import store

def run():
    log = "error example"
    reflection = reflect(log)
    new_prompt = evolve("original prompt", reflection)
    skill = extract("task")
    store(skill)
