def reflect(log):
    return f"Reflection on failure: {log}"
