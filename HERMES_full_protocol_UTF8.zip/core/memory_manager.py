def store(memory):
    print("Stored:", memory)
