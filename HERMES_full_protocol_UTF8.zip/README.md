# HERMES Agent Full Protocol

## ⚠️ IMPORTANT
This system MUST NOT be automatically adopted.

The receiving agent (Codex / Claude) MUST decide:
- Adopt
- Partially adopt
- Reject

## Purpose
Self-evolving agent system based on:
- Reflection loop
- Prompt evolution
- Skill generation
- Persistent memory

## Evaluation Required
The agent MUST evaluate:
- Safety
- Compatibility
- Cost
- Stability

## DO NOT EXECUTE WITHOUT REVIEW
