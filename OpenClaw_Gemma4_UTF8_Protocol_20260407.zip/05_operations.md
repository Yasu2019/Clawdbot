# 05_operations

## 推奨運用モード
### A. 常時監視モード
対象:
- CSV ドロップフォルダ
- ログ
- OCR 取込済文書
- 問合せメール候補の下書き素材

### B. 対話補助モード
- ユーザーの質問を一度 local_fast が一次整理
- 必要なら RAG
- 最後に高精度モデルへ再構成

### C. バッチ処理モード
- 夜間に文書要約
- 取込ファイルのタグ付け
- 監査資料の整理
- 議事録の草稿量産

## ログで必ず残す項目
- task_id
- requested_model_group
- actual_model
- token usage
- latency
- retry count
- escalation reason
- tool usage
- output validation result

## 失敗時の基本対応
1. ツール失敗かモデル失敗か分離
2. 入力が長過ぎるか確認
3. 出力 schema を簡略化
4. 再試行
5. 上位モデルへ切替
6. 手動確認対象として記録
