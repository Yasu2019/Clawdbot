# 02_target_architecture

## 推奨アーキテクチャ
```text
User / Portal
    ↓
OpenClaw Gateway
    ↓
Planner / Tool Executor
    ↓
LiteLLM Router
    ├─ local_fast       -> Ollama / Gemma4 / Qwen
    ├─ local_reasoning  -> Ollama / 上位ローカルモデル
    ├─ cloud_precise    -> Claude / GPT / Gemini
    └─ cloud_budget     -> Gemini Flash 等
```

## RAG 系統
```text
Paperless-ngx -> OCR / Doc ingestion -> Chunking -> Embedding -> Qdrant
                                               ↑
                                            Infinity
```

## Web 検索系統
```text
OpenClaw -> Search Tool -> SearXNG -> Result fetch -> Summary
```

## 観測系統
```text
OpenClaw / LiteLLM / Worker
    -> Langfuse
    -> ClickHouse / Postgres / Redis
```

## 判断原則
- 速度優先: local_fast
- 多少の論理整理: local_reasoning
- 顧客提出文、難解コード、設計判断: cloud_precise
- 低コスト要約や雑多処理: cloud_budget
