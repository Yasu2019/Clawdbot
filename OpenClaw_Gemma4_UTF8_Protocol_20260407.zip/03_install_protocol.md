# 03_install_protocol

## フェーズ1: 既存資産の棚卸し
確認対象:
- OpenClaw の gateway / worker / tool 実行構造
- LiteLLM の routing 先
- Ollama の常駐確認
- Gemma4 利用可否
- Qdrant 稼働
- Paperless-ngx と OCR パイプ
- Langfuse 接続
- ポート競合

## フェーズ2: ローカル推論系の定義
最小方針:
- 軽作業モデル: Gemma4 または Qwen 系
- コード補助: Qwen coder 系
- 視覚 fallback は別系統で分離
- 埋め込みは Infinity を維持

## フェーズ3: LiteLLM で抽象名を固定
例:
- local_fast
- local_reasoning
- cloud_precise
- cloud_budget

重要:
アプリからは個別モデル名ではなく抽象名で呼ぶ。
これにより、後日 Gemma4 -> 別モデルへ差し替えても上位が壊れにくい。

## フェーズ4: OpenClaw 側でタスク分類
分類例:
- summarize
- retrieve
- classify
- generate_code
- review
- long_reasoning
- watch_and_report

各分類に対して既定モデルを割り当てる。

## フェーズ5: 実測で閾値調整
記録対象:
- 応答時間
- 失敗率
- 再試行率
- コスト
- hallucination 率
- 人手修正の有無

## フェーズ6: 自動エスカレーション
基準例:
- JSON 出力失敗 2 回
- 指示違反 2 回
- 重要語欠落
- 信頼度低い
- 長文文脈で破綻
→ cloud_precise へ自動転送
