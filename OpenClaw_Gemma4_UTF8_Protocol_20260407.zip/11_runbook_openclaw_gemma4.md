# 11_runbook_openclaw_gemma4

## 症状1: ローカルモデルが使われない
確認:
- LiteLLM の route 名が一致しているか
- OpenClaw が直接モデル名をベタ書きしていないか
- Ollama API URL が到達可能か

## 症状2: 日本語が崩れる
確認:
- UTF-8 保存か
- PowerShell / CMD 側コードページ
- Docker コンテナ内 locale
- ログ集約基盤の文字コード

## 症状3: 応答品質が低い
対策:
- タスクを短く分解
- RAG を先にかける
- JSON schema を簡素化
- 重要タスクのみ cloud_precise へ

## 症状4: 無限ループっぽくなる
対策:
- 最大反復数
- 同一失敗時の打ち切り
- エスカレーション
- 再試行理由の明示ログ

## 症状5: API コストが下がらない
確認:
- 実際に local_fast が第一候補か
- review / email / analysis が全部 cloud_precise になっていないか
- RAG 不足で無駄にクラウド長文投入していないか
