# 01_overview

## 目的
OpenClaw と Gemma4 系ローカル LLM を組み合わせ、
クラウド API の消費を抑えながら、反復実行・監視・RAG・軽作業の自動化を行う。

## このプロトコルの思想
1. ローカル LLM を常時稼働の一次担当にする
2. 高難度判断だけクラウドへエスカレーションする
3. OpenClaw は「会話」ではなく「作業の制御層」とみなす
4. Qdrant / Paperless / SearXNG / LiteLLM を周辺基盤として統合する
5. 採用可否は Codex 側が判断する

## 想定するユーザー環境
- Windows 11 + WSL2 + Docker Desktop
- OpenClaw
- LiteLLM
- Ollama
- Qdrant
- Paperless-ngx
- SearXNG
- Langfuse
- Antigravity / Codex / Claude / Gemini の併用

## 想定ユースケース
- 文書要約
- RAG 回答
- ログ監視
- CSV 監視
- 議事録草案生成
- 開発補助
- 検索→要約→実行の多段フロー
