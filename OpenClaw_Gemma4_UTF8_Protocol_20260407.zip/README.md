# OpenClaw × Gemma4 実装プロトコル（文字化けし難いZIP版）

このZIPは、YouTube動画
「タダでAIエージェントが無限に動かせるようになったので設定方法を公開します【OpenClaw】【Gemma4】」
を起点に、ユーザー環境向けに実装可能な形へ再構成したプロトコルです。

重要:
- 文字コードは UTF-8 で保存
- 改行は LF
- ファイル名は ASCII のみ
- 日本語本文は Markdown / TXT に限定
- 実装判断は Codex / Antigravity 側に委ねる前提
- 本書は「導入を強制しない」「採否は受け手が判断する」方針

参照:
- YouTube 検索結果で、上記タイトルの動画として確認
- URL: https://www.youtube.com/watch?v=Uw-1SzvM5Ck

同梱:
- 01_overview.md
- 02_target_architecture.md
- 03_install_protocol.md
- 04_routing_policy.md
- 05_operations.md
- 06_risks_and_limits.md
- 07_codex_handoff_prompt.txt
- 08_checklist.txt
- 09_env_template.env
- 10_docker_compose_example.yml
- 11_runbook_openclaw_gemma4.md
- 12_decision_matrix.md
