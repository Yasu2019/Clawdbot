# 04_routing_policy

## ルーティング基本表
| タスク | 第一候補 | 第二候補 | 備考 |
|---|---|---|---|
| 短い要約 | local_fast | cloud_budget | 大量処理向け |
| 文書検索後の整理 | local_reasoning | cloud_budget | RAG と相性良 |
| コード雛形生成 | local_reasoning | cloud_precise | 難問は上げる |
| 顧客提出メール | cloud_precise | cloud_budget | 品質優先 |
| 議事録草案 | local_reasoning | cloud_budget | 最終整形は上位可 |
| エラー調査 | local_reasoning | cloud_precise | ログ量で分岐 |
| 設計レビュー | cloud_precise | local_reasoning | 誤判定コスト高 |
| 監視コメント | local_fast | local_reasoning | 常時稼働向け |

## エスカレーション条件
- 長文で指示追従が崩れた
- 図面や仕様整合が重要
- 外部提出文書
- 失敗再試行回数超過
- セーフティ上の曖昧さ

## コスト最適化原則
1. まず local_fast
2. ダメなら local_reasoning
3. それでも不十分なら cloud_precise
4. ただし外部提出物は最初から cloud_precise でもよい
