# Docker内Remotion確認手順

## 目的

あなたの環境に **Remotion 本体** と **Agent Skills** がどこまで入っているかを、壊さずに確認します。

---

## 1. 稼働中コンテナを確認

```bash
docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Status}}"
```

Remotion 専用名でなくても、以下のようなコンテナ名・用途に入っていることがあります。

- node
- frontend
- tools
- workspace
- devcontainer
- openclaw 系補助コンテナ
- 動画生成やメディア処理系の作業コンテナ

---

## 2. 候補コンテナに入る

```bash
docker exec -it <container_name> bash
```

Alpine 系なら:

```bash
docker exec -it <container_name> sh
```

---

## 3. Node / npm / npx を確認

```bash
node -v
npm -v
npx --version
```

Remotion は Node ベースのため、ここが欠けている場合はそのコンテナでは直接運用しにくいです。

---

## 4. Remotion の痕跡を探す

### package.json 検索

```bash
find / -name package.json 2>/dev/null | head -200
```

### Remotion 依存の検索

```bash
grep -R '"remotion"' /app /workspace /workspaces /usr/src/app 2>/dev/null
```

### node_modules の検索

```bash
find / -type d -name "@remotion" 2>/dev/null
find / -type d -name "remotion" 2>/dev/null | head -50
```

---

## 5. Agent Skills の痕跡を探す

```bash
find / -iname "*skills*.md" 2>/dev/null
find / -iname "skills.md" 2>/dev/null
find / -iname ".skills" 2>/dev/null
```

補助的に以下も確認:

```bash
grep -R "remotion-dev/skills" /app /workspace /workspaces /usr/src/app 2>/dev/null
```

---

## 6. プロジェクト直下での確認

候補プロジェクトへ移動し、以下を確認します。

```bash
cat package.json
ls -la
npm ls remotion
```

### ここで見たいもの

- `remotion`
- `@remotion/*`
- `src/`
- `remotion.config.*`
- `Root.tsx`
- `index.ts`
- `skills.md` など

---

## 7. 既存環境で起動確認

```bash
npm install
npm run dev
```

Remotion Studio が起動できれば、本体はかなり揃っています。公式でもローカルプレビューは `npm run dev` を案内しています。citeturn790749search1

---

## 8. レンダリング確認

```bash
npx remotion compositions
npx remotion render
```

Remotion 公式 CLI では、composition の確認やレンダリングが可能です。citeturn790749search6turn790749search7turn790749search9

---

## 判定の目安

### Remotionあり / Skillsなし
- `remotion` は package.json にある
- Studio は起動する
- でも `skills.md` などが無い

→ **Agent Skills のみ追加**

### Remotionあり / Skillsあり
- `skills.md` や skills 関連ファイルがある
- 既に AI 前提で構成済み

→ **そのまま Claude Code で実行テスト**

### Remotionなし
- 依存にも痕跡が無い
- Studio も起動不可

→ **新規作成**
