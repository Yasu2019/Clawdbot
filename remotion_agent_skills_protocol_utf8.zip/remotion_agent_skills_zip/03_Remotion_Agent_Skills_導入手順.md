# Remotion Agent Skills 導入手順

## A. 既存 Remotion プロジェクトへ追加する場合

プロジェクト直下で:

```bash
npm install
npx skills add remotion-dev/skills
```

Remotion 公式の Agent Skills ページでは、このコマンドで skills を追加する案内です。citeturn790749search0

### 追加後に確認するもの

- `skills.md` または skills 関連ファイル
- 追加されたテンプレ / ガイド
- プロジェクト構成に破綻がないか

その後:

```bash
npm run dev
```

---

## B. 新規作成する場合

```bash
npx create-video@latest
```

Remotion 公式の Claude Code 向けページでは、新規作成時に以下を推奨しています。citeturn790749search1

- Blank template
- TailwindCSS = Yes
- Skills = Yes

### 非対話の作成例

```bash
npx create-video --yes --blank my-video
cd my-video
npm install
npx skills add remotion-dev/skills
```

Remotion 公式の CLI ドキュメントでは、`--yes` 利用時は Agent Skills が自動では入らず、別途追加する案内です。citeturn790749search5

---

## C. Docker コンテナ内で導入する場合の注意

### 1. 永続ボリューム上で作業する
コンテナ再作成で消えない場所にプロジェクトを置くこと。

例:
- `/workspace/remotion-agent-video`
- `/app/projects/remotion-agent-video`

### 2. node_modules の権限に注意
ホストとコンテナの UID/GID 差で npm install が失敗することがあります。

### 3. headless Chrome 依存に注意
Linux コンテナではレンダリング時にブラウザ関連依存が問題になることがあります。Remotion CLI は Linux 環境向けの実行上の配慮をドキュメント化しています。citeturn790749search3turn790749search7

---

## D. 最小確認コマンド

```bash
npm run dev
npx remotion compositions
npx remotion render
```

---

## E. 一番安全な導入方針

既存環境を壊したくない場合は、既存プロジェクトに直投入せず、
**専用の新規フォルダを1つ作る** のが安全です。

例:

```bash
mkdir -p /workspace/remotion-agent-video
cd /workspace/remotion-agent-video
npx create-video@latest
```
