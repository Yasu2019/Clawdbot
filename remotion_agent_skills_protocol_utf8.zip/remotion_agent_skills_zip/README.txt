Remotion Agent Skills 導入・確認プロトコル

このZIPは UTF-8 で作成しています。
文字化けを避けるため、展開後は VS Code / Notepad / Cursor / Claude Code / Codex CLI など UTF-8 対応エディタで開いてください。

同梱ファイル:
- 00_最初にお読みください.md
- 01_結論.md
- 02_Docker内Remotion確認手順.md
- 03_Remotion_Agent_Skills_導入手順.md
- 04_ClaudeCode_実行プロトコル.md
- 05_OpenClaw_Antigravity_連携メモ.md
- 06_トラブルシュート.md
- 07_サンプル指示文_日本語.md
- verify_remotion_docker.sh
- verify_remotion_docker.ps1
