# Claude Code 実行プロトコル

## 前提

- プロジェクト内に Remotion がある
- Agent Skills が追加済み
- `npm run dev` が通る

---

## 1. Studio を起動

```bash
npm run dev
```

---

## 2. 別ターミナルで Claude Code を起動

```bash
claude
```

Remotion 公式も、Studio 用ターミナルと Claude 実行ターミナルを分ける流れを案内しています。citeturn790749search1

---

## 3. 最初の日本語プロンプト例

```text
このRemotionプロジェクトで、製造業の品質改善活動を説明する45秒動画を作成してください。
要件:
- 言語: 日本語
- アスペクト比: 16:9
- 雰囲気: 落ち着いた企業向け、青基調
- シーン数: 5シーン
- 内容:
  1. タイトル
  2. 現状課題
  3. 改善施策
  4. 改善結果グラフ
  5. まとめ
- テキストは読みやすく
- 過度な演出は避ける
- ダミーデータでよいので棒グラフを1つ入れる
- まずはプレビュー可能な状態まで実装してください
```

---

## 4. 修正指示のコツ

悪い例:

```text
いい感じにして
```

良い例:

```text
3シーン目の改善施策は、左にアイコン、右に3項目の箇条書きで表示してください。
アニメーションはフェード＋スライドのみで、派手なズームは不要です。
```

---

## 5. 出力確認

```bash
npx remotion compositions
npx remotion render
```

公式ドキュメントでも、composition の確認と render CLI が案内されています。citeturn790749search6turn790749search7turn790749search9

---

## 6. Windows シェル注意

Remotion 公式では、`--props` にインライン JSON を渡す方法は Windows シェルでクォートが崩れやすく、ファイル指定が推奨されています。citeturn790749search6

例:

```bash
npx remotion render MyComp out/video.mp4 --props=./props.json
```
