#!/usr/bin/env bash
set -e

echo "=== Running containers ==="
docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Status}}"

echo
echo "=== Hint ==="
echo "Pick a likely Node/frontend/workspace container and run:"
echo "docker exec -it <container_name> bash"
echo
echo "Inside the container, try:"
echo "node -v"
echo "npm -v"
echo "find / -name package.json 2>/dev/null | head -200"
echo "grep -R '\"remotion\"' /app /workspace /workspaces /usr/src/app 2>/dev/null"
echo "find / -iname '*skills*.md' 2>/dev/null"
