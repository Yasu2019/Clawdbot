# Copilot Pro Decision Template

## Decision
- Value: FULL_ADOPT / PARTIAL_ADOPT / HOLD / REJECT / MERGE_ONLY

## Summary
- What this package does
- What parts are useful
- What parts are risky

## Existing Components Check
- Existing similar service:
- Existing similar flow:
- Existing similar dashboard:
- Existing similar data store:

## Conflict Check
- Docker Compose conflicts:
- Port conflicts:
- Workflow duplication:
- Data duplication:
- Security concerns:

## Adoption Recommendation
### Keep
- item
### Modify
- item
### Reject
- item

## Rollout Order
1.
2.
3.

## Final Notes
- human approval gates
- rollback plan
- monitoring requirements
