AI Integrated Protocol Package
Encoding: UTF-8
Line ending: LF

Purpose:
- Provide a "safe but comprehensive" package
- Include almost all major components
- Avoid immediate full activation that could break the system

IMPORTANT:
You said Copilot Pro will decide whether to adopt or reject.
Therefore this package is written for Copilot Pro review.

Copilot Pro MUST decide:
1. Adopt fully
2. Adopt partially
3. Reject
4. Postpone
5. Merge into existing system only

MANDATORY REVIEW ORDER:
1. Check for conflicts with existing Docker Compose, n8n, Portal cards, Gmail flows, Qdrant, Langfuse, LiteLLM, Paperless, Docling, SearXNG
2. Check API cost impact
3. Check security / privacy impact
4. Check maintenance burden
5. Check whether current system already provides similar functions
6. Decide rollout order
7. Only then implement

Recommended rollout:
Phase 1: Gmail monitoring only
Phase 2: task extraction and gap detection
Phase 3: internal knowledge search
Phase 4: auto research
Phase 5: self-improvement loop and advanced routing

Do NOT enable everything at once.
