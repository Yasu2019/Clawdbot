-- Example only
-- Copilot Pro must adapt to the existing DB strategy

CREATE TABLE monitored_emails (
  id TEXT PRIMARY KEY,
  source_message_id TEXT NOT NULL,
  sender TEXT,
  recipients TEXT,
  subject TEXT,
  body_text TEXT,
  received_at TEXT,
  raw_json TEXT
);

CREATE TABLE extracted_items (
  id TEXT PRIMARY KEY,
  email_id TEXT NOT NULL,
  item_type TEXT,
  layer TEXT,
  content TEXT,
  confidence REAL,
  created_at TEXT
);

CREATE TABLE detected_gaps (
  id TEXT PRIMARY KEY,
  email_id TEXT NOT NULL,
  description TEXT,
  priority TEXT,
  confidence REAL,
  created_at TEXT
);
