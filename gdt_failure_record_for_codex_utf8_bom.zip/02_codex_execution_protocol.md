﻿# Codex / ローカルLLM 実行プロトコル（GD&T 2D→3D 整合版）

## 0. 絶対ルール
1. **図面の文字ラベルだけで datum 判定するな**
2. **正面1枚だけで成功と言うな**
3. **STEPフェースIDを言えないなら “STEP面ベース” と言うな**
4. **理論面と実フェースを混同するな**
5. **表示できた ≠ 正しい位置**
6. **不確実なら不確実と書け**
7. **スクリーンショット未確認で“修正済み”と言うな**

## 1. 入力
- 2D図面PDF
- 3Dモデル（STEP優先）
- 既存HTML/ビューア（あれば）
- ユーザーの指摘スクリーンショット

## 2. 実行フェーズ
### Phase 1: 図面記号分類
各記号を datum / section / detail / dimension / note / GD&T frame へ分類する。
出力必須: symbol_id, text, symbol_type, source_view, confidence

### Phase 2: 要求の論理化
例:
- Datum A = right coining underside face
- Flatness 0.05 = local underside coining face only
- Parallelism //0.15|A = top faces indicated in sections B-B / C-C

### Phase 3: STEP/B-Rep feature extraction
抽出対象:
- planar faces
- cylindrical faces
- axes
- candidate median planes
- face centers
- face normals
- face extents / area

出力必須:
- face_id
- face_type
- center
- normal
- bbox / extents
- area

### Phase 4: 2D→3D対応付け
各 requirement に対して 3D候補を結びつける。

### Phase 5: 描画
描画は少なくとも以下を分離する。
- exact geometry layer
- debug overlay layer
- labels / callouts
- helper arrows

### Phase 6: 検証
必須:
- front view
- side view
条件付き:
- top view
- local crop

### Phase 7: 成功判定
以下すべてを満たしたら success。
- symbol classification reviewed
- chosen face/axis identified
- exact geometry rendered
- front ok
- side ok
- explanation text matches rendering
- unresolved_points is empty or explicitly documented

## 3. 失敗時の再実行ループ
1. 失敗スクリーンショットを回収
2. failure_catalog へ登録
3. root cause を drawing misread / face mapping error / transform error / rendering bug / verification gap / UI misunderstanding に分類
4. 教育プロトコルへ再発防止ルールを追加
5. 同じ型の過去失敗を検索
6. 修正版を再生成
7. 再度 front+side で検証

## 4. 禁止表現
- 「合っています」(証拠なし)
- 「STEP面ベースです」(face idなし)
- 「正しいです」(1視点のみ)
- 「大丈夫です」(根拠なし)
- 「描画できています」(scene evidenceなし)

代替表現:
- 「現時点の証拠では front は整合、side は未確認」
- 「face #79/#117 を使って配置」
- 「理論面として定義、実在フェースではない」
- 「デバッグ表示なので最終位置ではない」
