﻿# GD&T 2D/3D 整合化 作業の失敗事例・原因・対策・再発防止パッケージ

このZIPは、今回の一連の作業で発生した失敗、誤読、実装不備、検証漏れを **Codex / OpenClaw / ローカルLLM** に引き渡すための再発防止用パッケージです。

## 目的
- 類似の失敗を次回以降に繰り返さない
- ローカルLLMやCodexに「何を疑うべきか」を明示する
- OpenClaw側のアプリ設計へ、具体的なガードレールを返す
- 単なる反省文ではなく、機械的に使えるルール/チェックリスト/失敗DBとして利用する

## 収録ファイル
- `00_master_postmortem.md`
  - 全体総括
- `01_failure_catalog.json`
  - 失敗事例を機械可読で整理したカタログ
- `01_failure_catalog_summary.csv`
  - 失敗一覧の簡易表
- `02_codex_execution_protocol.md`
  - Codex/ローカルLLM向けの実行プロトコル
- `03_openclaw_app_feedback.md`
  - OpenClaw側アプリ設計への具体的フィードバック
- `04_regression_test_checklist.md`
  - リグレッションテスト観点
- `05_observability_logging_schema.json`
  - ログ設計の最小スキーマ
- `06_version_timeline.md`
  - 各版(v31〜v61相当)の失敗・改善の流れ
- `07_failure_prevention_prompt.md`
  - Codex/ローカルLLMへ最初に読ませる短縮版プロンプト

## 文字コード
すべて **UTF-8 with BOM** です。
文字化け対策としてBOM付きで保存しています。
