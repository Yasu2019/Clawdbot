﻿# OpenClaw アプリ設計へのフィードバック（再発防止向け）

## 1. 問題設定
今回の連続失敗は、LLMの能力不足だけでなく、**アプリ側が失敗しやすい作りだった**ことも大きい。
したがって、OpenClaw 側に以下のガードレールが必要。

## 2. 必須コンポーネント
### 2.1 Symbol Classifier
datum / section / detail / note / dimension / GD&T frame を分類する。
OCR文字だけでなく、周囲の図形パターンも見ること。

### 2.2 CAD Feature Extractor
STEP/B-Rep から以下を抽出する。
- planar face list
- cylindrical face list
- candidate axes
- candidate median planes
- face adjacency graph

### 2.3 Requirement Mapper
図面要求を 3D候補へ対応付ける。
例:
- datum A -> face #X
- parallelism_BB -> face #Y
- parallelism_CC -> face #Z
- datum E -> cylinder axis #W

### 2.4 Theory Geometry Builder
実フェースが存在しない理論面を生成する。
- offset plane
- median plane
- derived axis
- intersection line

### 2.5 Multi-view Validator
最低でも front / side を自動評価する。必要なら top / local crop も。

### 2.6 Claim Gate
以下が揃わないと「完了」と出力できない。
- chosen face ids
- screenshots
- pass/fail by view
- unresolved items list

## 3. UI側の改善
### 3.1 略語を減らす
DRFより「基準の組み合わせ」「基準面」「基準軸」など説明中心にする。

### 3.2 Debug/Exact を分ける
- Debug overlay
- Exact placement
を明示し、色も変える。

### 3.3 状態を常時表示
- 表示成功
- 位置確認待ち
- 正面OK
- 側面NG
などを見える化する。

## 4. 重要な設計思想
1. **モデルを賢くする前に、失敗しにくい枠組みを作る**
2. **成功判定はLLMの主観に任せない**
3. **証拠のない断定をUI/プロンプトで禁止する**
4. **説明と描画を同じソースから生成する**
5. **図面読解と3D配置を同じ一発推論にしない**
