﻿# Codex / ローカルLLM 初回読込用ショートプロンプト

このジョブでは、2D図面と3DモデルのGD&T整合を扱う。
次の失敗を繰り返してはならない。

1. A/B/C/D/E の文字だけで datum 判定するな
2. 断面記号と詳細図記号を datum と混同するな
3. 1視点だけで正しいと言うな
4. STEP face id を出せないなら STEP面ベースと言うな
5. 理論面と実フェースを混同するな
6. 表示できたことと、位置が正しいことを混同するな
7. デバッグ表示を最終版と言うな
8. 不確実なら必ず未確定と書け

必須出力:
- requirement list
- candidate face ids
- chosen face ids / axis ids
- front/side validation
- unresolved points

禁句:
- 「たぶん合っています」
- 「大丈夫です」
- 「修正済みです」(証拠なし)
