﻿# リグレッションテスト・チェックリスト

## A. 図面読解
- [ ] A/B/C/D/E が datum か section/detail か分類した
- [ ] datum の矢示面を確認した
- [ ] 理論面か実フェースか区別した
- [ ] 平面度/平行度/位置度の対象面を限定できている

## B. STEP/B-Rep
- [ ] planar faces 抽出済み
- [ ] cylindrical faces 抽出済み
- [ ] candidate face id 一覧がある
- [ ] chosen face id を記録した
- [ ] chosen axis id を記録した

## C. 描画
- [ ] ボタン押下で表示される
- [ ] scene.add されている
- [ ] exact layer と debug layer が分かれている
- [ ] ラベルだけではなく対象面/軸が見える
- [ ] 説明文が描画内容と一致している

## D. 検証
- [ ] 正面で妥当
- [ ] 側面で妥当
- [ ] 必要なら上面で妥当
- [ ] ローカル拡大でも妥当
- [ ] ユーザー指摘スクリーンショットと矛盾しない

## E. 完了宣言前
- [ ] unresolved item を列挙した
- [ ] “STEP面ベース” の根拠(face id等)がある
- [ ] 不確実な点を断定していない
- [ ] 成功条件を満たした
