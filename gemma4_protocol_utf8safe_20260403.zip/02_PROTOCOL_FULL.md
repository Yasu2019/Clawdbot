﻿# Full Protocol: Gemma 4 Integration for OpenClaw / Ollama / LiteLLM

## 1. Goal

This protocol tells Codex CLI how to evaluate and optionally integrate Gemma 4 into the user's
existing local AI stack while minimizing conflict with current services.

Important instruction to Codex CLI:
- Do NOT assume this should be adopted fully.
- Re-check compatibility with the existing stack before changing anything.
- Prefer partial adoption if that gives better stability / cost / quality balance.
- Keep rollback easy.

---

## 2. Design Principles

1. Preserve the existing stable path.
2. Introduce Gemma 4 as an additive provider, not a destructive replacement.
3. Separate tasks by difficulty and business risk.
4. Measure before promoting.
5. Keep config, logs, and routing reversible.
6. Avoid any change that breaks existing OpenClaw cards, MCP flows, RAG, or observability.

---

## 3. Assumed Existing Architecture

Representative components:
- OpenClaw gateway
- Portal dashboard
- LiteLLM proxy
- Ollama
- Qdrant
- n8n
- Langfuse / observability
- Docker Desktop on Windows + WSL2

Likely local inference path:
Client -> OpenClaw -> LiteLLM -> Ollama -> Gemma 4 model

Fallback path:
Client -> OpenClaw -> LiteLLM -> Cloud provider

---

## 4. Risk Classification

### Low-risk tasks suitable for Gemma 4 first
- chunk summarization
- OCR post-cleanup draft
- rough extraction
- tag assignment
- manufacturing document classification
- draft RAG answer generation
- code explanation
- command generation with review

### Medium-risk tasks
- internal email draft
- SOP rewrite draft
- issue triage
- root-cause candidate listing
- spreadsheet formula help
- slide outline drafting

### High-risk tasks to keep on cloud first
- external customer final response
- formal CAPA conclusion
- technical commitments
- compliance interpretation
- supplier blame / causality conclusion
- high-stakes strategic recommendation

---

## 5. Recommended Adoption Strategy

### Stage A: non-invasive install
- Pull Gemma 4 in Ollama
- Run local CLI tests only
- No routing changes yet

### Stage B: LiteLLM registration
- Register Gemma 4 as a new model alias
- Keep existing default untouched
- Test direct calls via LiteLLM

### Stage C: limited routing
Route only:
- summarization
- extraction
- low-risk RAG draft tasks

### Stage D: A/B evaluation
Compare Gemma 4 vs current local model vs current cloud model for:
- latency
- hallucination rate
- instruction following
- Japanese quality
- structured output stability
- code usefulness
- business writing safety

### Stage E: selective promotion
Only promote if:
- quality is acceptable
- failure rate is controlled
- RAM pressure is tolerable
- concurrency does not damage other services

---

## 6. Resource Guidance

For a 48 GB RAM machine:
- start from smaller Gemma 4 variant
- keep one moderate model active at a time
- avoid loading too many large Ollama models simultaneously
- monitor swap, WSL memory pressure, and latency spikes

Operational advice:
- unload idle models when possible
- do not benchmark during heavy Docker background activity
- verify that Qdrant, Paperless, browser automation, and OpenClaw still behave normally

---

## 7. Implementation Steps

### Step 1: baseline capture
Before any change, record:
- current Docker compose status
- Ollama model list
- active LiteLLM config
- OpenClaw routing config
- CPU / RAM idle usage
- average latency of current key tasks

### Step 2: backup
Back up:
- compose files
- LiteLLM config
- OpenClaw config
- custom prompts
- routing rules
- model alias mappings

### Step 3: install model
Use Ollama pull commands for Gemma 4 candidate variants.
Do not remove existing models yet.

### Step 4: smoke test locally
Test prompts:
- Japanese summary
- English summary
- extraction to JSON
- code explanation
- manufacturing memo rewrite

### Step 5: register in LiteLLM
Add a new model alias such as:
- gemma4_local_small
- gemma4_local_main

Do not override current production alias yet.

### Step 6: direct API test
Call through LiteLLM and confirm:
- correct response path
- token usage logging
- observability traces
- error behavior
- timeout behavior

### Step 7: route a narrow task class
Example:
- all "summarize_chunk" tasks -> gemma4_local_small
- all "extract_table_fields" tasks -> gemma4_local_main
Keep fallback to cloud on failure.

### Step 8: benchmark
Use a fixed evaluation set from real work:
- supplier emails
- audit clauses
- defect summaries
- meeting notes
- coding tasks
- RAG questions

### Step 9: promote only after review
Only after benchmark review, expand routing.

---

## 8. Suggested Evaluation Matrix

Score each 1 to 5:

- Japanese naturalness
- technical term retention
- instruction adherence
- JSON formatting stability
- refusal / boundary behavior
- hallucination control
- concise answering
- code utility
- long context usefulness
- local cost advantage
- latency
- stability under concurrent load

Also log:
- failed responses
- malformed JSON
- repeated loops
- missing citation discipline in RAG workflows
- overconfident wrong answers

---

## 9. Example Routing Policy

### Use Gemma 4 local by default for:
- preprocessing
- retrieval result compression
- first-pass classification
- internal rough drafts
- transformation tasks

### Use cloud by default for:
- final customer-facing text
- executive summary with implications
- ambiguous root-cause interpretation
- complex planning
- multi-tool supervision
- final safety / compliance wording

### Hybrid policy:
1. Gemma 4 drafts
2. cloud reviews only when threshold exceeded
3. optional auto-escalation when:
   - confidence low
   - task tagged high-risk
   - output malformed
   - prompt length too large
   - user explicitly asks for highest quality

---

## 10. Conflict Checks for Codex CLI

Codex CLI should inspect:

1. Does the new model alias collide with existing LiteLLM names?
2. Does OpenClaw assume OpenAI-compatible parameters that Ollama path cannot satisfy?
3. Are there prompt templates tuned too specifically for another model family?
4. Will added model load cause WSL memory pressure that hurts Qdrant / browser / Paperless?
5. Does observability still capture the new route cleanly?
6. Are fallback loops possible?
7. Will existing Telegram / MCP / n8n flows accidentally start using Gemma 4 without validation?
8. Does any safety middleware depend on previous provider metadata?
9. Does current RAG chain require citation behavior that Gemma 4 fails to follow reliably?
10. Is Japanese business writing quality sufficient for internal use only, or safe for external use?

---

## 11. Minimal Rollback Plan

Rollback must be trivial:
- keep old LiteLLM aliases
- keep old default route
- disable new route by config flag
- do not delete previous models or configs until stable
- document the last-known-good state

---

## 12. What Codex CLI Should Produce

Preferred deliverables:
1. updated routing proposal
2. exact changed config diff
3. rollback diff
4. benchmark results table
5. recommendation:
   - adopt fully
   - adopt partially
   - keep as experimental only
   - reject for now

---

## 13. Recommended Final Decision Rule

Adopt Gemma 4 partially if:
- low-risk task quality is good
- latency is acceptable
- system stability remains good
- local cost reduction is meaningful

Do not force full adoption merely because the model is new.

The correct outcome may be:
- Gemma 4 for preprocessing and RAG drafting
- existing cloud model for final reasoning and high-risk writing
- previous local coder model retained for code-heavy tasks if it still wins

That is acceptable and often optimal.
