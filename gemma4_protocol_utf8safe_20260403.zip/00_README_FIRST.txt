﻿# Gemma 4 Integration Protocol (UTF-8 Safe Package)

This package is designed to reduce mojibake risk.

Encoding policy:
- All filenames are ASCII only.
- Main text files are saved as UTF-8 with BOM.
- Markdown and TXT copies are both included.
- Avoid renaming files into Japanese filenames before handing to Codex CLI.

Recommended handling:
1. Extract with Windows Explorer or 7-Zip.
2. Open with VS Code, Notepad, or Codex CLI.
3. Keep the folder path ASCII-only if possible.

Package contents:
- 00_README_FIRST.txt
- 01_EXEC_SUMMARY.txt
- 02_PROTOCOL_FULL.md
- 03_CODEX_HANDOFF_PROMPT.txt
- 04_LITELLM_EXAMPLE.yaml
- 05_OLLAMA_COMMANDS.sh
- 06_VALIDATION_CHECKLIST.txt
- 07_ADOPTION_POLICY.txt
