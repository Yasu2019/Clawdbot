﻿#!/usr/bin/env bash
set -e

# Replace model names with actual Gemma 4 tags available in your environment.
# Check `ollama list` and official naming before production use.

ollama pull gemma4:small
ollama pull gemma4:main

echo "Run quick tests"
ollama run gemma4:small "次の文章を3行で要約してください。"
ollama run gemma4:main "次の内容をJSON形式で整理してください。"
