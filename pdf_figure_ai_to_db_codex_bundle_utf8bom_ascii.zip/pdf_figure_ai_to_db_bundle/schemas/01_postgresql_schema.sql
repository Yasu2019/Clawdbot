﻿CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_sha256 TEXT NOT NULL UNIQUE,
    source_type TEXT,
    page_count INT,
    detected_pdf_type TEXT,
    ingestion_status TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS pages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    page_no INT NOT NULL,
    width DOUBLE PRECISION,
    height DOUBLE PRECISION,
    native_text_len INT,
    ocr_text_len INT,
    route_selected TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE(document_id, page_no)
);

CREATE TABLE IF NOT EXISTS items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    page_id UUID NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
    item_type TEXT NOT NULL,
    parent_item_id UUID NULL REFERENCES items(id) ON DELETE SET NULL,
    group_id TEXT NULL,
    bbox_x0 DOUBLE PRECISION NULL,
    bbox_y0 DOUBLE PRECISION NULL,
    bbox_x1 DOUBLE PRECISION NULL,
    bbox_y1 DOUBLE PRECISION NULL,
    source_method TEXT NOT NULL,
    source_asset_path TEXT NULL,
    text_original TEXT NULL,
    text_normalized TEXT NULL,
    ai_summary TEXT NULL,
    language_code TEXT NULL,
    confidence DOUBLE PRECISION NULL,
    hash_sha256 TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS figures (
    item_id UUID PRIMARY KEY REFERENCES items(id) ON DELETE CASCADE,
    figure_type TEXT,
    caption_original TEXT NULL,
    caption_ai TEXT NULL,
    vlm_model TEXT NULL,
    vlm_confidence DOUBLE PRECISION NULL,
    review_required BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS tables (
    item_id UUID PRIMARY KEY REFERENCES items(id) ON DELETE CASCADE,
    extraction_engine TEXT,
    table_json JSONB,
    markdown_text TEXT
);

CREATE TABLE IF NOT EXISTS embeddings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id UUID NOT NULL REFERENCES items(id) ON DELETE CASCADE,
    embedding_model TEXT NOT NULL,
    vector_store TEXT NOT NULL,
    vector_point_id TEXT NOT NULL,
    dim INT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    job_type TEXT NOT NULL,
    job_status TEXT NOT NULL,
    started_at TIMESTAMP NOT NULL DEFAULT NOW(),
    ended_at TIMESTAMP NULL,
    error_message TEXT NULL,
    retry_count INT NOT NULL DEFAULT 0,
    runtime_ms BIGINT NULL
);

CREATE INDEX IF NOT EXISTS idx_documents_sha ON documents(file_sha256);
CREATE INDEX IF NOT EXISTS idx_pages_doc_page ON pages(document_id, page_no);
CREATE INDEX IF NOT EXISTS idx_items_doc_page_type ON items(document_id, page_id, item_type);
CREATE INDEX IF NOT EXISTS idx_items_group_id ON items(group_id);
CREATE INDEX IF NOT EXISTS idx_embeddings_item_id ON embeddings(item_id);
