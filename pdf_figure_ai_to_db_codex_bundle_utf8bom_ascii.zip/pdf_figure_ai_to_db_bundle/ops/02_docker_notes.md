﻿# Docker notes

## Why keep OCR and parsing modular
- OCRmyPDF may be easier to install as a system-level package or dedicated container
- Tesseract language packs should be explicit
- Docling and VLM dependencies may evolve quickly
- Keeping OCR, parsing, and storage as separate services reduces upgrade risk

## Suggested service split
- pdf_ingest_worker
- ocr_worker
- docling_worker
- db_writer
- vector_writer

## Minimal environment variables
- POSTGRES_DSN
- QDRANT_URL
- OCR_LANG=jpn+eng
- ENABLE_REMOTE_VLM=false
- TEMP_DIR=/tmp/pdf_ingest
- LOG_LEVEL=INFO

## Security defaults
- mount local temp volume only
- no remote VLM unless approved
- delete temp image crops after successful ingestion unless audit retention requires them
