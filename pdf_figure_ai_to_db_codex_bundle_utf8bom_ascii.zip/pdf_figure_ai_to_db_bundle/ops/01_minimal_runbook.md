﻿# Minimal runbook

## 1. Detect PDF type
python scripts/detect_pdf_type.py input.pdf

## 2. If scanned or weak text, add OCR layer
python scripts/run_ocrmypdf.py input.pdf output_ocr.pdf

## 3. Native extraction
python scripts/extract_native_pymupdf.py output_ocr.pdf work/native

## 4. Optional table extraction
python scripts/extract_tables_pdfplumber.py output_ocr.pdf work/tables.json

## 5. Optional Docling structure / picture annotation
python scripts/parse_with_docling.py output_ocr.pdf work/docling

## 6. Canonicalize
python scripts/canonicalize_output.py work/native/native_extract.json work/canonical.json

## 7. Load PostgreSQL schema
psql postgresql://USER:PASS@HOST:5432/DB -f schemas/01_postgresql_schema.sql

## 8. Store canonical records
python scripts/store_to_postgres.py work/canonical.json postgresql://USER:PASS@HOST:5432/DB

## 9. Store vectors
python scripts/store_to_qdrant.py work/canonical.json http://localhost:6333 pdf_items

## 10. Verify
- documents row inserted
- pages row count matches PDF page count
- figure rows exist for docs with images
- qdrant point count > 0
