﻿#!/usr/bin/env bash
set -euo pipefail

python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r scripts/requirements_min.txt
# Optional:
# pip install -r scripts/requirements_optional.txt
