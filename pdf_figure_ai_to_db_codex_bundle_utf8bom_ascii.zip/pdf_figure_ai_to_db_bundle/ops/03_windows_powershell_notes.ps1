﻿# Example Windows / PowerShell setup notes
# Adjust to your environment.

python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r scripts\requirements_min.txt

# Optional:
# pip install -r scripts\requirements_optional.txt

# OCRmyPDF is often easier via WSL or dedicated container on Windows.
