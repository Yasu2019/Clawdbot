﻿# Overview and adoption guide

## Objective

Build a production-friendly pipeline that can:
- read PDF text accurately,
- understand figures, charts, tables, and illustrations,
- attach AI-generated explanations to non-text content,
- store everything in a DB with provenance,
- support later search / RAG / audit.

## Recommended adoption policy

Codex should decide among:
- full adoption,
- partial adoption,
- hold / defer.

It must check:
1. Existing code conflict risk
2. Existing container / app overlap
3. Whether a lighter integration is enough
4. Whether local-only processing is required for security
5. Whether OCR / VLM cost is acceptable

## Recommended default decision

### A. Full adoption when all are true
- You need text + figure understanding
- You need searchable DB / RAG
- You need provenance by page and bbox
- You already have PostgreSQL and Qdrant
- Security favors local processing

### B. Partial adoption when any of these apply
- Existing ingestion already handles text well
- Only figure understanding is missing
- Existing OCR already exists
- You only need a pilot for limited documents

### C. Hold when any of these apply
- There is no clear downstream use case
- Storage schema is not yet agreed
- Local VLM capacity is too weak
- Existing portal / workflow already has a better equivalent

## Suggested phased rollout

### Phase 1
- PDF type detection
- native text extraction
- OCR fallback
- save text chunks + images + page metadata

### Phase 2
- Docling structure extraction
- picture annotation
- figure captions / chart summaries
- PostgreSQL + Qdrant integration

### Phase 3
- benchmark set
- confidence scoring
- retry routing
- queue / workflow integration
- portal status card / observability

## What "AI understands figures" should mean in scope

In this bundle, figure understanding means:
- classify figure type
- generate short description
- extract nearby caption if present
- relate figure to page context
- create embeddings for retrieval
- keep image asset and bbox for evidence

It does NOT automatically guarantee:
- exact engineering interpretation
- exact dimension reading from all drawings
- perfect small text reading inside charts
- legally safe interpretation without review

## Recommended confidence policy

Store confidence per item:
- extraction_confidence
- ocr_confidence
- figure_description_confidence
- routing_reason

Low-confidence items should be flagged for review.

## Suggested local-first policy

Prefer local processing in this order:
1. native extraction
2. local OCR
3. local VLM
4. remote API only when explicitly approved

## Recommended canonical output units

Every extracted item should keep:
- document_id
- page_no
- item_type
- bbox
- source_method
- source_asset_path
- text_original
- text_normalized
- ai_summary
- embedding_model
- embedding_vector_id
- hash_sha256
