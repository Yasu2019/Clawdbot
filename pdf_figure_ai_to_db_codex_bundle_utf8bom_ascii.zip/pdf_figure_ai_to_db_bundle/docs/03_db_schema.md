﻿# DB schema proposal

## Design goals
- searchable
- auditable
- provenance-preserving
- supports text, tables, figures, embeddings
- supports reprocessing and versioning

## Core tables

### documents
- id UUID PK
- file_name TEXT
- file_path TEXT
- file_sha256 TEXT UNIQUE
- source_type TEXT
- page_count INT
- detected_pdf_type TEXT
- ingestion_status TEXT
- created_at TIMESTAMP
- updated_at TIMESTAMP

### pages
- id UUID PK
- document_id UUID FK
- page_no INT
- width FLOAT
- height FLOAT
- native_text_len INT
- ocr_text_len INT
- route_selected TEXT
- created_at TIMESTAMP

### items
Generic storage for chunks, tables, figures, captions, etc.
- id UUID PK
- document_id UUID FK
- page_id UUID FK
- item_type TEXT
- parent_item_id UUID NULL
- group_id TEXT NULL
- bbox_x0 FLOAT NULL
- bbox_y0 FLOAT NULL
- bbox_x1 FLOAT NULL
- bbox_y1 FLOAT NULL
- source_method TEXT
- source_asset_path TEXT NULL
- text_original TEXT NULL
- text_normalized TEXT NULL
- ai_summary TEXT NULL
- language_code TEXT NULL
- confidence FLOAT NULL
- hash_sha256 TEXT
- created_at TIMESTAMP

### figures
Optional figure-specific extension
- item_id UUID PK FK -> items.id
- figure_type TEXT
- caption_original TEXT NULL
- caption_ai TEXT NULL
- vlm_model TEXT NULL
- vlm_confidence FLOAT NULL
- review_required BOOLEAN DEFAULT FALSE

### tables
Optional table-specific extension
- item_id UUID PK FK -> items.id
- extraction_engine TEXT
- table_json JSONB
- markdown_text TEXT

### embeddings
- id UUID PK
- item_id UUID FK
- embedding_model TEXT
- vector_store TEXT
- vector_point_id TEXT
- dim INT
- created_at TIMESTAMP

### jobs
- id UUID PK
- document_id UUID FK
- job_type TEXT
- job_status TEXT
- started_at TIMESTAMP
- ended_at TIMESTAMP
- error_message TEXT NULL
- retry_count INT DEFAULT 0
- runtime_ms BIGINT NULL

## Suggested indexes
- documents(file_sha256)
- pages(document_id, page_no)
- items(document_id, page_id, item_type)
- items(group_id)
- figures(figure_type)
- embeddings(item_id)

## Why split items and figures
This avoids schema explosion.
Text, captions, images, tables, and summaries all share provenance fields.
Figure-specific fields live only where needed.

## Suggested enum values

### documents.detected_pdf_type
- born_digital
- scanned
- hybrid
- unknown

### items.item_type
- text_block
- body_chunk
- heading
- footer
- header
- table
- figure
- caption
- figure_summary
- table_summary

### items.source_method
- pymupdf_native
- pdfplumber_native
- ocrmypdf_tesseract
- docling_parse
- docling_vlm
- manual_review

## Review queue idea
Any item with low confidence or parse conflict should be inserted into a review queue table.
