﻿# Troubleshooting

## Symptom: Extracted text is empty
Possible causes:
- image-only scan
- encrypted / damaged PDF
- extraction library failure
Actions:
- check page char count
- try OCR route
- render page and verify visible text manually

## Symptom: Native text exists but quality is bad
Possible causes:
- broken font mapping
- reading order issue
- hybrid PDF with hidden low-quality text layer
Actions:
- compare native vs OCR text length and cleanliness
- use PyMuPDF blocks / words
- keep per-page route selection

## Symptom: Same image extracted multiple times
Possible causes:
- repeated xref reuse
Actions:
- de-duplicate by image hash

## Symptom: Figure description is vague
Possible causes:
- image crop too small
- no local caption context
- VLM too weak
Actions:
- include nearby text blocks
- expand crop slightly
- route hard cases to better local VLM or manual review

## Symptom: Table extraction is poor
Possible causes:
- scanned table without clear lines
- merged cells
- rotated table
Actions:
- OCR first
- test pdfplumber debugging
- store raw asset and mark for review

## Symptom: Mojibake in Japanese text
Possible causes:
- wrong encoding in downstream system
- font mapping issue from source PDF
Actions:
- keep UTF-8 end to end
- inspect raw extracted text
- compare native and OCR routes
- normalize whitespace only, not content prematurely

## Symptom: Retrieval misses figure content
Possible causes:
- only body text embedded
- figure summaries not embedded
Actions:
- embed captions and figure summaries as separate chunks
- link them with body group_id
