﻿# Benchmark plan

## Goal
Measure whether the pipeline is good enough for production.

## Dataset buckets
1. born-digital text-heavy PDFs
2. scanned Japanese PDFs
3. PDFs with charts and illustrations
4. PDFs with tables
5. hybrid PDFs

## Metrics
- native extraction text coverage
- OCR coverage
- OCR error examples
- figure extraction rate
- caption linking rate
- figure description usefulness
- retrieval hit rate
- job runtime
- failure rate

## Suggested manual review sheet
For each sample PDF:
- expected document type
- actual route
- text acceptable? yes/no
- figure extracted? yes/no
- figure summary useful? yes/no
- table acceptable? yes/no
- review notes

## Minimum pilot success target
- text acceptable on >= 90 percent of pages in pilot set
- at least one correct figure summary for target docs
- zero silent failures
