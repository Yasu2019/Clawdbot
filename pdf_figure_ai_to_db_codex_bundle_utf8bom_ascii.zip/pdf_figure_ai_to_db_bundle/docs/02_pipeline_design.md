﻿# Pipeline design

## End-to-end flow

1. Input PDF arrives
2. Compute file hash
3. Detect PDF type
   - born-digital
   - image-only scan
   - hybrid
4. If scan or weak text, run OCRmyPDF
5. Extract:
   - page text
   - text blocks
   - words
   - images
   - tables if needed
6. Run Docling for structure-aware parsing
7. Run picture annotation
8. Build canonical JSON
9. Chunk text for embeddings
10. Embed text and figure descriptions
11. Store:
   - PostgreSQL: metadata and provenance
   - Qdrant: vectors
12. Write job log and quality metrics

## Recommended tool roles

### PyMuPDF
Use for:
- quick PDF open
- page text
- text blocks
- word coordinates
- image extraction
- page rendering if needed

### pdfplumber
Use for:
- visual debugging
- lines / rectangles / chars
- tables
- layout inspection
- hard cases where coordinates matter

### OCRmyPDF
Use for:
- scanned PDFs
- adding searchable OCR text layer
- producing OCR-augmented PDF for later steps

### Docling
Use for:
- structured document model
- text / tables / pictures in a unified representation
- picture annotation via local or remote VLM
- export to JSON / Markdown-like forms

## Routing logic

### Route 1: born-digital PDF
- try native extraction first
- if character count and quality are good, skip OCR
- extract images and layout
- run Docling enrichment only where useful

### Route 2: scanned PDF
- OCR first
- then parse the OCR-augmented PDF
- extract images separately when needed
- run figure understanding

### Route 3: hybrid PDF
- compare native text quality vs OCR
- keep the better source per page or per block
- record source_method carefully

## Quality heuristics

Potential "native extraction is weak" signals:
- too few extracted chars on a text-heavy page
- excessive replacement characters
- abnormal whitespace patterns
- low Japanese character ratio when Japanese is expected
- repeated gibberish blocks

Potential "OCR is weak" signals:
- too many short garbage tokens
- impossible punctuation density
- mixed orientation without deskew
- captions detached from figure blocks

## Figure understanding flow

1. Extract image asset
2. Keep page number + bbox
3. Find nearby caption text on same page
4. Send image and context to VLM
5. Get:
   - figure_type
   - concise description
   - optional relation to surrounding text
6. Store both raw and normalized outputs

## Minimal figure prompt design

Inputs:
- page title or nearest heading
- nearby caption
- local surrounding text block
- image bytes or file path

Outputs:
- figure_type
- 1-2 sentence description
- keywords
- possible caution flag if unreadable

## Chunking guidance

Chunk separately:
- body text
- table text
- figure caption
- AI figure description

Do not merge all page content into a single chunk.
Keep links among related chunks by group_id.

## Provenance rules

Every record should preserve:
- file hash
- page number
- bbox if available
- extraction method
- model name
- timestamp
- retry count

## Failure handling

If any stage fails:
- keep raw artifacts
- mark job_status as partial
- continue best-effort for remaining stages
- never discard document silently

## Recommended local-first examples

Good local-first stack:
- PyMuPDF
- OCRmyPDF
- Tesseract with jpn+eng
- Docling with local VLM
- sentence-transformers or local embedding service
- PostgreSQL
- Qdrant

## Security note

For confidential documents:
- disable remote VLM by default
- keep temp files on local disk only
- scrub logs if they may contain document snippets
- avoid sending image assets to external APIs unless approved
