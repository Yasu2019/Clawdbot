﻿# Integration adapter ideas

## If an existing Paperless / Docling / RAG stack already exists
Prefer to add:
- a canonical exporter
- a figure description stage
- a PostgreSQL writer
- a vector writer for figure summaries

## If OCR already exists
Do not replace it immediately.
Instead:
- compare quality on pilot set
- preserve current OCR path
- add routing and confidence metrics first

## If existing ingestion already pushes text to vector DB
Add only:
- figure extraction
- caption linking
- figure summary embeddings
- provenance fields

## If observability already exists
Publish:
- docs processed
- OCR ratio
- figure extraction ratio
- failures by stage
- average runtime
