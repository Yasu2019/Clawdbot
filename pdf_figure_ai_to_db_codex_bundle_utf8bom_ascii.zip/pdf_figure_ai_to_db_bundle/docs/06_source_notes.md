﻿# Source notes for this bundle

These notes summarize why the recommended stack was chosen.

- PyMuPDF:
  fast native extraction, text blocks / words, image extraction, sorting support
- pdfplumber:
  detailed chars / lines / rectangles, table extraction, visual debugging
- OCRmyPDF:
  adds searchable OCR text layer to scanned PDFs
- Docling:
  unified document representation with text / tables / pictures and picture annotation via VLM
- PaddleOCR:
  strong document parsing path, useful when complex OCR / structure extraction is needed
- docTR:
  deep learning OCR library useful for advanced OCR flows

Codex should confirm exact versions in the target environment before locking APIs.
