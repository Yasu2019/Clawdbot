﻿from __future__ import annotations

import json
import sys
from pathlib import Path

import psycopg


def insert_document(cur, doc):
    cur.execute(
        """
        INSERT INTO documents (file_name, file_path, file_sha256, page_count, detected_pdf_type, ingestion_status)
        VALUES (%s, %s, %s, %s, %s, %s)
        RETURNING id
        """,
        (
            doc["file_name"],
            doc.get("file_path", doc["file_name"]),
            doc["file_sha256"],
            doc.get("page_count"),
            doc.get("detected_pdf_type"),
            "ingested",
        ),
    )
    return cur.fetchone()[0]


def main(canonical_json: str, dsn: str) -> None:
    payload = json.loads(Path(canonical_json).read_text(encoding="utf-8"))

    with psycopg.connect(dsn) as conn:
        with conn.cursor() as cur:
            document_id = insert_document(cur, payload["document"])

            page_id_map = {}
            for page in payload["pages"]:
                cur.execute(
                    """
                    INSERT INTO pages (document_id, page_no, route_selected)
                    VALUES (%s, %s, %s)
                    RETURNING id
                    """,
                    (document_id, page["page_no"], page.get("route_selected")),
                )
                page_id_map[page["page_no"]] = cur.fetchone()[0]

            for item in payload["items"]:
                bbox = item.get("bbox") or {}
                cur.execute(
                    """
                    INSERT INTO items (
                        document_id, page_id, item_type, group_id,
                        bbox_x0, bbox_y0, bbox_x1, bbox_y1,
                        source_method, source_asset_path,
                        text_original, text_normalized, ai_summary,
                        confidence, hash_sha256
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING id
                    """,
                    (
                        document_id,
                        page_id_map[item["page_no"]],
                        item["item_type"],
                        item.get("group_id"),
                        bbox.get("x0"),
                        bbox.get("y0"),
                        bbox.get("x1"),
                        bbox.get("y1"),
                        item["source_method"],
                        item.get("source_asset_path"),
                        item.get("text_original"),
                        item.get("text_normalized"),
                        item.get("ai_summary"),
                        item.get("confidence"),
                        item["hash_sha256"],
                    ),
                )
                item_id = cur.fetchone()[0]

                if item["item_type"] == "figure":
                    cur.execute(
                        """
                        INSERT INTO figures (item_id, figure_type, caption_original, caption_ai, vlm_model, vlm_confidence, review_required)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)
                        """,
                        (
                            item_id,
                            item.get("figure_type"),
                            item.get("caption_original"),
                            item.get("caption_ai"),
                            item.get("vlm_model"),
                            item.get("confidence"),
                            bool(item.get("review_required", False)),
                        ),
                    )

        conn.commit()

    print("Inserted into PostgreSQL successfully.")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python store_to_postgres.py canonical.json postgresql://...", file=sys.stderr)
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
