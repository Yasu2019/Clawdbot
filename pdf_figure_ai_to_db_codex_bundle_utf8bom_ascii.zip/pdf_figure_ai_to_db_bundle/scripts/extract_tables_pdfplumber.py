﻿from __future__ import annotations

import sys
import json
from pathlib import Path

import pdfplumber


def extract_tables(pdf_path: str, out_json: str) -> None:
    results = []
    with pdfplumber.open(pdf_path) as pdf:
        for page_idx, page in enumerate(pdf.pages):
            tables = page.extract_tables() or []
            for t_idx, table in enumerate(tables):
                rows = []
                for row in table:
                    rows.append([("" if cell is None else str(cell)) for cell in row])
                results.append({
                    "page_no": page_idx + 1,
                    "table_index": t_idx,
                    "row_count": len(rows),
                    "rows": rows,
                })

    Path(out_json).write_text(
        json.dumps(results, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python extract_tables_pdfplumber.py input.pdf output.json", file=sys.stderr)
        sys.exit(1)
    extract_tables(sys.argv[1], sys.argv[2])
