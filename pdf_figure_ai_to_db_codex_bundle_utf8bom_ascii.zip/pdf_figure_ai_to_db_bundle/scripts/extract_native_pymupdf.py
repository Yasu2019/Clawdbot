﻿from __future__ import annotations

import sys
import json
import hashlib
from pathlib import Path

import fitz  # PyMuPDF


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def extract_native(pdf_path: str, out_dir: str) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    doc = fitz.open(pdf_path)
    all_items = []

    for page_index, page in enumerate(doc):
        page_no = page_index + 1

        # Text blocks
        blocks = page.get_text("blocks") or []
        for b_idx, block in enumerate(blocks):
            x0, y0, x1, y1, text, *_ = block
            text = (text or "").strip()
            if not text:
                continue
            all_items.append({
                "page_no": page_no,
                "item_type": "text_block",
                "bbox": {"x0": x0, "y0": y0, "x1": x1, "y1": y1},
                "source_method": "pymupdf_native",
                "text_original": text,
                "text_normalized": text,
                "group_id": f"p{page_no}_tb{b_idx}",
                "confidence": None,
            })

        # Images
        seen_hashes = set()
        for img_idx, img in enumerate(page.get_images(full=True)):
            xref = img[0]
            info = doc.extract_image(xref)
            if not info:
                continue
            image_bytes = info["image"]
            image_ext = info.get("ext", "bin")
            image_hash = sha256_bytes(image_bytes)
            if image_hash in seen_hashes:
                continue
            seen_hashes.add(image_hash)

            img_name = f"page_{page_no:04d}_img_{img_idx:03d}.{image_ext}"
            img_path = out / img_name
            img_path.write_bytes(image_bytes)

            all_items.append({
                "page_no": page_no,
                "item_type": "figure",
                "bbox": None,
                "source_method": "pymupdf_native",
                "source_asset_path": str(img_path),
                "text_original": None,
                "text_normalized": None,
                "group_id": f"p{page_no}_img{img_idx}",
                "confidence": None,
            })

    payload = {
        "document": {
            "file_name": Path(pdf_path).name,
            "file_sha256": sha256_bytes(Path(pdf_path).read_bytes()),
            "detected_pdf_type": "unknown",
            "page_count": len(doc),
        },
        "pages": [{"page_no": i + 1} for i in range(len(doc))],
        "items": all_items,
    }

    out_json = out / "native_extract.json"
    out_json.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python extract_native_pymupdf.py input.pdf output_dir", file=sys.stderr)
        sys.exit(1)
    result = extract_native(sys.argv[1], sys.argv[2])
    print(json.dumps({"items": len(result["items"])}, ensure_ascii=False))
