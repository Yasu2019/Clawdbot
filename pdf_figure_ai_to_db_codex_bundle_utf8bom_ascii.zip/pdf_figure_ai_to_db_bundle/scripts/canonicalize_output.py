﻿from __future__ import annotations

import json
import sys
import hashlib
from pathlib import Path


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def build_canonical(native_json: str, out_json: str) -> None:
    payload = json.loads(Path(native_json).read_text(encoding="utf-8"))

    items = []
    for item in payload.get("items", []):
        normalized = {
            "page_no": item.get("page_no"),
            "item_type": item.get("item_type"),
            "group_id": item.get("group_id"),
            "bbox": item.get("bbox"),
            "source_method": item.get("source_method"),
            "source_asset_path": item.get("source_asset_path"),
            "text_original": item.get("text_original"),
            "text_normalized": item.get("text_normalized"),
            "ai_summary": item.get("ai_summary"),
            "figure_type": item.get("figure_type"),
            "caption_original": item.get("caption_original"),
            "caption_ai": item.get("caption_ai"),
            "confidence": item.get("confidence"),
        }
        normalized["hash_sha256"] = sha256_text(json.dumps(normalized, ensure_ascii=False, sort_keys=True))
        items.append(normalized)

    final_payload = {
        "document": payload["document"],
        "pages": payload["pages"],
        "items": items,
    }

    Path(out_json).write_text(
        json.dumps(final_payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python canonicalize_output.py native_extract.json canonical.json", file=sys.stderr)
        sys.exit(1)
    build_canonical(sys.argv[1], sys.argv[2])
