﻿from __future__ import annotations

import sys
import json
from pathlib import Path

import fitz  # PyMuPDF


def detect_pdf_type(pdf_path: str) -> dict:
    doc = fitz.open(pdf_path)
    total_pages = len(doc)
    page_stats = []
    text_like_pages = 0
    image_only_pages = 0

    for i, page in enumerate(doc):
        text = page.get_text("text", sort=True) or ""
        images = page.get_images(full=True)
        text_len = len(text.strip())

        if text_len > 30:
            page_type = "text_like"
            text_like_pages += 1
        elif images:
            page_type = "image_only"
            image_only_pages += 1
        else:
            page_type = "unknown"

        page_stats.append({
            "page_no": i + 1,
            "text_len": text_len,
            "image_count": len(images),
            "page_type": page_type,
        })

    if text_like_pages == total_pages and total_pages > 0:
        detected = "born_digital"
    elif image_only_pages == total_pages and total_pages > 0:
        detected = "scanned"
    elif text_like_pages > 0 and image_only_pages > 0:
        detected = "hybrid"
    else:
        detected = "unknown"

    return {
        "file": str(Path(pdf_path).resolve()),
        "page_count": total_pages,
        "detected_pdf_type": detected,
        "pages": page_stats,
    }


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python detect_pdf_type.py input.pdf", file=sys.stderr)
        sys.exit(1)
    result = detect_pdf_type(sys.argv[1])
    print(json.dumps(result, ensure_ascii=False, indent=2))
