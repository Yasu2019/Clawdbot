﻿"""
Docling skeleton for structure parsing and picture annotation.

This script is intentionally conservative:
- It is a starting point, not a promise that every environment already has the exact API version.
- Codex should check installed Docling version and adapt imports if needed.

Goal:
- Convert PDF to a Docling document representation
- Export text / tables / pictures metadata
- Optionally annotate pictures with a local VLM
"""

from __future__ import annotations

import json
import sys
from pathlib import Path


def main(pdf_path: str, out_dir: str) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    # IMPORTANT:
    # Codex should verify the exact Docling API in the target environment.
    # Below is a conceptual placeholder to be adapted to the installed version.

    result = {
        "status": "placeholder",
        "note": "Adapt this script to the installed Docling version.",
        "input_pdf": str(Path(pdf_path).resolve()),
        "intended_outputs": [
            "document structure",
            "pictures list",
            "picture descriptions",
            "tables",
            "canonical JSON mapping"
        ]
    }

    (out / "docling_result_placeholder.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python parse_with_docling.py input.pdf output_dir", file=sys.stderr)
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
