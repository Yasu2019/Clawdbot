﻿"""
Example wrapper for OCRmyPDF.
Requires the system package / executable to be installed.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def run_ocr(input_pdf: str, output_pdf: str, lang: str = "jpn+eng") -> int:
    cmd = [
        "ocrmypdf",
        "-l", lang,
        "--skip-text",
        "--rotate-pages",
        "--deskew",
        input_pdf,
        output_pdf,
    ]
    print("Running:", " ".join(cmd))
    result = subprocess.run(cmd, check=False)
    return result.returncode


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python run_ocrmypdf.py input.pdf output_ocr.pdf", file=sys.stderr)
        sys.exit(1)
    rc = run_ocr(sys.argv[1], sys.argv[2])
    sys.exit(rc)
