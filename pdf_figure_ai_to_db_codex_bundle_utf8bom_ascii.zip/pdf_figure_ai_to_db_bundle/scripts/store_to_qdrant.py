﻿from __future__ import annotations

import sys
import json
from pathlib import Path

from qdrant_client import QdrantClient
from qdrant_client.http import models


def fake_embed(text: str, dim: int = 8) -> list[float]:
    # Placeholder only.
    # Replace with your real embedding call.
    base = [0.0] * dim
    for i, ch in enumerate(text[:dim]):
        base[i] = (ord(ch) % 100) / 100.0
    return base


def main(canonical_json: str, qdrant_url: str, collection_name: str) -> None:
    payload = json.loads(Path(canonical_json).read_text(encoding="utf-8"))
    client = QdrantClient(url=qdrant_url)

    dim = 8
    if not client.collection_exists(collection_name):
        client.create_collection(
            collection_name=collection_name,
            vectors_config=models.VectorParams(size=dim, distance=models.Distance.COSINE),
        )

    points = []
    point_id = 1
    for item in payload["items"]:
        text = item.get("text_normalized") or item.get("ai_summary") or item.get("caption_ai")
        if not text:
            continue
        vector = fake_embed(text, dim=dim)
        points.append(
            models.PointStruct(
                id=point_id,
                vector=vector,
                payload={
                    "page_no": item["page_no"],
                    "item_type": item["item_type"],
                    "group_id": item.get("group_id"),
                    "text": text,
                    "source_method": item["source_method"],
                },
            )
        )
        point_id += 1

    if points:
        client.upsert(collection_name=collection_name, points=points)

    print(f"Upserted {len(points)} points to {collection_name}.")


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python store_to_qdrant.py canonical.json http://localhost:6333 collection_name", file=sys.stderr)
        sys.exit(1)
    main(sys.argv[1], sys.argv[2], sys.argv[3])
