﻿# PDF Figure / Illustration Understanding -> DB Bundle

This bundle is designed for Codex CLI handoff.
Goal:
- Read PDF text with high accuracy
- Understand figures / illustrations / charts / tables with AI
- Store both source content and AI-enriched metadata into DB
- Make the result suitable for search, audit, and RAG

Date:
- Generated on 2026-04-01

Recommended baseline architecture:
1. Detect PDF type
   - born-digital PDF: prefer native extraction first
   - scanned PDF: OCR first
2. Extract text / blocks / images
3. Run layout-aware parsing
4. Run figure understanding on extracted pictures
5. Normalize to canonical JSON
6. Store metadata in PostgreSQL
7. Store vectors in Qdrant
8. Keep provenance, bbox, page number, and source file hash

Primary recommended stack:
- PyMuPDF: fast text / block / image extraction
- pdfplumber: table and layout inspection
- OCRmyPDF + Tesseract: OCR text layer for scanned PDFs
- Docling: document structure + picture annotation + VLM integration
- PostgreSQL: metadata / audit / provenance
- Qdrant: embeddings / retrieval

Practical principle:
- Do NOT OCR every PDF blindly.
- First detect whether text already exists.
- Only add OCR when native extraction is weak or absent.
- Keep original evidence: source path, page number, bbox, image asset path, and extraction method.

Read in this order:
1. docs/01_overview_and_adoption.md
2. docs/02_pipeline_design.md
3. docs/03_db_schema.md
4. prompts/01_codex_master_prompt.md
5. scripts/

Windows / UTF notes:
- File names are ASCII only.
- All text files are UTF-8 with BOM.
- Line endings are CRLF.
- This is intentional to reduce mojibake in Windows tools.

Main deliverables:
- Architecture decision documents
- Codex CLI handoff prompts
- Python skeleton scripts
- JSON schemas
- SQL DDL
- Troubleshooting and benchmark templates
