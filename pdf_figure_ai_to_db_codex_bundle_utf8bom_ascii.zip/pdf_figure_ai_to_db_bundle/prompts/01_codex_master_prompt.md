﻿You are Codex CLI operating inside an existing local AI / Docker / portal environment.

Mission:
Implement a production-friendly pipeline that can read PDFs accurately, understand figures / illustrations / charts / tables with AI, and store both source and enriched results into DB.

Before changing anything, you MUST evaluate:
1. Whether similar code, containers, workflows, or portal cards already exist
2. Whether full adoption, partial adoption, or hold is the best decision
3. Whether proposed changes conflict with current OCR / ingestion / RAG flows
4. Whether local-only processing is required for confidentiality
5. Whether existing PostgreSQL / Qdrant infrastructure should be reused

Decision rules:
- If an existing ingestion pipeline already covers text extraction well, then prefer partial adoption that adds figure understanding only.
- If no figure-aware pipeline exists and current use cases clearly need image understanding, allow full adoption.
- If the current system already has overlapping code that would cause confusion or double ingestion, either merge carefully or hold.

Absolute requirements:
- Do not blindly OCR all PDFs.
- First detect born-digital vs scanned vs hybrid.
- Preserve provenance: page, bbox, source method, source asset path, file hash.
- Keep best-effort processing on partial failures.
- Default to local-first processing.
- Remote VLM / API use must be optional and clearly isolated.

Implementation targets:
- Python 3.11+
- Docker-friendly
- ASCII file names where reasonable
- UTF-8 output
- Clear logs
- Small modular scripts first, then service integration

Requested outputs:
1. Adoption decision report
2. Detailed implementation plan
3. Minimal working pipeline
4. DB migration or SQL DDL
5. Test dataset plan
6. Benchmark / quality plan
7. Rollback plan
8. Final summary of what was adopted and why

Technical preference order:
1. PyMuPDF for native extraction and image extraction
2. pdfplumber for table / layout troubleshooting
3. OCRmyPDF + Tesseract for scanned PDFs
4. Docling for structure + picture annotation
5. PostgreSQL for metadata
6. Qdrant for vector retrieval

Expected behavior:
- Search the current repo / containers / compose files first.
- Reuse existing services if possible.
- Avoid duplicating already-working components.
- Build only what is missing.
- When uncertain, create a thin adapter instead of a new parallel stack.

Acceptance criteria:
- A sample born-digital PDF is ingested correctly
- A sample scanned PDF is ingested with OCR fallback
- At least one figure is extracted, described, and stored with provenance
- Search can retrieve figure-related content by text query
- Logs show route decisions and failure reasons
