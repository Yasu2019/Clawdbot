﻿# Adoption decision report template

## 1. Executive decision
- Full adoption / Partial adoption / Hold:
- Reason in one paragraph:

## 2. Existing overlap check
- Existing OCR pipeline found:
- Existing PDF parser found:
- Existing DB ingestion flow found:
- Existing vector store flow found:
- Existing portal card / monitoring found:
- Conflict risk:

## 3. Proposed integration scope
- Components to add:
- Components to modify:
- Components to leave unchanged:
- Temporary pilot-only components:

## 4. Security / privacy
- Local-only required:
- Remote model allowed:
- Log redaction needed:
- Temp file cleanup policy:

## 5. Data model
- PostgreSQL tables:
- Qdrant collections:
- Provenance fields:
- Confidence fields:

## 6. Routing logic
- born-digital:
- scanned:
- hybrid:

## 7. Quality gate
- Native extraction pass rule:
- OCR fallback rule:
- Figure review rule:
- Reprocessing rule:

## 8. Rollback plan
- How to disable:
- How to revert schema:
- How to stop new jobs:

## 9. Final recommendation
- Implement now / Pilot only / Hold:
- Rationale:
