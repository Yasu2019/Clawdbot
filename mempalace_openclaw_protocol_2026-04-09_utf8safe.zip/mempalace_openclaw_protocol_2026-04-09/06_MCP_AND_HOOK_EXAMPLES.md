﻿# MCP and Hook Examples

## Direct MCP server command from the public README

```bash
claude mcp add mempalace -- python -m mempalace.mcp_server
```

## Claude Code hook example pattern

The public README shows hook entries like:

```json
{
  "hooks": {
    "Stop": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "/path/to/mempalace/hooks/mempal_save_hook.sh"
          }
        ]
      }
    ],
    "PreCompact": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "/path/to/mempalace/hooks/mempal_precompact_hook.sh"
          }
        ]
      }
    ]
  }
}
```

## Recommended way to think about hooks in your environment

Do **not** wire hooks into production workflows first.

Start with:
- one test agent
- one project wing
- one save interval
- one backup directory

Observe:
- latency impact
- accidental over-saving
- duplicate memory filing
- usefulness of saved results

## OpenClaw / Antigravity recommendation

Because your environment already has a gateway/orchestration layer,
treat MemPalace as:
- a sidecar MCP service for evaluation
- or a design reference for a Qdrant-first implementation

Do not re-architect the whole platform around it before proof.
