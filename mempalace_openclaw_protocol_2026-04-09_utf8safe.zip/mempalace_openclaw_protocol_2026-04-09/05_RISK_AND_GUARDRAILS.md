﻿# Risk and Guardrails

## 1. Dependency drift risk

MemPalace public package and repo expectations may not align cleanly.
Guardrail:
- always pin Python and ChromaDB versions
- export `pip freeze`
- store install transcript

## 2. Benchmark overtrust risk

Do not adopt because of leaderboard claims alone.
Guardrail:
- test on your own real memory questions
- use a held-out question set
- measure qualitative usefulness, not just headline score

## 3. Double-memory-silo risk

MemPalace + Qdrant can become two truths.
Guardrail:
- define source of truth by content class:
  - documents = current document pipeline
  - conversations = candidate for MemPalace sidecar
  - production facts = canonical structured store
- forbid silent duplication without ownership rule

## 4. Agent confusion risk

Too many tools make agent behavior worse.
Guardrail:
- expose a small stable tool surface
- do not dump every memory tool into every agent
- use role-based access:
  - reviewer: diary + search
  - architect: search + decision memory
  - ops: incident memory + timeline

## 5. Backup / restore risk

Local-first is good only if recoverable.
Guardrail:
- back up data directory
- back up configs
- document re-create steps
- test restore on a clean environment

## 6. Encoding / transcript hygiene risk

Chat exports are often messy.
Guardrail:
- normalize to UTF-8
- split mega transcripts before mining
- preserve original raw exports separately

## 7. Privacy / retention risk

Local memory can still over-retain sensitive content.
Guardrail:
- define retention policy
- classify content by allowed scope
- exclude secrets, tokens, credentials, raw personal data
