﻿# MemPalace Protocol Pack for OpenClaw / Qdrant / LiteLLM

This ZIP is designed for **evaluation first**, not blind adoption.
It is optimized for your current environment:

- Windows 11 + WSL2 + Docker Desktop
- OpenClaw gateway / UI
- Antigravity
- LiteLLM
- Qdrant
- Paperless-ngx
- Docling
- Infinity embedding server
- Langfuse

## Goal

Decide one of the following:

1. **Adopt MemPalace directly as a sidecar**
2. **Adopt only the MemPalace design ideas**
3. **Reject for now and keep current stack**

## Important reality check

MemPalace is promising, but the public claims and the code/repo state are not fully aligned yet.
This pack therefore uses a **guarded evaluation protocol** rather than a hype-based install.

## Recommended stance for your environment

**Default recommendation:**
Start with **Idea Transplant Mode** instead of full replacement.

Meaning:
- Keep Qdrant as the main vector store
- Keep Paperless / Docling / Infinity / LiteLLM / Langfuse as-is
- Borrow these MemPalace ideas:
  - wing / room / hall taxonomy
  - wake-up memory layers
  - project / person scoped memory
  - agent diary
  - export mining discipline
  - MCP-accessible memory tools

Only adopt the real MemPalace package if it passes the gate checks in this ZIP.

## Files in this pack

- `01_EXECUTIVE_SUMMARY.md`
- `02_GO_NO_GO_CHECKLIST.md`
- `03_ARCHITECTURE_OPTIONS.md`
- `04_PHASED_PROTOCOL.md`
- `05_RISK_AND_GUARDRAILS.md`
- `06_MCP_AND_HOOK_EXAMPLES.md`
- `07_CODEX_REVIEW_PROMPT_JA.txt`
- `08_ANTIGRAVITY_REVIEW_PROMPT_JA.txt`
- `09_SOURCE_NOTES.md`
- `scripts/install_mempalace_wsl.sh`
- `scripts/install_mempalace_windows.ps1`
- `scripts/sample_claude_hooks.json`
- `scripts/mcp_server_example.json`
- `scripts/qdrant_transplant_design.yaml`

## Encoding policy

To reduce mojibake risk on Windows:
- File names are ASCII only
- Markdown / TXT / JSON / YAML / PS1 are UTF-8 with BOM
- Shell scripts are UTF-8 without BOM
- ZIP file name is ASCII only

Generated: 2026-04-09
