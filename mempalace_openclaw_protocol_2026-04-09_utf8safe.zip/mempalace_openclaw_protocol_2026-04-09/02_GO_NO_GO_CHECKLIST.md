﻿# Go / No-Go Checklist

Use this before adoption.

## Gate A — Installation reproducibility

Pass only if all are true:
- Python environment can be created cleanly
- `pip install mempalace` succeeds
- `mempalace --help` works
- `mempalace init` works
- `mempalace status` works after initialization
- dependency versions are recorded
- ChromaDB version is pinned deliberately

Fail if:
- install behavior changes across machines
- package resolves to incompatible ChromaDB automatically
- created collections are unreadable after environment rebuild

## Gate B — Local-only operability

Pass only if:
- no cloud dependency is required
- no mandatory API key is required
- local storage location is clear
- backup / restore is documented
- the system can be stopped without breaking the rest of the stack

## Gate C — MCP usability

Pass only if:
- MCP server launches reliably
- at least one client can call search and status tools correctly
- tool latency is acceptable
- failure mode is clean and observable in logs

Fail if:
- MCP server stalls or dies silently
- memory tools are difficult for the agent to use consistently
- operational troubleshooting is worse than current tool integrations

## Gate D — Retrieval usefulness

Pass only if a small benchmark with your own data shows real value.

Suggested test set:
- 20 historical design decisions
- 20 troubleshooting facts
- 20 "who decided what and when" questions
- 20 cross-project memory questions
- 20 "why did we choose X over Y" questions

Success target:
- direct answerability improves
- retrieval is faster or more precise
- important rationale is surfaced verbatim

## Gate E — Architectural fit

Pass only if:
- it does not fragment your memory system too much
- you can explain clearly:
  - what stays in Qdrant
  - what goes to MemPalace
  - how duplicates are handled
  - which component is source of truth

Fail if:
- you end up with two parallel memory silos
- staff cannot tell which store to trust

## Decision matrix

### GO (direct sidecar adoption)
Use if Gates A-E all pass.

### PARTIAL GO (idea transplant only)
Use if:
- ideas are good
- package maturity is not sufficient

### NO-GO (defer)
Use if:
- dependency pinning is unstable
- operational value is unclear
- Qdrant-first design remains cleaner
