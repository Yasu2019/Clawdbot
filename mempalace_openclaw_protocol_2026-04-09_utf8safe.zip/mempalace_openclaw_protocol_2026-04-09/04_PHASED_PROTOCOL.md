﻿# Phased Implementation Protocol

## Phase 0 — Safety baseline

Do this first:
- snapshot current Docker compose / config / env files
- record active ports
- record current embedding dimensions
- record current memory-related tools
- define rollback rule:
  - if MemPalace test fails, remove only sidecar env and data dir

## Phase 1 — Isolated install

Use the scripts in `scripts/`.
Recommended location examples:
- WSL: `~/tools/mempalace-eval`
- Windows: `D:\tools\mempalace-eval`

Rules:
- do not install into existing production virtualenv
- pin versions
- store all logs
- create a dedicated data directory

### Expected validation commands
- `python --version`
- `pip show mempalace`
- `pip show chromadb`
- `mempalace --help`
- `mempalace init ./seed_project`
- `mempalace status`

## Phase 2 — Mine a tiny dataset

Use a tiny, controlled sample:
- 3 project notes
- 3 architecture decisions
- 3 troubleshooting logs
- 3 chat transcripts
- 1 timeline of changes

Questions to test:
- why did we choose this architecture?
- who changed the decision?
- what happened before the failure?
- what was the earlier workaround?
- what project was related?

Success condition:
- answers are grounded in retrieved memory, not hallucinated summary

## Phase 3 — MCP proof

Connect one MCP-capable client.
Test:
- status
- list wings
- search within a wing
- search across wings
- add a drawer
- query KG if enabled

Record:
- cold start latency
- average tool latency
- failure behavior
- agent prompt burden

## Phase 4 — Compare against current stack

Compare:
- MemPalace direct search
- current OpenClaw + Qdrant retrieval
- hybrid prompt with structured metadata

Judge on:
- precision
- rationale recovery
- ease of operation
- observability
- maintenance burden

## Phase 5 — Decide

### If MemPalace direct wins
Keep as sidecar first.
Do not merge deeply until:
- backup strategy exists
- restart strategy exists
- client integration is reliable
- version pinning is frozen

### If idea transplant wins
Implement:
- wing / room metadata in Qdrant payload
- L0-L3 retrieval profiles
- agent diary collections
- structured export mining
- chronology / validity metadata

### If neither wins
Document the findings and defer.

## Production guardrail

Never let a new memory layer become the only copy of important information
until backup, export, and recovery are verified.
