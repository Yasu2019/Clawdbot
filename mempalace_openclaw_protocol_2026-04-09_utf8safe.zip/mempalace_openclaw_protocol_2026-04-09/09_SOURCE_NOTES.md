﻿# Source Notes

This pack was prepared with reference to the public MemPalace GitHub repository and related public pages as of 2026-04-09.

Important public points reflected in this pack:
- public quick start and command examples
- MCP server command and tool list
- hook example structure
- caution that raw-mode benchmark and AAAK claims were clarified in the README
- release notes claims
- public issue about ChromaDB version mismatch risk

This pack intentionally recommends a guarded evaluation because public claims and repo/package behavior may not be perfectly aligned yet.
