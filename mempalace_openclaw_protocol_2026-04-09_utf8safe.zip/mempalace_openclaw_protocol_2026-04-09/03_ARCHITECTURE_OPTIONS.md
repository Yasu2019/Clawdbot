﻿# Architecture Options

## Option 1 — Direct MemPalace Sidecar

### Shape
- Keep current stack unchanged
- Add a dedicated Python virtual environment for MemPalace
- Add local ChromaDB data directory for MemPalace only
- Connect via MCP from compatible client(s)

### Pros
- Fastest way to test real package behavior
- Minimal change to existing Qdrant pipeline
- Easy to remove if not useful

### Cons
- Introduces another memory store
- ChromaDB version pin needs active control
- Search surface becomes split

### Recommended use
- experimental evaluation
- isolated proof of concept
- low-risk comparison against current system

## Option 2 — MemPalace Idea Transplant into Existing Stack (Recommended)

### Shape
- Keep Qdrant as primary vector store
- Add metadata schema inspired by MemPalace:
  - wing
  - room
  - hall
  - layer
  - agent
  - validity interval
- Add "wake-up" retrieval profiles in OpenClaw / Antigravity prompts
- Add diary collections per agent
- Add export-mining scripts that normalize chat history and notes

### Pros
- no second vector DB required
- best fit with current architecture
- observability remains centralized
- routing remains under LiteLLM/OpenClaw control

### Cons
- requires implementation work
- not a one-command install
- you do not get the package "as-is"

### Recommended use
- production direction
- long-term maintainability
- cost and observability discipline

## Option 3 — Hybrid

### Shape
- Sidecar MemPalace for conversations only
- Qdrant remains canonical for docs / OCR / knowledge base
- optional sync or cross-link rules

### Pros
- narrower evaluation scope
- less duplication than full adoption

### Cons
- still two stores
- retrieval policy becomes more complex

## Recommended final choice

For your environment:
1. Start with Option 1 for evaluation
2. Move toward Option 2 for production
3. Use Option 3 only if conversation memory proves uniquely valuable
