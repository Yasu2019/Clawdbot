﻿param(
    [string]$RootDir = "D:\tools\mempalace-eval"
)

$ErrorActionPreference = "Stop"

$VenvDir = Join-Path $RootDir ".venv"
$DataDir = Join-Path $RootDir "palace_data"
$LogDir  = Join-Path $RootDir "logs"
$SeedDir = Join-Path $RootDir "seed_project"

New-Item -ItemType Directory -Force -Path $RootDir,$DataDir,$LogDir,$SeedDir | Out-Null

python --version | Tee-Object -FilePath (Join-Path $LogDir "python_version.txt")

python -m venv $VenvDir

$Py = Join-Path $VenvDir "Scripts\python.exe"
$Pip = Join-Path $VenvDir "Scripts\pip.exe"

& $Py -m pip install --upgrade pip wheel setuptools | Tee-Object -FilePath (Join-Path $LogDir "pip_upgrade.txt")

# NOTE:
# We pin ChromaDB conservatively for evaluation because public repo/package
# discussions indicate version mismatch risk between published install behavior
# and repo/dev expectations.
try {
    & $Py -m pip install "chromadb>=0.5,<0.7" "mempalace==3.0.0" 2>&1 | Tee-Object -FilePath (Join-Path $LogDir "install.txt")
} catch {
    $_ | Out-String | Set-Content -Encoding utf8 (Join-Path $LogDir "install_error.txt")
}

try { & $Py -m pip show mempalace | Tee-Object -FilePath (Join-Path $LogDir "show_mempalace.txt") } catch {}
try { & $Py -m pip show chromadb | Tee-Object -FilePath (Join-Path $LogDir "show_chromadb.txt") } catch {}
& $Py -m pip freeze | Tee-Object -FilePath (Join-Path $LogDir "freeze.txt")

"This is a tiny seed project for MemPalace evaluation." | Set-Content -Encoding utf8 (Join-Path $SeedDir "README.txt")

try { & (Join-Path $VenvDir "Scripts\mempalace.exe") --help 2>&1 | Tee-Object -FilePath (Join-Path $LogDir "mempalace_help.txt") } catch {}
try { & (Join-Path $VenvDir "Scripts\mempalace.exe") init $SeedDir 2>&1 | Tee-Object -FilePath (Join-Path $LogDir "mempalace_init.txt") } catch {}
try { & (Join-Path $VenvDir "Scripts\mempalace.exe") status 2>&1 | Tee-Object -FilePath (Join-Path $LogDir "mempalace_status.txt") } catch {}

Write-Host ""
Write-Host "Evaluation environment created at: $RootDir"
Write-Host "Check:"
Write-Host "  $(Join-Path $LogDir 'install.txt')"
Write-Host "  $(Join-Path $LogDir 'freeze.txt')"
Write-Host "  $(Join-Path $LogDir 'show_chromadb.txt')"
Write-Host "  $(Join-Path $LogDir 'mempalace_init.txt')"
Write-Host "  $(Join-Path $LogDir 'mempalace_status.txt')"
