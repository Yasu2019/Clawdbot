#!/usr/bin/env bash
set -euo pipefail

# MemPalace isolated evaluator for WSL / Linux
# Purpose:
# - keep MemPalace in its own virtual environment
# - pin versions deliberately
# - avoid touching production Python envs

ROOT_DIR="${1:-$HOME/tools/mempalace-eval}"
VENV_DIR="$ROOT_DIR/.venv"
DATA_DIR="$ROOT_DIR/palace_data"
LOG_DIR="$ROOT_DIR/logs"

mkdir -p "$ROOT_DIR" "$DATA_DIR" "$LOG_DIR"

python3 --version | tee "$LOG_DIR/python_version.txt"

python3 -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"

python -m pip install --upgrade pip wheel setuptools | tee "$LOG_DIR/pip_upgrade.txt"

# NOTE:
# The public repo README shows chromadb>=0.4.0,
# while public issue discussion indicates users may resolve to chromadb 1.x
# even though repo/dev expectations were closer to 0.6.x.
# Therefore we pin chromadb conservatively for evaluation.
python -m pip install "chromadb>=0.5,<0.7" "mempalace==3.0.0" | tee "$LOG_DIR/install.txt" || true

python -m pip show mempalace | tee "$LOG_DIR/show_mempalace.txt" || true
python -m pip show chromadb | tee "$LOG_DIR/show_chromadb.txt" || true
python -m pip freeze | tee "$LOG_DIR/freeze.txt"

mkdir -p "$ROOT_DIR/seed_project"
cat > "$ROOT_DIR/seed_project/README.txt" <<'EOF'
This is a tiny seed project for MemPalace evaluation.
EOF

{
  echo "===== mempalace --help ====="
  mempalace --help
} | tee "$LOG_DIR/mempalace_help.txt" || true

{
  echo "===== mempalace init ====="
  mempalace init "$ROOT_DIR/seed_project"
} | tee "$LOG_DIR/mempalace_init.txt" || true

{
  echo "===== mempalace status ====="
  mempalace status
} | tee "$LOG_DIR/mempalace_status.txt" || true

cat <<EOF

Evaluation environment created at:
  $ROOT_DIR

Check:
  $LOG_DIR/install.txt
  $LOG_DIR/freeze.txt
  $LOG_DIR/show_chromadb.txt
  $LOG_DIR/mempalace_init.txt
  $LOG_DIR/mempalace_status.txt

EOF
